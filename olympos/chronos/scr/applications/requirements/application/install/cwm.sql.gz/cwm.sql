-- phpMyAdmin SQL Dump
-- version 3.3.7deb5build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 09, 2011 at 11:40 AM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `chronos`
--

-- --------------------------------------------------------

--
-- Table structure for table `ChiNode`
--

CREATE TABLE IF NOT EXISTS `ChiNode` (
  `id` int(11) NOT NULL,
  `fk_chicontroller_id` int(11) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `notes` text,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `last_editor` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  `display_value` varchar(255) DEFAULT NULL,
  `parent_order` varchar(255) DEFAULT NULL,
  `child_order` varchar(255) DEFAULT NULL,
  `pk_name` varchar(255) DEFAULT NULL,
  `is_searchable` varchar(255) DEFAULT NULL,
  `orderby` varchar(255) DEFAULT NULL,
  `is_soap` varchar(255) DEFAULT NULL,
  `initparams` varchar(255) DEFAULT NULL,
  `fk_package_id` int(11) DEFAULT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `is_ordered` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `sortkey` int(11) DEFAULT NULL,
  `visibility` varchar(255) DEFAULT NULL,
  `isabstract` varchar(255) DEFAULT NULL,
  `umi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiNode`
--

INSERT INTO `ChiNode` (`id`, `fk_chicontroller_id`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `display_value`, `parent_order`, `child_order`, `pk_name`, `is_searchable`, `orderby`, `is_soap`, `initparams`, `fk_package_id`, `table_name`, `is_ordered`, `status`, `author`, `sortkey`, `visibility`, `isabstract`, `umi`) VALUES
(95856, NULL, 'Chi3944Nod', '1.0', 'String', '?', '2011-03-17 13:41:55', 'admin', 'admin', '2011-03-17 13:42:09', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 95844, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(42605, NULL, 'Chi103Nod', '1.0', 'Adodbseq', '?', '2009-09-04 10:23:01', 'pgiuseppe', 'ingo.herwig', '2010-01-11 17:21:51', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 37000, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL),
(76948, NULL, 'Chi1736Nod', '1.0', 'MyClass', '?', '2010-11-25 20:39:30', 'admin', 'admin', '2010-11-25 20:43:03', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 36986, NULL, NULL, '27293', NULL, 3, NULL, 'false', NULL),
(36090, 35339, 'Chi062Nod', '1.0', 'Node', '?', '2009-08-26 19:22:11', 'niko', 'admin', '2010-11-04 23:42:06', NULL, NULL, NULL, NULL, 'true', 'none', 'true', 'database', 36065, NULL, NULL, NULL, NULL, 36090, NULL, NULL, NULL),
(36131, NULL, 'Chi063Nod', '1.0', 'Role', '?', '2009-08-26 19:26:44', 'niko', 'pgiuseppe', '2010-01-08 18:43:43', NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', 36076, NULL, NULL, NULL, NULL, 36131, NULL, NULL, NULL),
(36141, NULL, 'Chi064Nod', '1.0', 'User', '?', '2009-08-26 19:27:17', 'niko', 'pgiuseppe', '2010-01-08 18:43:12', NULL, NULL, NULL, NULL, 'true', 'none', NULL, 'database', 36076, NULL, NULL, NULL, NULL, 36141, NULL, NULL, NULL),
(37016, NULL, 'Chi065Nod', '1.0', 'UserRDB', '<br>', '2009-08-26 20:20:39', 'niko', 'ingo.herwig', '2010-01-11 17:21:50', 'login', NULL, NULL, 'id', 'true', 'none', 'true', 'database', 37000, 'user', NULL, NULL, NULL, 2, NULL, NULL, NULL),
(37136, NULL, 'Chi066Nod', '1.0', 'RoleRDB', '<br>', '2009-08-26 20:27:13', 'niko', 'ingo.herwig', '2010-01-11 17:21:50', 'name', NULL, NULL, 'id', 'true', 'none', 'true', 'database', 37000, 'role', NULL, NULL, NULL, 3, NULL, NULL, NULL),
(37202, NULL, 'Chi067Nod', '1.0', 'Locktable', '?', '2009-08-26 20:29:22', 'niko', 'ingo.herwig', '2010-01-11 17:21:50', NULL, NULL, NULL, NULL, 'false', 'none', NULL, 'database', 37000, 'locktable', NULL, NULL, NULL, 4, NULL, NULL, NULL),
(37302, NULL, 'Chi068Nod', '1.0', 'Translation', '?', '2009-08-26 20:33:06', 'niko', 'ingo.herwig', '2010-01-11 17:21:50', 'oid|attribute|language', NULL, NULL, 'id', 'true', 'none', 'true', 'database', 37000, NULL, NULL, NULL, NULL, 6, NULL, NULL, NULL),
(37460, NULL, 'Chi069Nod', '1.0', 'EntityBase', '?', '2009-08-26 20:40:16', 'niko', 'admin', '2010-11-25 20:39:35', NULL, NULL, NULL, 'id', 'true', 'none', 'true', 'database', 36986, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL),
(78021, 78019, 'Chi1740Nod', '1.0', 'Node', '?', '2011-02-03 17:09:40', 'admin', 'admin', '2011-02-03 17:10:07', 'name', NULL, NULL, NULL, 'true', 'none', 'true', 'database', 78170, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78182, NULL, 'Chi1741Nod', '1.0', 'Role', '?', '2011-02-03 17:10:11', 'admin', 'admin', '2011-02-03 17:10:11', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 78178, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78185, NULL, 'Chi1742Nod', '1.0', 'User', '?', '2011-02-03 17:10:12', 'admin', 'admin', '2011-02-03 17:10:12', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 78178, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78700, NULL, 'Chi1750Nod', '1.0', 'Node', NULL, '2011-02-11 17:28:57', 'admin', 'admin', '2011-02-11 17:28:57', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78704, NULL, 'Chi1751Nod', '1.0', 'Role', NULL, '2011-02-11 17:28:57', 'admin', 'admin', '2011-02-11 17:28:57', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78705, NULL, 'Chi1752Nod', '1.0', 'User', NULL, '2011-02-11 17:28:57', 'admin', 'admin', '2011-02-11 17:28:57', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78710, NULL, 'Chi1753Nod', '1.0', 'Actor', NULL, '2011-02-11 17:28:57', 'admin', 'admin', '2011-02-11 17:28:57', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78711, NULL, 'Chi1754Nod', '1.0', 'Date', NULL, '2011-02-11 17:28:57', 'admin', 'admin', '2011-02-11 17:28:57', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78713, NULL, 'Chi1755Nod', '1.0', 'Director', NULL, '2011-02-11 17:28:57', 'admin', 'admin', '2011-02-11 17:28:57', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78714, NULL, 'Chi1756Nod', '1.0', 'EntityBase', NULL, '2011-02-11 17:28:57', 'admin', 'admin', '2011-02-11 17:28:57', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78719, NULL, 'Chi1757Nod', '1.0', 'EntityBaseExtended', NULL, '2011-02-11 17:28:58', 'admin', 'admin', '2011-02-11 17:28:58', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78722, NULL, 'Chi1758Nod', '1.0', 'Genre', NULL, '2011-02-11 17:28:58', 'admin', 'admin', '2011-02-11 17:28:58', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78723, NULL, 'Chi1759Nod', '1.0', 'Image', NULL, '2011-02-11 17:28:58', 'admin', 'admin', '2011-02-11 17:28:58', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78725, NULL, 'Chi1760Nod', '1.0', 'Language', NULL, '2011-02-11 17:28:58', 'admin', 'admin', '2011-02-11 17:28:58', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78727, NULL, 'Chi1761Nod', '1.0', 'Movie', NULL, '2011-02-11 17:28:58', 'admin', 'admin', '2011-02-11 17:28:58', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78737, NULL, 'Chi1762Nod', '1.0', 'Person', NULL, '2011-02-11 17:28:59', 'admin', 'admin', '2011-02-11 17:28:59', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78741, NULL, 'Chi1763Nod', '1.0', 'Poster', NULL, '2011-02-11 17:28:59', 'admin', 'admin', '2011-02-11 17:28:59', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78742, NULL, 'Chi1764Nod', '1.0', 'PosterPrimary', NULL, '2011-02-11 17:28:59', 'admin', 'admin', '2011-02-11 17:28:59', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78743, NULL, 'Chi1765Nod', '1.0', 'PosterSecondary', NULL, '2011-02-11 17:29:00', 'admin', 'admin', '2011-02-11 17:29:00', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78746, NULL, 'Chi1766Nod', '1.0', 'Adodbseq', NULL, '2011-02-11 17:29:00', 'admin', 'admin', '2011-02-11 17:29:00', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78747, NULL, 'Chi1767Nod', '1.0', 'Locktable', NULL, '2011-02-11 17:29:00', 'admin', 'admin', '2011-02-11 17:29:00', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78751, NULL, 'Chi1768Nod', '1.0', 'RoleRDB', NULL, '2011-02-11 17:29:00', 'admin', 'admin', '2011-02-11 17:29:00', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78753, NULL, 'Chi1769Nod', '1.0', 'Translation', NULL, '2011-02-11 17:29:00', 'admin', 'admin', '2011-02-11 17:29:00', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78758, NULL, 'Chi1770Nod', '1.0', 'UserRDB', NULL, '2011-02-11 17:29:01', 'admin', 'admin', '2011-02-11 17:29:01', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78956, NULL, 'Chi1771Nod', '1.0', 'Node', NULL, '2011-02-15 13:52:42', 'admin', 'admin', '2011-02-15 13:52:42', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78960, NULL, 'Chi1772Nod', '1.0', 'Role', NULL, '2011-02-15 13:52:43', 'admin', 'admin', '2011-02-15 13:52:43', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78961, NULL, 'Chi1773Nod', '1.0', 'User', NULL, '2011-02-15 13:52:44', 'admin', 'admin', '2011-02-15 13:52:44', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78966, NULL, 'Chi1774Nod', '1.0', 'Actor', NULL, '2011-02-15 13:52:44', 'admin', 'admin', '2011-02-15 13:52:44', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78967, NULL, 'Chi1775Nod', '1.0', 'Date', NULL, '2011-02-15 13:52:44', 'admin', 'admin', '2011-02-15 13:52:44', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78969, NULL, 'Chi1776Nod', '1.0', 'Director', NULL, '2011-02-15 13:52:44', 'admin', 'admin', '2011-02-15 13:52:44', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78970, NULL, 'Chi1777Nod', '1.0', 'EntityBase', NULL, '2011-02-15 13:52:44', 'admin', 'admin', '2011-02-15 13:52:44', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78975, NULL, 'Chi1778Nod', '1.0', 'EntityBaseExtended', NULL, '2011-02-15 13:52:44', 'admin', 'admin', '2011-02-15 13:52:44', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78978, NULL, 'Chi1779Nod', '1.0', 'Genre', NULL, '2011-02-15 13:52:45', 'admin', 'admin', '2011-02-15 13:52:45', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78979, NULL, 'Chi1780Nod', '1.0', 'Image', NULL, '2011-02-15 13:52:45', 'admin', 'admin', '2011-02-15 13:52:45', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78981, NULL, 'Chi1781Nod', '1.0', 'Language', NULL, '2011-02-15 13:52:45', 'admin', 'admin', '2011-02-15 13:52:45', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78983, NULL, 'Chi1782Nod', '1.0', 'Movie', NULL, '2011-02-15 13:52:45', 'admin', 'admin', '2011-02-15 13:52:45', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78993, NULL, 'Chi1783Nod', '1.0', 'Person', NULL, '2011-02-15 13:52:46', 'admin', 'admin', '2011-02-15 13:52:46', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78997, NULL, 'Chi1784Nod', '1.0', 'Poster', NULL, '2011-02-15 13:52:46', 'admin', 'admin', '2011-02-15 13:52:46', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78998, NULL, 'Chi1785Nod', '1.0', 'PosterPrimary', NULL, '2011-02-15 13:52:46', 'admin', 'admin', '2011-02-15 13:52:46', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(78999, NULL, 'Chi1786Nod', '1.0', 'PosterSecondary', NULL, '2011-02-15 13:52:46', 'admin', 'admin', '2011-02-15 13:52:46', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79002, NULL, 'Chi1787Nod', '1.0', 'Adodbseq', NULL, '2011-02-15 13:52:47', 'admin', 'admin', '2011-02-15 13:52:47', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79003, NULL, 'Chi1788Nod', '1.0', 'Locktable', NULL, '2011-02-15 13:52:47', 'admin', 'admin', '2011-02-15 13:52:47', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79007, NULL, 'Chi1789Nod', '1.0', 'RoleRDB', NULL, '2011-02-15 13:52:47', 'admin', 'admin', '2011-02-15 13:52:47', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79009, NULL, 'Chi1790Nod', '1.0', 'Translation', NULL, '2011-02-15 13:52:47', 'admin', 'admin', '2011-02-15 13:52:47', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79014, NULL, 'Chi1791Nod', '1.0', 'UserRDB', NULL, '2011-02-15 13:52:48', 'admin', 'admin', '2011-02-15 13:52:48', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79482, NULL, 'Chi1839Nod', '1.0', 'persona', NULL, '2011-02-15 16:39:56', 'admin', 'admin', '2011-02-15 16:39:56', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79138, NULL, 'Chi1794Nod', '1.0', 'User', NULL, '2011-02-15 15:09:36', 'admin', 'admin', '2011-02-15 15:09:36', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79142, NULL, 'Chi1795Nod', '1.0', 'Actor', NULL, '2011-02-15 15:09:37', 'admin', 'admin', '2011-02-15 15:09:37', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79143, NULL, 'Chi1796Nod', '1.0', 'Date', NULL, '2011-02-15 15:09:37', 'admin', 'admin', '2011-02-15 15:09:37', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79145, NULL, 'Chi1797Nod', '1.0', 'Director', NULL, '2011-02-15 15:09:37', 'admin', 'admin', '2011-02-15 15:09:37', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79146, NULL, 'Chi1798Nod', '1.0', 'EntityBase', NULL, '2011-02-15 15:09:37', 'admin', 'admin', '2011-02-15 15:09:37', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79151, NULL, 'Chi1799Nod', '1.0', 'EntityBaseExtended', NULL, '2011-02-15 15:09:37', 'admin', 'admin', '2011-02-15 15:09:37', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79154, NULL, 'Chi1800Nod', '1.0', 'Genre', NULL, '2011-02-15 15:09:38', 'admin', 'admin', '2011-02-15 15:09:38', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79155, NULL, 'Chi1801Nod', '1.0', 'Image', NULL, '2011-02-15 15:09:38', 'admin', 'admin', '2011-02-15 15:09:38', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79157, NULL, 'Chi1802Nod', '1.0', 'Language', NULL, '2011-02-15 15:09:38', 'admin', 'admin', '2011-02-15 15:09:38', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79159, NULL, 'Chi1803Nod', '1.0', 'Movie', NULL, '2011-02-15 15:09:38', 'admin', 'admin', '2011-02-15 15:09:38', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79169, NULL, 'Chi1804Nod', '1.0', 'Person', NULL, '2011-02-15 15:09:39', 'admin', 'admin', '2011-02-15 15:09:39', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79173, NULL, 'Chi1805Nod', '1.0', 'Poster', NULL, '2011-02-15 15:09:39', 'admin', 'admin', '2011-02-15 15:09:39', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79174, NULL, 'Chi1806Nod', '1.0', 'PosterPrimary', NULL, '2011-02-15 15:09:39', 'admin', 'admin', '2011-02-15 15:09:39', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79175, NULL, 'Chi1807Nod', '1.0', 'PosterSecondary', NULL, '2011-02-15 15:09:39', 'admin', 'admin', '2011-02-15 15:09:39', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79178, NULL, 'Chi1808Nod', '1.0', 'Adodbseq', NULL, '2011-02-15 15:09:40', 'admin', 'admin', '2011-02-15 15:09:40', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79179, NULL, 'Chi1809Nod', '1.0', 'Locktable', NULL, '2011-02-15 15:09:40', 'admin', 'admin', '2011-02-15 15:09:40', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79183, NULL, 'Chi1810Nod', '1.0', 'RoleRDB', NULL, '2011-02-15 15:09:40', 'admin', 'admin', '2011-02-15 15:09:40', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79185, NULL, 'Chi1811Nod', '1.0', 'Translation', NULL, '2011-02-15 15:09:40', 'admin', 'admin', '2011-02-15 15:09:40', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79190, NULL, 'Chi1812Nod', '1.0', 'UserRDB', NULL, '2011-02-15 15:09:41', 'admin', 'admin', '2011-02-15 15:09:41', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79411, NULL, 'Chi1833Nod', '1.0', 'peron', NULL, '2011-02-15 15:56:25', 'admin', 'admin', '2011-02-15 15:56:25', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79302, NULL, 'Chi1814Nod', '1.0', 'Date', NULL, '2011-02-15 15:14:21', 'admin', 'admin', '2011-02-15 15:14:21', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79304, NULL, 'Chi1815Nod', '1.0', 'Director', NULL, '2011-02-15 15:14:22', 'admin', 'admin', '2011-02-15 15:14:22', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79305, NULL, 'Chi1816Nod', '1.0', 'EntityBase', NULL, '2011-02-15 15:14:22', 'admin', 'admin', '2011-02-15 15:14:22', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79310, NULL, 'Chi1817Nod', '1.0', 'EntityBaseExtended', NULL, '2011-02-15 15:14:22', 'admin', 'admin', '2011-02-15 15:14:22', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79313, NULL, 'Chi1818Nod', '1.0', 'Genre', NULL, '2011-02-15 15:14:22', 'admin', 'admin', '2011-02-15 15:14:22', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79314, NULL, 'Chi1819Nod', '1.0', 'Image', NULL, '2011-02-15 15:14:23', 'admin', 'admin', '2011-02-15 15:14:23', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79316, NULL, 'Chi1820Nod', '1.0', 'Language', NULL, '2011-02-15 15:14:23', 'admin', 'admin', '2011-02-15 15:14:23', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79318, NULL, 'Chi1821Nod', '1.0', 'Movie', NULL, '2011-02-15 15:14:24', 'admin', 'admin', '2011-02-15 15:14:24', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79328, NULL, 'Chi1822Nod', '1.0', 'Person', NULL, '2011-02-15 15:14:25', 'admin', 'admin', '2011-02-15 15:14:25', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79332, NULL, 'Chi1823Nod', '1.0', 'Poster', NULL, '2011-02-15 15:14:25', 'admin', 'admin', '2011-02-15 15:14:25', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79333, NULL, 'Chi1824Nod', '1.0', 'PosterPrimary', NULL, '2011-02-15 15:14:25', 'admin', 'admin', '2011-02-15 15:14:25', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79334, NULL, 'Chi1825Nod', '1.0', 'PosterSecondary', NULL, '2011-02-15 15:14:25', 'admin', 'admin', '2011-02-15 15:14:25', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79337, NULL, 'Chi1826Nod', '1.0', 'Adodbseq', NULL, '2011-02-15 15:14:25', 'admin', 'admin', '2011-02-15 15:14:25', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79338, NULL, 'Chi1827Nod', '1.0', 'Locktable', NULL, '2011-02-15 15:14:25', 'admin', 'admin', '2011-02-15 15:14:25', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79342, NULL, 'Chi1828Nod', '1.0', 'RoleRDB', NULL, '2011-02-15 15:14:26', 'admin', 'admin', '2011-02-15 15:14:26', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79344, NULL, 'Chi1829Nod', '1.0', 'Translation', NULL, '2011-02-15 15:14:26', 'admin', 'admin', '2011-02-15 15:14:26', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79349, NULL, 'Chi1830Nod', '1.0', 'UserRDB', NULL, '2011-02-15 15:14:26', 'admin', 'admin', '2011-02-15 15:14:26', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', NULL, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(81838, NULL, 'Chi1864Nod', '1.0', 'insertANewMovieWithAPIRequest ', '?', '2011-02-16 18:00:11', 'admin', 'admin', '2011-02-28 18:39:35', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 81830, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(79644, NULL, 'Chi1845Nod', '1.0', 'Actor', '?', '2010-12-06 20:54:14', 'admin', 'admin', '2011-03-22 07:12:58', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27293', NULL, 15, '46328', 'false', NULL),
(79645, NULL, 'Chi1846Nod', '1.0', 'Date', '<span >this Class represents the Date where the movie was released.</span>', '2010-12-07 06:20:07', 'admin', 'admin', '2011-03-22 07:12:58', 'year', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27293', NULL, 13, '46328', 'false', NULL),
(79647, NULL, 'Chi1847Nod', '1.0', 'Director', 'A director is the person that cohordinates the Movie.<br><br>', '2010-12-06 20:54:17', 'admin', 'admin', '2011-03-22 07:12:58', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27293', NULL, 14, '46328', 'false', NULL),
(79648, NULL, 'Chi1848Nod', '1.0', 'EntityBase', '?', '2010-12-06 20:49:33', 'admin', 'admin', '2011-03-22 07:12:58', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27293', NULL, 12, '46328', 'true', NULL),
(79653, NULL, 'Chi1849Nod', '1.0', 'EntityBaseExtended', 'this is an abstract class with the fields name and description.', '2010-12-06 20:49:34', 'admin', 'admin', '2011-03-22 07:12:58', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27293', NULL, 7, '46328', 'true', NULL),
(79656, NULL, 'Chi1850Nod', '1.0', 'Genre', 'the genre of the Movie (e.g. "Fantasy" of "Action")', '2010-12-07 06:24:36', 'admin', 'admin', '2011-03-22 07:12:58', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27320', NULL, 5, '46328', 'false', NULL),
(79657, NULL, 'Chi1851Nod', '1.0', 'Image', 'this Class represents the abstract idea of an image.', '2010-12-06 20:58:12', 'admin', 'admin', '2011-03-22 08:04:28', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27293', NULL, 4, '46328', 'true', NULL),
(79659, NULL, 'Chi1852Nod', '1.0', 'Language', 'this Class represents the<b>original</b> language of the movie.', '2010-12-07 06:25:48', 'admin', 'admin', '2011-03-22 08:04:35', 'shortForm', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27293', NULL, 3, '46328', 'false', NULL),
(79661, NULL, 'Chi1853Nod', '1.0', 'Movie', 'A movie is a visual reppresentation made in a special date where actors play.', '2010-12-06 20:56:08', 'admin', 'admin', '2011-03-22 07:12:58', 'title|year', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27293', NULL, 2, '46328', 'false', NULL),
(79671, NULL, 'Chi1854Nod', '1.0', 'Person', 'this abstract Classrepresents any Human being present in this domain.', '2010-12-06 20:49:35', 'admin', 'admin', '2011-03-22 07:12:58', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27293', NULL, 6, '46328', 'true', NULL),
(79675, NULL, 'Chi1855Nod', '1.0', 'Poster', '<span >this Classrepresentstheabstract idea of a poster, an imagerepresentinga movie</span>', '2010-12-06 20:58:47', 'admin', 'admin', '2011-03-22 07:12:58', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27293', NULL, 8, '46328', 'false', NULL),
(79676, NULL, 'Chi1856Nod', '1.0', 'PosterPrimary', '?', '2010-12-06 20:59:07', 'admin', 'admin', '2011-03-22 07:12:58', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27293', NULL, 11, '46328', 'false', NULL),
(79677, NULL, 'Chi1857Nod', '1.0', 'PosterSecondary', '?', '2010-12-06 20:59:12', 'admin', 'admin', '2011-03-22 07:12:58', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79643, NULL, NULL, '27293', NULL, 10, '46328', 'false', NULL),
(79680, NULL, 'Chi1858Nod', '1.0', 'Adodbseq', '?', '2010-12-06 20:49:28', 'admin', 'admin', '2011-03-09 10:15:30', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79679, NULL, NULL, '27293', NULL, NULL, '46328', 'false', NULL),
(79681, NULL, 'Chi1859Nod', '1.0', 'Locktable', '?', '2010-12-06 20:49:28', 'admin', 'admin', '2011-03-09 10:15:30', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79679, 'locktable', NULL, '27293', NULL, NULL, '46328', 'false', NULL),
(79685, NULL, 'Chi1860Nod', '1.0', 'RoleRDB', '<br>', '2010-12-06 20:49:29', 'admin', 'admin', '2011-03-09 10:15:30', 'name', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79679, 'role', NULL, '27293', NULL, NULL, '46328', 'false', NULL),
(79687, NULL, 'Chi1861Nod', '1.0', 'Translation', '?', '2010-12-06 20:49:30', 'admin', 'admin', '2011-03-09 10:15:30', 'oid|attribute|language', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79679, NULL, NULL, '27293', NULL, NULL, '46328', 'false', NULL),
(79692, NULL, 'Chi1862Nod', '1.0', 'UserRDB', '<br>', '2010-12-06 20:49:31', 'admin', 'admin', '2011-03-09 10:15:30', 'login', NULL, NULL, NULL, 'false', 'none', 'false', 'database', 79679, 'user', NULL, '27293', NULL, NULL, '46328', 'false', NULL),
(86322, NULL, 'Chi2726Nod', '1.0', 'insertANewMovieWithAPIResponse', '?', '2011-02-18 14:40:04', 'admin', 'admin', '2011-03-02 12:12:41', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 81830, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(87635, NULL, 'Chi2898Nod', '1.0', 'Film', '<span >this class represent a different definition of the movie concept coming from a different domain.</span>', '2011-02-21 14:18:17', 'admin', 'admin', '2011-04-14 12:11:39', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 87621, NULL, NULL, '27293', NULL, NULL, '46328', 'false', NULL),
(96890, NULL, 'Chi3945Nod', '1.0', 'identifiedObject', '?', '2011-04-14 11:15:50', 'admin', 'admin', '2011-04-14 11:16:51', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 87621, NULL, NULL, '27293', NULL, 96890, NULL, 'false', NULL),
(96978, NULL, 'Chi3946Nod', '1.0', 'Protagonist', 'This is the object that main actor in a film', '2011-04-14 11:20:52', 'admin', 'admin', '2011-04-14 11:22:48', 'fullName', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 87621, NULL, NULL, '27293', NULL, 96978, '46328', 'false', NULL),
(94651, NULL, 'Chi3938Nod', '1.0', 'InsertNewMovieResponse', '?', '2011-03-02 12:10:48', 'admin', 'admin', '2011-03-02 12:11:05', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 82503, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(94664, NULL, 'Chi3939Nod', '1.0', 'InsertNewMovieRequest', '?', '2011-03-02 12:11:20', 'admin', 'admin', '2011-03-02 12:11:59', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 82503, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(94801, NULL, 'Chi3942Nod', '1.0', 'insertANewMovieWithnoncompilantAPIRequest', 'this class transport the domain objects coming from a certain external domain.', '2011-03-02 12:15:46', 'admin', 'admin', '2011-03-23 08:35:35', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 87621, NULL, NULL, '27293', NULL, NULL, '46333', 'false', NULL),
(94773, NULL, 'Chi3941Nod', '1.0', 'insertANewMovieWithnoncompilantAPIResponse', '?', '2011-03-02 12:15:01', 'admin', 'admin', '2011-03-02 12:15:15', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 87621, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL),
(95781, NULL, 'Chi3943Nod', '1.0', 'Request', '?', '2011-03-17 12:47:04', 'admin', 'admin', '2011-03-17 12:47:16', 'name', NULL, NULL, NULL, 'true', 'none', NULL, 'database', 95751, NULL, NULL, '27293', NULL, NULL, NULL, 'false', NULL);
