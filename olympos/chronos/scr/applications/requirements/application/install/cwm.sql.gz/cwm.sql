-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 06, 2009 at 05:58 PM
-- Server version: 5.0.67
-- PHP Version: 5.2.6-2ubuntu4.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cwm`
--

-- --------------------------------------------------------

--
-- Table structure for table `Activity`
--

CREATE TABLE IF NOT EXISTS `Activity` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) default NULL,
  `fk_activityinitial_id` int(11) default NULL,
  `fk_activityreceive_id` int(11) default NULL,
  `fk_activity_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_activityset_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_activityinitial_id` (`fk_activityinitial_id`),
  KEY `fk_activityreceive_id` (`fk_activityreceive_id`),
  KEY `fk_activity_id` (`fk_activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Activity`
--

INSERT INTO `Activity` (`id`, `fk_package_id`, `fk_activityinitial_id`, `fk_activityreceive_id`, `fk_activity_id`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `fk_activityset_id`) VALUES
(21504, NULL, 21498, NULL, NULL, 'Chi002Act', NULL, 'New Activity', NULL, '2009-03-06 17:56:54', 'admin', 'admin', '2009-03-06 17:57:00', 21489),
(18681, NULL, NULL, NULL, 18683, 'Chi024Act', NULL, 'New Activity', NULL, '2009-02-27 14:23:18', 'marco.eilers', 'marco.eilers', '2009-02-27 14:23:21', 18658),
(18683, NULL, NULL, NULL, NULL, 'Chi025Act', NULL, 'New Activity', NULL, '2009-02-27 14:23:19', 'marco.eilers', 'marco.eilers', '2009-02-27 14:23:21', 18658),
(18690, NULL, NULL, NULL, 18692, 'Chi026Act', NULL, 'New Activity', NULL, '2009-02-27 14:25:29', 'marco.eilers', 'marco.eilers', '2009-02-27 14:25:34', 18658),
(18692, NULL, NULL, NULL, NULL, 'Chi027Act', NULL, 'New Activity', NULL, '2009-02-27 14:25:29', 'marco.eilers', 'marco.eilers', '2009-02-27 14:25:34', 18658),
(18714, NULL, NULL, NULL, NULL, 'Chi028Act', NULL, 'New Activity', NULL, '2009-02-27 14:28:41', 'marco.eilers', 'marco.eilers', '2009-02-27 14:28:43', 18658),
(18731, NULL, NULL, NULL, NULL, 'Chi029Act', NULL, 'New Activity', NULL, '2009-02-27 14:32:03', 'marco.eilers', 'marco.eilers', '2009-02-27 14:32:05', 18658),
(20863, NULL, NULL, NULL, NULL, 'Chi061Act', NULL, 'He checks if it is meaningful to check up all Transmitters in the faulty Transmitter?s Subdomain', '&#160;<span lang="EN-CA"> If so, plan  \nmaintenance of whole </span><span >Subdomain on that day.</span>', '2009-03-04 16:47:47', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:48:11', 18779),
(20822, NULL, NULL, NULL, NULL, 'Chi060Act', NULL, 'For the remaining days plan maintenance of Transmitters of a whole Subdomain.', NULL, '2009-03-04 16:46:24', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:46:41', 18779),
(20793, NULL, NULL, NULL, 20822, 'Chi059Act', NULL, 'Check if there are still any single postponed or open tasks', '<span lang="EN-CA">Check if there are still any  \nsingle postponed or open tasks to be planned and organize them in a meaningful  \nway.</span> <br>', '2009-03-04 16:45:19', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:46:28', 18779);

-- --------------------------------------------------------

--
-- Table structure for table `ActivityDecision`
--

CREATE TABLE IF NOT EXISTS `ActivityDecision` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_activityset_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ActivityDecision`
--


-- --------------------------------------------------------

--
-- Table structure for table `ActivityFinal`
--

CREATE TABLE IF NOT EXISTS `ActivityFinal` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) default NULL,
  `fk_activity_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_activityset_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_activity_id` (`fk_activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ActivityFinal`
--

INSERT INTO `ActivityFinal` (`id`, `fk_package_id`, `fk_activity_id`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `fk_activityset_id`) VALUES
(21510, NULL, 21504, 'Chi002ActF', NULL, 'New ActivityFinal', NULL, '2009-03-06 17:56:57', 'admin', 'admin', '2009-03-06 17:57:03', 21489),
(18722, NULL, NULL, 'Chi010ActF', NULL, 'New ActivityFinal', NULL, '2009-02-27 14:28:55', 'marco.eilers', 'marco.eilers', '2009-02-27 14:28:59', 18658),
(18724, NULL, NULL, 'Chi011ActF', NULL, 'New ActivityFinal', NULL, '2009-02-27 14:28:59', 'marco.eilers', 'marco.eilers', '2009-02-27 14:29:03', 18658),
(18738, NULL, NULL, 'Chi012ActF', NULL, 'New ActivityFinal', NULL, '2009-02-27 14:32:21', 'marco.eilers', 'marco.eilers', '2009-02-27 14:32:23', 18658),
(18740, NULL, NULL, 'Chi013ActF', NULL, 'New ActivityFinal', NULL, '2009-02-27 14:32:26', 'marco.eilers', 'marco.eilers', '2009-02-27 14:32:31', 18658),
(18742, NULL, NULL, 'Chi014ActF', NULL, 'New ActivityFinal', NULL, '2009-02-27 14:32:34', 'marco.eilers', 'marco.eilers', '2009-02-27 14:32:35', 18658),
(18744, NULL, NULL, 'Chi015ActF', NULL, 'New ActivityFinal', NULL, '2009-02-27 14:32:38', 'marco.eilers', 'marco.eilers', '2009-02-27 14:32:42', 18658),
(18746, NULL, NULL, 'Chi016ActF', NULL, 'New ActivityFinal', NULL, '2009-02-27 14:34:10', 'marco.eilers', 'marco.eilers', '2009-02-27 14:34:12', 18658),
(18748, NULL, NULL, 'Chi017ActF', NULL, 'New ActivityFinal', NULL, '2009-02-27 14:34:16', 'marco.eilers', 'marco.eilers', '2009-02-27 14:34:18', 18658),
(18750, NULL, NULL, 'Chi018ActF', NULL, 'New ActivityFinal', NULL, '2009-02-27 14:34:29', 'marco.eilers', 'marco.eilers', '2009-02-27 14:34:33', 18658),
(20837, NULL, 20822, 'Chi047ActF', NULL, 'end', NULL, '2009-03-04 16:46:53', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:49:12', 18779);

-- --------------------------------------------------------

--
-- Table structure for table `ActivityInitial`
--

CREATE TABLE IF NOT EXISTS `ActivityInitial` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_activityset_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_package_id` (`fk_package_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ActivityInitial`
--

INSERT INTO `ActivityInitial` (`id`, `fk_package_id`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `fk_activityset_id`) VALUES
(21498, NULL, 'Chi002ActI', NULL, 'New ActivityInitial', NULL, '2009-03-06 17:56:49', 'admin', 'admin', '2009-03-06 17:56:50', 21489),
(18663, NULL, 'Chi011ActI', NULL, 'New ActivityInitial', NULL, '2009-02-27 14:16:24', 'marco.eilers', 'marco.eilers', '2009-02-27 14:16:25', 18658),
(18790, NULL, 'Chi013ActI', NULL, 'New ActivityInitial', NULL, '2009-02-27 16:40:28', 'pgiuseppe', 'pgiuseppe', '2009-02-27 16:40:30', 18779);

-- --------------------------------------------------------

--
-- Table structure for table `ActivityReceive`
--

CREATE TABLE IF NOT EXISTS `ActivityReceive` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) default NULL,
  `fk_activitysend_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_activityset_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_activitysend_id` (`fk_activitysend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ActivityReceive`
--

INSERT INTO `ActivityReceive` (`id`, `fk_package_id`, `fk_activitysend_id`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `fk_activityset_id`) VALUES
(18700, NULL, NULL, 'Chi005ActR', NULL, 'New ActivityReceive', NULL, '2009-02-27 14:28:06', 'marco.eilers', 'marco.eilers', '2009-02-27 14:28:12', 18658);

-- --------------------------------------------------------

--
-- Table structure for table `ActivitySend`
--

CREATE TABLE IF NOT EXISTS `ActivitySend` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) default NULL,
  `fk_activity_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_activityset_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_package_id` (`fk_package_id`),
  KEY `fk_activity_id` (`fk_activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ActivitySend`
--

INSERT INTO `ActivitySend` (`id`, `fk_package_id`, `fk_activity_id`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `fk_activityset_id`) VALUES
(18707, NULL, NULL, 'Chi008ActS', NULL, 'New ActivitySend', NULL, '2009-02-27 14:28:25', 'marco.eilers', 'marco.eilers', '2009-02-27 14:28:28', 18658);

-- --------------------------------------------------------

--
-- Table structure for table `ActivitySet`
--

CREATE TABLE IF NOT EXISTS `ActivitySet` (
  `id` int(11) NOT NULL,
  `fk_chibusinessusecasecore_id` int(11) default NULL,
  `fk_chibusinessusecase_id` int(11) default NULL,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_chibusinessusecasecore_id` (`fk_chibusinessusecasecore_id`),
  KEY `fk_chibusinessusecase_id` (`fk_chibusinessusecase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ActivitySet`
--

INSERT INTO `ActivitySet` (`id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `created`, `creator`, `last_editor`, `modified`) VALUES
(18292, NULL, NULL, '2009-02-26 18:27:42', 'ibm', 'ibm', '2009-02-26 18:27:43'),
(21489, NULL, 12587, '2009-03-06 17:56:20', 'admin', 'admin', '2009-03-06 17:56:36'),
(18658, 9944, NULL, '2009-02-27 14:15:52', 'marco.eilers', 'marco.eilers', '2009-02-27 14:15:54'),
(18779, 9956, NULL, '2009-02-27 16:39:37', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:42:28');

-- --------------------------------------------------------

--
-- Table structure for table `Actor`
--

CREATE TABLE IF NOT EXISTS `Actor` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Actor`
--


-- --------------------------------------------------------

--
-- Table structure for table `adodbseq`
--

CREATE TABLE IF NOT EXISTS `adodbseq` (
  `id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adodbseq`
--

INSERT INTO `adodbseq` (`id`) VALUES
(21515);

-- --------------------------------------------------------

--
-- Table structure for table `ChiAuthors`
--

CREATE TABLE IF NOT EXISTS `ChiAuthors` (
  `id` int(11) NOT NULL,
  `role` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiAuthors`
--

INSERT INTO `ChiAuthors` (`id`, `role`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`) VALUES
(53, 'Developer', 'Niko Stotz', NULL, '2008-08-26 10:51:11', 'admin', 'pgiuseppe', '2009-02-11 16:16:18'),
(13431, 'Systemarchitekt', 'Andreas Kießling', '&#160;MVV', '2009-02-11 16:26:57', 'christian', 'christian', '2009-02-11 16:27:38'),
(58, 'Architect', 'Giuseppe', NULL, '2008-08-26 10:52:18', 'admin', 'admin', '2009-01-22 12:22:50'),
(5652, 'MoMa Architect', 'Christian Schiller', NULL, '2009-01-22 16:58:39', 'pgiuseppe', 'pgiuseppe', '2009-01-22 17:01:14'),
(11231, ' ', 'F. Czicholl', NULL, '2009-02-05 15:51:03', 'marco.eilers', 'marco.eilers', '2009-02-05 16:03:43'),
(11238, ' ', 'T. Hoffmann', NULL, '2009-02-05 15:51:18', 'marco.eilers', 'marco.eilers', '2009-02-05 16:03:48'),
(11239, NULL, 'F. Merz', NULL, '2009-02-05 15:51:21', 'marco.eilers', 'marco.eilers', '2009-02-05 15:51:58'),
(11246, NULL, 'S. Gläser', NULL, '2009-02-05 15:52:13', 'marco.eilers', 'marco.eilers', '2009-02-05 15:52:19'),
(11329, NULL, 'T. Koch', NULL, '2009-02-05 16:12:55', 'marco.eilers', 'marco.eilers', '2009-02-05 16:13:04'),
(19323, 'BA Student', 'Marco Eilers', NULL, '2009-03-02 15:34:57', 'marco.eilers', 'marco.eilers', '2009-03-02 15:35:13');

-- --------------------------------------------------------

--
-- Table structure for table `ChiBase`
--

CREATE TABLE IF NOT EXISTS `ChiBase` (
  `id` int(11) NOT NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_package_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiBase`
--


-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessPartner`
--

CREATE TABLE IF NOT EXISTS `ChiBusinessPartner` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiBusinessPartner`
--


-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessPartnerActive`
--

CREATE TABLE IF NOT EXISTS `ChiBusinessPartnerActive` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_chibusinesspartneractive_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiBusinessPartnerActive`
--


-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessPartnerPassive`
--

CREATE TABLE IF NOT EXISTS `ChiBusinessPartnerPassive` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_chibusinesspartnerpassive_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiBusinessPartnerPassive`
--


-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessProcess`
--

CREATE TABLE IF NOT EXISTS `ChiBusinessProcess` (
  `id` int(11) NOT NULL,
  `fk_package_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_model_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiBusinessProcess`
--

INSERT INTO `ChiBusinessProcess` (`id`, `fk_package_id`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `fk_model_id`) VALUES
(12593, 12390, NULL, '1.0', 'my ChiBusinessProcess', NULL, '2009-02-11 12:06:59', 'pgiuseppe', 'pgiuseppe', '2009-02-11 16:07:03', NULL),
(20715, 9694, 'Chi005BPr', '1.0', 'manage time', NULL, '2009-03-04 16:37:17', 'pgiuseppe', 'admin', '2009-03-06 17:50:14', NULL),
(20723, 9694, 'Chi006BPr', '1.0', 'Order Management', NULL, '2009-03-04 16:38:32', 'pgiuseppe', 'admin', '2009-03-06 17:50:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessUseCase`
--

CREATE TABLE IF NOT EXISTS `ChiBusinessUseCase` (
  `id` int(11) NOT NULL,
  `fk_chifeature_id` int(11) default NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `primaryactor` varchar(255) default NULL,
  `otheractors` varchar(255) default NULL,
  `goalincontext` varchar(255) default NULL,
  `scope` varchar(255) default NULL,
  `level` varchar(255) default NULL,
  `stakeholders` varchar(255) default NULL,
  `precondition` varchar(255) default NULL,
  `trigger` varchar(255) default NULL,
  `mainsuccessscenario` varchar(255) default NULL,
  `extensions` varchar(255) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_package_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiBusinessUseCase`
--

INSERT INTO `ChiBusinessUseCase` (`id`, `fk_chifeature_id`, `fk_chibusinessprocess_id`, `primaryactor`, `otheractors`, `goalincontext`, `scope`, `level`, `stakeholders`, `precondition`, `trigger`, `mainsuccessscenario`, `extensions`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `fk_package_id`) VALUES
(9984, NULL, NULL, NULL, NULL, 'Update existing Transmitter manual', 'Olympos', 'RWU', 'Administrator, RM', 'Existing manual', 'Manual is outdated, new information needs to be included', 'Manual has been successfully updated', NULL, 'Use Case 1', '1.0', 'Administrator updates Manual', NULL, '2009-02-05 11:26:32', 'marco.eilers', 'marco.eilers', '2009-02-05 11:31:47', 9694),
(9991, NULL, NULL, NULL, NULL, 'Insert a new Transmitter type', 'Olympos', 'W', 'Administrator, RM', 'Existing manual', 'Non-existing transmitter has been taken under contract', 'Transmitter type has been successfully inserted', NULL, 'Use Case 2', '1.0', 'Administrator inserts Transmitter type', NULL, '2009-02-05 11:26:36', 'marco.eilers', 'marco.eilers', '2009-02-05 11:31:53', 9694),
(12587, 12570, 12593, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1.0', 'my ChiBusinessUseCase', NULL, '2009-02-11 12:06:52', 'pgiuseppe', 'pgiuseppe', '2009-02-20 16:43:05', 12148);

-- --------------------------------------------------------

--
-- Table structure for table `ChiBusinessUseCaseCore`
--

CREATE TABLE IF NOT EXISTS `ChiBusinessUseCaseCore` (
  `id` int(11) NOT NULL,
  `fk_chifeature_id` int(11) default NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `primaryactor` varchar(255) default NULL,
  `otheractors` varchar(255) default NULL,
  `goalincontext` varchar(255) default NULL,
  `scope` varchar(255) default NULL,
  `level` varchar(255) default NULL,
  `stakeholders` varchar(255) default NULL,
  `precondition` varchar(255) default NULL,
  `trigger` varchar(255) default NULL,
  `mainsuccessscenario` varchar(255) default NULL,
  `extensions` varchar(255) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_package_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiBusinessUseCaseCore`
--

INSERT INTO `ChiBusinessUseCaseCore` (`id`, `fk_chifeature_id`, `fk_chibusinessprocess_id`, `primaryactor`, `otheractors`, `goalincontext`, `scope`, `level`, `stakeholders`, `precondition`, `trigger`, `mainsuccessscenario`, `extensions`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `fk_package_id`) VALUES
(9702, NULL, NULL, NULL, 'SVNCRM, Facility Manager', 'Perform regular Transmitter Call', 'SVNcrm Dionysos', 'RWU (Schedule); W (Visit Report, Opportunity); R (Transmitter, Module, Transmitter Module, Transmitter Module Manual)', 'Customer, RM', 'Field worker available', 'Field Worker checks schedule', 'Transmitter has been successfully checked, no problems have been found', 'Field worker repairs transmitter; Field worker creates opportunity', NULL, '1.0', 'Field Worker performs Maintenance Call', NULL, '2009-02-05 10:41:31', 'marco.eilers', 'marco.eilers', '2009-02-05 10:47:16', 9694),
(9720, NULL, NULL, NULL, 'SVNCRM, facility manager, Specialist', 'Repair faulty Transmitter', NULL, 'RWU (Trouble Call, Schedule, Knowledge Base); W (Visit Report, Opportunity); R (Transmitter Site, Transmitter, Transmitter Module, Transmitter Module Manual, Customer, Transmitter History)', 'Customer, RM', 'SVNCRM online availability', 'Field Worker receives Trouble Call or checks  schedule', 'Transmitter is successfully repaired', 'Field Worker requests Specialist; Field Worker orders Repair parts (urgent); Field Worker adds an item to the Knowledge Base; Field Worker creates opportunity', NULL, '1.0', 'Field Worker repairs Transmitter', NULL, '2009-02-05 10:41:48', 'marco.eilers', 'marco.eilers', '2009-02-05 11:00:19', 9694),
(9867, NULL, NULL, '9673', 'SVNCRM, Specialist', 'Repair faulty Module', 'SVNCRM', 'RWU (Trouble Call, Schedule, Knowledge Base); W (Visit Report); R (Transmitter, Module, Manual, Visit Report, Trouble Call)', 'Customer, Technician', 'SVNCRM is available', 'Module is not working properly', 'Module is successfully repaired', 'Technician requests Specialist; Technician orders Repair parts (urgent); Technician adds an item to the Knowledge Base', NULL, '1.0', 'Technician repairs module', NULL, '2009-02-05 11:01:19', 'marco.eilers', 'admin', '2009-03-06 17:52:03', 9694),
(9920, NULL, NULL, '9474', '9679', 'Escalate task to specialist', NULL, 'RWU (Trouble Call, Schedule); W (Escalate Task)', 'Customer, RM', 'SVNCRM online availability', 'Field Worker cannot resolve an issue', 'Trouble Call is successfully escalated', NULL, NULL, '1.0', 'Field Worker requests Specialist', NULL, '2009-02-05 11:05:58', 'marco.eilers', 'admin', '2009-03-06 17:52:15', 9694),
(9926, NULL, NULL, NULL, 'SVNCRM', 'Escalate task to Specialist', NULL, 'RWU (Trouble Call, Schedule, Escalate Task); R (Transmitter Site, Transmitter, Transmitter Module, Car Stock)', 'Customer, CM', 'SVNCRM online availability', 'Allocator receives ?SVNCRM ? Escalate task?', 'Trouble Call is successfully escalated', 'Specialist stocks up at Regional Storage Center', NULL, '1.0', 'Allocator assigns escalated Trouble Call', NULL, '2009-02-05 11:08:25', 'marco.eilers', 'marco.eilers', '2009-02-05 11:09:57', 9694),
(9932, NULL, 20723, NULL, 'SVNCRM', 'Replenish Field Worker car stock', NULL, 'RWU (Car stock, RSC Stock); R (Field Worker, Regional Storage Center)', NULL, 'SVNCRM online availability', 'Field Worker needs to replenish car stock', 'Field Worker car stock successfully replenished', NULL, NULL, '1.0', 'Field Worker orders Repair parts (monthly)', NULL, '2009-02-05 11:10:34', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:39:18', 9694),
(9938, NULL, 20723, '9474', '20927', 'Replenish Field Worker car stock', NULL, 'RWU (car stock, RSC Sock); R (Field Worker, Regional Storage Center, Transmitter)', 'Customer', 'SVNCRM online availability', 'Field Worker needs repair parts urgently', 'Repair parts successfully delivered in time', 'Field Worker picks up repair parts; Courier service delivers to Transmitter Site', NULL, '1.0', 'Field Worker orders Repair parts (urgent)', NULL, '2009-02-05 11:12:43', 'marco.eilers', 'pgiuseppe', '2009-03-04 17:03:16', 9694),
(9944, NULL, NULL, NULL, 'SVNCRM, Allocator', 'Create new Trouble Call', NULL, 'RWU (Transmitter, Trouble Call); R (Customer, Support Contract)', 'Customer, Call Center Manager', 'SVNCRM online availability', 'Customer?s RM calls to state an issue', 'New Trouble Call is created', 'Trouble Call already created / Inform Customer about status', NULL, '1.0', 'Call Center Agent takes Trouble Call', NULL, '2009-02-05 11:14:20', 'marco.eilers', 'marco.eilers', '2009-02-05 11:16:54', 9694),
(9950, NULL, NULL, NULL, 'SVNCRM', 'Assign Task to Field Worker', NULL, 'RWU (Trouble Call, Schedule); R (Transmitter Site, Transmitter, Transmitter Module, Support Contract, Car Stock)', 'Customer, RM, CM', 'SVNCRM online availability', 'Allocator receives Trouble Call', 'Trouble Call is successfully assigned', 'Field Worker stocks up at Regional Storage Center; Allocator assigns escalated Trouble Call; Field Worker repairs Transmitter', NULL, '1.0', 'Allocator assigns Trouble Call', NULL, '2009-02-05 11:16:58', 'marco.eilers', 'marco.eilers', '2009-02-05 11:19:59', 9694),
(9956, 8309, 20715, '9474', 'SVNCRM', 'Organize Week', 'SVNCRM', 'RWU (Trouble Call, Schedule); R (Transmitter Site, Transmitter, Transmitter Module, Support Contract, Car Stock)', 'Management', 'SVNCRM online availability', 'Field Worker needs to plan the next week; Field Worker is assigned Trouble Call', 'Week is successfully organized', 'Field Worker orders Repair parts (monthly)', NULL, '1.0', 'Field Worker organizes Week', '<ul><li>&#160;<span lang="EN-CA">Field Worker plans ?Silver? \nTrouble Calls to be processed at least 2 days before expiration of reaction \ntime.</span></li><li><span lang="EN-CA">He checks if it is meaningful to \ncheck up all Transmitters in the faulty Transmitter?s Subdomain. If so, plan \nmaintenance of whole Subdomain on that day.</span></li><li><span lang="EN-CA">Check if there are still any \nsingle postponed or open tasks to be planned and organize them in a meaningful \nway.</span></li><li><span style="font-size: 12pt; line-height: 150%; font-family: Arial;">For the remaining days \nplan maintenance of Transmitters of a whole Subdomain.</span></li></ul> \n \n \n \n \n \n \n \n', '2009-02-05 11:17:30', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:43:41', 9694),
(9961, NULL, NULL, NULL, 'SVNCRM, facility manager', 'Repair faulty Transmitter', NULL, 'RWU (Trouble Call, Schedule, Knowledge Base); W (Visit Report, Opportunity); R (Transmitter Site, Transmitter, Transmitter Module, Transmitter Module Manual, Customer, Transmitter History)', 'Customer, CM', 'SVNCRM online availability', 'Specialist receives Trouble Call or checks schedule', 'Transmitter is successfully repaired', 'Specialist orders Repair parts (urgent); Specialist adds an item to the Knowledge Base; Specialist creates opportunity', NULL, '1.0', 'Specialist repairs Transmitter', NULL, '2009-02-05 11:17:32', 'marco.eilers', 'marco.eilers', '2009-02-05 11:24:23', 9694);

-- --------------------------------------------------------

--
-- Table structure for table `ChiController`
--

CREATE TABLE IF NOT EXISTS `ChiController` (
  `id` int(11) NOT NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_package_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiController`
--


-- --------------------------------------------------------

--
-- Table structure for table `ChiFeature`
--

CREATE TABLE IF NOT EXISTS `ChiFeature` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `author` varchar(255) default NULL,
  `proofreader` varchar(255) default NULL,
  `status` varchar(255) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiFeature`
--

INSERT INTO `ChiFeature` (`id`, `fk_chibusinessprocess_id`, `fk_package_id`, `author`, `proofreader`, `status`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`) VALUES
(8834, NULL, 7652, '11231', '11238', '70', 'ChiFeat002', '1.0', 'UMTS / GPRS internet connection will be provided', '    \n<p>Each    \nUMPC&#160;will&#160;have&#160;a&#160;UMTS&#160;card&#160;put&#160;into    \nan&#160;available&#160;PCMCIA&#160;slot.&#160;An&#160;external    \nantenna&#160;will&#160;be&#160;supplied&#160;which&#160;can&#160;be    \nused&#160;to&#160;improve&#160;signal&#160;strength&#160;in&#160;areas    \nwith&#160;low&#160;UMTS&#160;coverage.&#160;Each&#160;UMTS&#160;card    \nwill&#160;be&#160;covered&#160;under&#160;a&#160;framework&#160;agreement    \nflat&#160;rate&#160;tariff.&#160;The&#160;card&#160;automatically    \nselects&#160;the&#160;best&#160;network&#160;and&#160;will&#160;fall    \nback&#160;to&#160;the&#160;GRPS-system&#160;if&#160;no&#160;UMTS    \ncoverage&#160;is&#160;present.</p><p>UMTS    \navailability&#160;is&#160;estimated&#160;to&#160;an&#160;extent&#160;of    \n80%&#160;in&#160;the&#160;field?s&#160;area.&#160;Settings&#160;will    \nbe&#160;customized&#160;so&#160;that&#160;an&#160;automatic&#160;reconnect    \noccurs&#160;if&#160;a&#160;connection&#160;is&#160;lost.</p>', '2009-02-04 14:19:58', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:56:03'),
(8309, NULL, 7652, '11231', 'aName, Client', '11382', 'ChiFeat001', '1.0', 'Each field worker will be equipped with a UMPC', '     \n<p style="margin-left: 0.04in; margin-top: 0.06in; margin-bottom: 0.04in; line-height: 100%;" lang="en-CA"><font style="font-size: 9pt;" size="2">Each     \nfield&nbsp;worker&nbsp;will&nbsp;be&nbsp;equipped&nbsp;with&nbsp;a     \nUMPC.&nbsp;900/1000&nbsp;MHz&nbsp;CPU,&nbsp;512MB&nbsp;RAM,&nbsp;running     \nWindowsXP.&nbsp;The&nbsp;settings&nbsp;will&nbsp;be&nbsp;configured     \nto&nbsp;minimize&nbsp;graphical&nbsp;features&nbsp;and&nbsp;optimize     \nperformance.</font></p><p style="margin-left: 0.04in; margin-top: 0.06in; margin-bottom: 0.04in; line-height: 100%;" lang="en-CA"><font style="font-size: 9pt;" size="2">Each     \nUMPC&nbsp;will&nbsp;have&nbsp;Firefox&nbsp;2.0.0.2&nbsp;installed,&nbsp;as     \na&nbsp;lightweight&nbsp;but&nbsp;secure&nbsp;web-browser&nbsp;that     \nupdates&nbsp;itself&nbsp;automatically&nbsp;should&nbsp;security     \nfixes&nbsp;be&nbsp;available.</font></p><p style="margin-top: 0in; margin-bottom: 0in;"><br>     \n</p>', '2009-02-04 12:12:46', 'marco.eilers', 'marco.eilers', '2009-02-05 16:37:23'),
(8840, NULL, 7652, '5652', '58', '67', 'ChiFeat003', '1.0', 'Encrypted VPN connection to intranet will be realized', '      \n<p style="margin-left: 0.04in; margin-top: 0.06in; margin-bottom: 0.04in; line-height: 100%;" lang="en-CA"><font style="font-size: 9pt;" size="2">When      \nconnected&nbsp;to&nbsp;the&nbsp;internet,&nbsp;the&nbsp;UMPC&nbsp;will      \nestablish&nbsp;an&nbsp;encrypted&nbsp;VPN&nbsp;tunnelling&nbsp;connection      \nto&nbsp;EUROCOM?s&nbsp;intranet,&nbsp;granting&nbsp;access&nbsp;to      \nlive&nbsp;data.</font></p><p style="margin-left: 0.04in; margin-top: 0.06in; margin-bottom: 0.04in; line-height: 100%;" lang="en-CA"><font style="font-size: 9pt;" size="2">The      \nencryption&nbsp;method&nbsp;used&nbsp;will&nbsp;be&nbsp;IPSec.</font></p><p style="margin-left: 0.04in; margin-top: 0.06in; margin-bottom: 0.04in; line-height: 100%;" lang="en-CA"><font style="font-size: 9pt;" size="2">Settings      \nwill&nbsp;be&nbsp;customized&nbsp;so&nbsp;that&nbsp;an&nbsp;automatic      \nreconnect&nbsp;occurs&nbsp;if&nbsp;a&nbsp;connection&nbsp;is&nbsp;lost      \nand&nbsp;internet&nbsp;connection&nbsp;was&nbsp;re-established.</font></p>', '2009-02-04 14:20:51', 'marco.eilers', 'marco.eilers', '2009-02-05 12:34:15'),
(8850, NULL, 7652, '11231', ', ', '11382', 'ChiFeat004', '1.0', 'SVNCRM will be implemented', '        \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">SVNCRM        \nwill&nbsp;be&nbsp;implemented&nbsp;and&nbsp;customized&nbsp;to&nbsp;fit        \nEUROCOM?s&nbsp;needs&nbsp;and&nbsp;work&nbsp;according&nbsp;to        \ntheir&nbsp;business&nbsp;processes.&nbsp;SVNCRM&nbsp;will&nbsp;consist        \nof&nbsp;the&nbsp;Chronos&nbsp;business&nbsp;model,&nbsp;an&nbsp;Aphrodite        \nserver&nbsp;and&nbsp;Dionysos&nbsp;clients.<br>SVNCRM        \nis&nbsp;an&nbsp;open&nbsp;source&nbsp;CRM&nbsp;system&nbsp;similar&nbsp;to        \nSugarCRM&nbsp;that&nbsp;is&nbsp;based&nbsp;on&nbsp;an&nbsp;MDA-approach.        \nBased&nbsp;on&nbsp;a&nbsp;UML&nbsp;business&nbsp;process&nbsp;model        \nthe&nbsp;application&nbsp;is&nbsp;generated&nbsp;and&nbsp;therefore        \nflexible&nbsp;to&nbsp;changes&nbsp;within&nbsp;the&nbsp;model&nbsp;and        \nthe&nbsp;business&nbsp;operation&nbsp;structure.</font></p><p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">SVNCRM        \nwill&nbsp;implement&nbsp;a&nbsp;dashboard&nbsp;as&nbsp;a&nbsp;?homepage?        \nin&nbsp;SVNCRM&nbsp;that&nbsp;lists&nbsp;the&nbsp;most&nbsp;frequent        \nactions&nbsp;and&nbsp;objects&nbsp;accessed&nbsp;by&nbsp;a&nbsp;worker.        \nDashboards&nbsp;vary&nbsp;according&nbsp;to&nbsp;roles&nbsp;of        \nworkers&nbsp;who&nbsp;access&nbsp;SVNCRM.&nbsp;Different&nbsp;dashboards        \nwill&nbsp;be&nbsp;implemented&nbsp;for&nbsp;the&nbsp;roles&nbsp;Field        \nWorker,&nbsp;Call&nbsp;Center&nbsp;Agent&nbsp;and&nbsp;System        \nAdministrator.</font>        \n</p>', '2009-02-04 14:21:42', 'marco.eilers', 'marco.eilers', '2009-02-05 16:41:50'),
(8855, NULL, 7652, '11231', 'aName, Client', NULL, 'ChiFeat005', '1.0', 'Up-to-date manuals will be accessible via UMPC', '      \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">Field      \nworkers&nbsp;will&nbsp;be&nbsp;able&nbsp;to&nbsp;access&nbsp;manuals      \nfrom&nbsp;EUROCOM?s&nbsp;central&nbsp;servers&nbsp;via&nbsp;VPN.<br>Manuals      \nwill&nbsp;be&nbsp;stored&nbsp;on&nbsp;a&nbsp;central&nbsp;file&nbsp;server      \nmanaged&nbsp;by&nbsp;a&nbsp;versioning&nbsp;system&nbsp;(SVN-subversion)      \nalways&nbsp;providing&nbsp;the&nbsp;most&nbsp;recent&nbsp;version&nbsp;to      \na&nbsp;transmitter?s&nbsp;manual&nbsp;when&nbsp;a&nbsp;static&nbsp;link      \nwill&nbsp;be&nbsp;accessed.&nbsp;Old&nbsp;versions&nbsp;of&nbsp;a      \nmanual&nbsp;will&nbsp;be&nbsp;kept&nbsp;and&nbsp;stored&nbsp;for      \nversioning&nbsp;reasons,&nbsp;tracking&nbsp;document&nbsp;history.</font>      \n</p>', '2009-02-04 14:21:45', 'marco.eilers', 'marco.eilers', '2009-02-05 16:35:45'),
(8861, NULL, 7652, '11231', 'aName, Client', '70', 'ChiFeat006', '1.0', 'Task management will be updated in real-time', '      \n<p style="margin-left: 0.04in; margin-top: 0.06in; margin-bottom: 0.04in; line-height: 100%;" lang="en-CA">      \n</p><p style="margin-left: 0.04in; margin-top: 0.06in; margin-bottom: 0.04in; line-height: 100%;" lang="en-CA"><font style="font-size: 9pt;" size="2">Tasks      \ncan&nbsp;be&nbsp;updated&nbsp;dynamically&nbsp;in&nbsp;real-time.      \nThere&nbsp;no&nbsp;longer&nbsp;is&nbsp;a&nbsp;deadline&nbsp;after      \nwhich&nbsp;incoming&nbsp;tasks&nbsp;cannot&nbsp;be&nbsp;regarded.      \nIncoming&nbsp;Trouble&nbsp;Calls&nbsp;may&nbsp;supersede&nbsp;currently      \npending&nbsp;tasks.</font></p>', '2009-02-04 14:21:46', 'marco.eilers', 'marco.eilers', '2009-02-05 16:36:13'),
(8878, NULL, 7652, '11231', 'aName, Client', '11382', 'ChiFeat007', '1.0', 'Trouble Calls will be assigned instantly', '   \n<p style="margin-left: 0.04in; margin-top: 0.06in; margin-bottom: 0.04in; line-height: 100%;" lang="en-CA"><font style="font-size: 9pt;" size="2">Trouble   \nCalls&nbsp;will&nbsp;be&nbsp;assigned&nbsp;instantly&nbsp;via&nbsp;a   \nPush-technique&nbsp;and&nbsp;be&nbsp;displayed&nbsp;on&nbsp;a&nbsp;chosen   \nfield&nbsp;worker?s&nbsp;UMPC.&nbsp;The&nbsp;worker&nbsp;will&nbsp;then   \nbe&nbsp;given&nbsp;the&nbsp;possibility&nbsp;to&nbsp;decide&nbsp;whether   \nhe&nbsp;wants&nbsp;to&nbsp;accept&nbsp;the&nbsp;activity&nbsp;or   \ndecline&nbsp;it,&nbsp;stating&nbsp;a&nbsp;reason&nbsp;for&nbsp;the   \ndecline.</font></p>', '2009-02-04 14:24:05', 'marco.eilers', 'marco.eilers', '2009-02-06 11:00:15'),
(8885, NULL, 7652, '11231', 'aName, Client', '11382', 'ChiFeat008', '1.0', 'Docking stations will be placed inside of workers'' cars', '        \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">Docking        \nstations&nbsp;for&nbsp;the&nbsp;UMPCs&nbsp;will&nbsp;be&nbsp;placed        \ninside&nbsp;of&nbsp;the&nbsp;workers'' cars,&nbsp;providing&nbsp;a        \npossibility&nbsp;to&nbsp;recharge&nbsp;the&nbsp;battery&nbsp;that&nbsp;is        \npowering&nbsp;the&nbsp;UMPC&nbsp;while&nbsp;at&nbsp;a&nbsp;customer''s        \nsite.</font>        \n</p>', '2009-02-04 14:24:09', 'marco.eilers', 'marco.eilers', '2009-02-06 11:00:36'),
(8886, NULL, 7652, '11231', ', ', '11382', 'ChiFeat009', '1.0', 'Known-issues database will be realized', '       \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">A       \nnew&nbsp;database&nbsp;will&nbsp;be&nbsp;set&nbsp;up&nbsp;on&nbsp;a       \ncentral&nbsp;server.&nbsp;This&nbsp;database&nbsp;will&nbsp;be       \naccessible&nbsp;via&nbsp;VPN&nbsp;dial-in&nbsp;and&nbsp;provide       \ninformation&nbsp;about&nbsp;known&nbsp;issues&nbsp;to&nbsp;transmitters.       \nEntries&nbsp;and&nbsp;contributions&nbsp;to&nbsp;this&nbsp;database       \nmay&nbsp;be&nbsp;done&nbsp;from&nbsp;within&nbsp;the&nbsp;field&nbsp;by       \nfield&nbsp;workers&nbsp;as&nbsp;well&nbsp;as&nbsp;by&nbsp;internal       \nworkers.&nbsp;The&nbsp;database&nbsp;will&nbsp;provide&nbsp;a&nbsp;search       \nfunction&nbsp;and&nbsp;will&nbsp;be&nbsp;able&nbsp;to&nbsp;display       \nentries&nbsp;sorted&nbsp;by&nbsp;transmitter&nbsp;type.</font>       \n</p>', '2009-02-04 14:24:10', 'marco.eilers', 'marco.eilers', '2009-02-06 11:00:59'),
(8902, NULL, 7652, '11231', 'aName, Client', '64', 'ChiFeat010', '1.0', 'Dynamic Travelling salesman optimization of activities may be realized', '      \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">Dynamic      \nTravelling&nbsp;salesman&nbsp;optimization&nbsp;is&nbsp;indented&nbsp;to      \nbe&nbsp;implemented.</font>      \n</p>', '2009-02-04 14:25:35', 'marco.eilers', 'marco.eilers', '2009-02-06 11:01:10'),
(8909, NULL, 7652, '11231', 'aName, Client', '11382', 'ChiFeat011', '1.0', 'SVNCRM will have a read-only interface to existing ERP-system', '      \n<p style="margin-top: 0in; margin-bottom: 0in;">    \n</p><p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">SVNCRM    \nwill&nbsp;have&nbsp;a&nbsp;read-only&nbsp;interface&nbsp;to&nbsp;existing    \nERP-system.</font>    \n</p>', '2009-02-04 14:25:37', 'marco.eilers', 'marco.eilers', '2009-02-06 11:01:33'),
(12570, NULL, 12126, 'myName, Analyst', 'aName, Client', NULL, NULL, '1.0', 'My ChiFeature', NULL, '2009-02-11 11:52:15', 'pgiuseppe', 'pgiuseppe', '2009-02-11 12:00:40');

-- --------------------------------------------------------

--
-- Table structure for table `ChiFeatureStatus`
--

CREATE TABLE IF NOT EXISTS `ChiFeatureStatus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiFeatureStatus`
--

INSERT INTO `ChiFeatureStatus` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`) VALUES
(64, 'Proposed', NULL, '2008-08-26 10:56:05', 'admin', 'admin', '2008-08-26 10:56:25'),
(67, 'under review', NULL, '2008-08-26 10:56:32', 'admin', 'admin', '2008-08-26 10:56:47'),
(70, 'Approved', NULL, '2008-08-26 10:56:54', 'admin', 'admin', '2008-08-26 10:57:06'),
(3633, 'mandatory', NULL, '2009-01-06 15:53:13', 'admin', 'admin', '2009-01-13 13:40:59'),
(11382, 'tbd', NULL, '2009-02-05 16:36:43', 'marco.eilers', 'marco.eilers', '2009-02-05 16:36:50');

-- --------------------------------------------------------

--
-- Table structure for table `ChiGoal`
--

CREATE TABLE IF NOT EXISTS `ChiGoal` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `fk_chigoal_id` int(11) default NULL,
  `priority` varchar(255) default NULL,
  `value_name` varchar(255) default NULL,
  `value_ammount` varchar(255) default NULL,
  `value_goal` varchar(255) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `goaltype` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiGoal`
--

INSERT INTO `ChiGoal` (`id`, `fk_chibusinessprocess_id`, `fk_package_id`, `fk_chigoal_id`, `priority`, `value_name`, `value_ammount`, `value_goal`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `goaltype`) VALUES
(7707, NULL, 7673, 21060, '50', 'Customer Satisfaction', 'dsfsdfdsf', '60', 'ChiGoal01', '1.0', 'Improve customer satisfaction', 'Improve percentage of ''satisfied'' or ''very satisfied'' customers by 10%', '2009-02-04 10:34:08', 'marco.eilers', 'admin', '2009-03-06 11:32:52', '5530'),
(7735, NULL, 7673, NULL, '50', 'Travel Costs', NULL, '-5%', 'ChiGoal02', '1.0', 'Reduce Travel costs', 'Reduce average travel costs by 5%', '2009-02-04 10:41:48', 'marco.eilers', 'marco.eilers', '2009-02-06 10:57:36', '9421'),
(7763, NULL, 7673, 21060, '50', 'Effectiveness in %', 'fdsgdfgfd', '5', 'ChiGoal03', '1.0', 'Increase ''Activities per Field Worker per Day'' ratio', 'Increase ''Activities per Field Worker per Day'' ratio by 5<br> ', '2009-02-04 10:47:30', 'marco.eilers', 'admin', '2009-03-06 11:49:10', '5532'),
(7774, NULL, 7673, 21060, '50', 'Cost reduction', '61,50', '-3 EUR/task', 'ChiGoal04', '1.0', 'Reduce costs per task', 'Reduce costs per task from 61,50 to below 58,50 EUR', '2009-02-04 10:49:08', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:20:35', '9421'),
(7792, NULL, 7673, 21060, '50', 'Reaction time in day  reduction', '40', '35', 'ChiGoal06', '1.0', 'Reduce reaction time', 'The reaction time to incoming Trouble&#160;Calls&#160;must be&#160; reduced.&#160;in&#160;order&#160;to&#160;increase&#160;customer        \nsatisfaction&#160;and&#160;offer&#160;a&#160;competitive&#160;advantage        \nto&#160;stand&#160;out&#160;from&#160;the&#160;crowd&#160;of        \ncompetitors&#160;in&#160;the&#160;field.<p><br>        \n</p>', '2009-02-04 10:51:14', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:32:54', '9421'),
(7785, NULL, 7673, 21060, '50', '''Closed tasks per activity''', NULL, 'Increase by 6%', 'ChiGoal05', '1.0', 'Increase ''closed tasks per activity'' ratio', 'Increase number of&#160;tasks&#160;put&#160;into&#160;status ''closed''         \nafter performing an&#160;activity&#160;on&#160;site.<p><br>         \n</p>', '2009-02-04 10:51:08', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:20:41', '9421'),
(21060, NULL, 7673, 7763, NULL, NULL, NULL, NULL, 'Chi035Goa', NULL, 'Gain market share by winning contracts for newly erected transmitter generations', NULL, '2009-03-05 13:29:16', 'pgiuseppe', 'pgiuseppe', '2009-03-05 14:20:18', '5534'),
(12366, NULL, 12099, NULL, NULL, NULL, NULL, NULL, NULL, '01', 'project Mission', ' \n	 \n	 \n<p>the project \nmission is the <b>root </b>of the whole project.  \n</p> \n<p>Describe in \na very abstract level what you intend to realize.<br></p> \n', '2009-02-10 18:40:13', 'pgiuseppe', 'pgiuseppe', '2009-02-10 18:42:42', '5536'),
(21071, NULL, 7673, 21060, NULL, NULL, NULL, NULL, 'Chi036Goa', NULL, 'Constantly providing high-quality services for our partners in the mobile telecommunications sector', NULL, '2009-03-05 13:29:50', 'pgiuseppe', 'pgiuseppe', '2009-03-05 14:16:39', '5536');

-- --------------------------------------------------------

--
-- Table structure for table `ChiGoalType`
--

CREATE TABLE IF NOT EXISTS `ChiGoalType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiGoalType`
--

INSERT INTO `ChiGoalType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`) VALUES
(5530, 'Strategic', NULL, '2009-01-22 16:22:48', 'pgiuseppe', 'pgiuseppe', '2009-01-22 16:22:58'),
(5532, 'Business', NULL, '2009-01-22 16:23:00', 'pgiuseppe', 'pgiuseppe', '2009-01-22 16:23:11'),
(5534, 'Vision', NULL, '2009-01-22 16:23:12', 'pgiuseppe', 'pgiuseppe', '2009-01-22 16:23:23'),
(5536, 'Mission', NULL, '2009-01-22 16:23:24', 'pgiuseppe', 'pgiuseppe', '2009-01-22 16:23:33'),
(5538, 'Scenario', NULL, '2009-01-22 16:23:41', 'pgiuseppe', 'pgiuseppe', '2009-01-22 16:23:48'),
(9421, 'Operational', NULL, '2009-02-04 15:20:49', 'pgiuseppe', 'marco.eilers', '2009-02-06 10:57:09');

-- --------------------------------------------------------

--
-- Table structure for table `ChiIssue`
--

CREATE TABLE IF NOT EXISTS `ChiIssue` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `fk_chirequirement_id` int(11) default NULL,
  `author` varchar(255) default NULL,
  `responsible` varchar(255) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiIssue`
--

INSERT INTO `ChiIssue` (`id`, `fk_chibusinessprocess_id`, `fk_package_id`, `fk_chirequirement_id`, `author`, `responsible`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`) VALUES
(12577, NULL, 12138, 12419, NULL, 'none', NULL, '1.0', 'My ChiIssue', NULL, '2009-02-11 11:52:23', 'pgiuseppe', 'pgiuseppe', '2009-02-11 12:00:32'),
(8151, NULL, 8143, 7888, NULL, 'none', 'ChiIss001', '1.0', 'Currently no optimal task distribution', NULL, '2009-02-04 11:43:55', 'marco.eilers', 'marco.eilers', '2009-02-05 13:53:19'),
(8157, NULL, 8143, 7888, NULL, 'none', 'ChiIss002', '1.0', 'Currently faxes used for task distribution and coordination', NULL, '2009-02-04 11:44:01', 'marco.eilers', 'marco.eilers', '2009-02-05 13:53:45'),
(8163, NULL, 8143, 7888, NULL, 'none', 'ChiIss003', '1.0', 'Currently task lists are rather inflexible', NULL, '2009-02-04 11:44:04', 'marco.eilers', 'marco.eilers', '2009-02-05 13:54:56');

-- --------------------------------------------------------

--
-- Table structure for table `ChiNode`
--

CREATE TABLE IF NOT EXISTS `ChiNode` (
  `id` int(11) NOT NULL,
  `fk_chicontroller_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `display_value` varchar(255) default NULL,
  `parent_order` varchar(255) default NULL,
  `child_order` varchar(255) default NULL,
  `pk_name` varchar(255) default NULL,
  `is_searchable` varchar(255) default NULL,
  `orderby` varchar(255) default NULL,
  `is_soap` varchar(255) default NULL,
  `initparams` varchar(255) default NULL,
  `fk_package_id` int(11) default NULL,
  `table_name` varchar(255) default NULL,
  `is_ordered` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiNode`
--


-- --------------------------------------------------------

--
-- Table structure for table `ChiRequirement`
--

CREATE TABLE IF NOT EXISTS `ChiRequirement` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_chigoal_id` int(11) default NULL,
  `fk_chirequirement_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `reqtype` varchar(255) default NULL,
  `priority` varchar(255) default NULL,
  `author` varchar(255) default NULL,
  `proofreader` varchar(255) default NULL,
  `status` varchar(255) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiRequirement`
--

INSERT INTO `ChiRequirement` (`id`, `fk_chibusinessprocess_id`, `fk_chigoal_id`, `fk_chirequirement_id`, `fk_package_id`, `reqtype`, `priority`, `author`, `proofreader`, `status`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`) VALUES
(7858, NULL, 7707, 7944, 7653, '4116', '100', 'Niko - Developer', '11231', 'Mandatory', 'ChiReq002', '1.0', 'Provide field workers with mobile device', '<font style="font-size: 9pt;" size="2">Provide               \nfield&nbsp;workers&nbsp;with&nbsp;a&nbsp;device&nbsp;that&nbsp;enables               \nthe&nbsp;access&nbsp;to&nbsp;data&nbsp;like&nbsp;manuals&nbsp;and               \ntask&nbsp;overviews.&nbsp;Access&nbsp;to&nbsp;live&nbsp;data&nbsp;must               \nbe&nbsp;realized;&nbsp;therefore&nbsp;a&nbsp;connection&nbsp;to&nbsp;a               \ncentral&nbsp;server&nbsp;must&nbsp;be&nbsp;established.</font>               \n', '2009-02-04 11:01:47', 'marco.eilers', 'marco.eilers', '2009-02-05 15:53:36'),
(7864, NULL, 7763, NULL, 7653, '4116', '100', '11239', '11231', '11255', 'ChiReq003', '1.0', 'A new CRM system must be implemented', '<font style="font-size: 9pt;" size="2">Implement              \na&nbsp;new&nbsp;CRM&nbsp;system&nbsp;that&nbsp;allows&nbsp;the              \nmanagement&nbsp;of&nbsp;current&nbsp;customers,&nbsp;tasks,&nbsp;contracts              \nand&nbsp;employees.&nbsp;The&nbsp;CRM&nbsp;system&nbsp;should&nbsp;include              \ninterfaces&nbsp;for&nbsp;internal&nbsp;workers&nbsp;as&nbsp;well&nbsp;as              \nexternal&nbsp;workers&nbsp;and&nbsp;administrators.&nbsp;The&nbsp;CRM              \nsystem&nbsp;is&nbsp;to&nbsp;manage&nbsp;business&nbsp;tasks,              \nactivities,&nbsp;customers,&nbsp;transmitters&nbsp;and&nbsp;employees.</font>              \n', '2009-02-04 11:01:52', 'marco.eilers', 'marco.eilers', '2009-02-05 16:00:20'),
(7870, NULL, 7774, 7858, 7653, '4116', '100', '11238', '11231', '11255', 'ChiReq004', '1.0', 'Display assigned tasks on mobile device', '           \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">Display           \na&nbsp;worker?s&nbsp;assigned&nbsp;and&nbsp;pending&nbsp;tasks&nbsp;on           \nthe&nbsp;mobile&nbsp;device&nbsp;in&nbsp;a&nbsp;clearly&nbsp;arranged           \nand&nbsp;comprehensible&nbsp;way.&nbsp;Provide&nbsp;an&nbsp;overview           \nof&nbsp;To-Dos&nbsp;and&nbsp;support&nbsp;field&nbsp;workers&nbsp;in           \nmanaging&nbsp;pending&nbsp;workload.</font>           \n</p>', '2009-02-04 11:01:57', 'marco.eilers', 'marco.eilers', '2009-02-05 16:00:45'),
(7876, NULL, 7707, 8016, 7653, '4116', '50', '11238', '11231', '11255', 'ChiReq005', '1.0', 'Manage task information on mobile device', '<font style="font-size: 9pt;" size="2">Provide         \nan&nbsp;option&nbsp;to&nbsp;field&nbsp;workers&nbsp;to&nbsp;view&nbsp;and         \nedit&nbsp;own&nbsp;tasks.&nbsp;Field&nbsp;workers&nbsp;must&nbsp;be         \nable&nbsp;to&nbsp;enter&nbsp;information&nbsp;about&nbsp;a&nbsp;just         \nprocessed&nbsp;task&nbsp;and&nbsp;attach&nbsp;this&nbsp;information         \nto&nbsp;the&nbsp;task,&nbsp;contract,&nbsp;customer&nbsp;or         \ntransmitter.</font>         \n', '2009-02-04 11:02:01', 'marco.eilers', 'marco.eilers', '2009-02-05 16:01:49'),
(7882, NULL, NULL, NULL, 7653, '4116', '50', '11238', '11231', '11255', 'ChiReq006', '1.0', 'Display transmitter manual on mobile device', '        \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">Display        \na&nbsp;requested&nbsp;transmitter&nbsp;manual&nbsp;on&nbsp;the&nbsp;mobile        \ndevice,&nbsp;providing&nbsp;the&nbsp;field&nbsp;worker&nbsp;with        \nimportant&nbsp;technical&nbsp;data&nbsp;needed&nbsp;to&nbsp;maintain        \nor&nbsp;repair&nbsp;a&nbsp;specific&nbsp;transmitter&nbsp;model.&nbsp;The        \nmanual&nbsp;should&nbsp;be&nbsp;readable&nbsp;with&nbsp;no&nbsp;major        \nconstraints&nbsp;in&nbsp;comparison&nbsp;to&nbsp;a&nbsp;paper&nbsp;manual.        \nA&nbsp;search&nbsp;function,&nbsp;dynamically&nbsp;linked&nbsp;table        \nof&nbsp;contents&nbsp;and&nbsp;index&nbsp;should&nbsp;be&nbsp;provided.</font><br>        \n</p>', '2009-02-04 11:02:05', 'marco.eilers', 'marco.eilers', '2009-02-05 16:02:22'),
(7888, NULL, 7735, 8520, 7653, '4116', '100', '11246', '11231', '11278', 'ChiReq007', '1.0', 'Trouble Calls must be assigned instantly', '       \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">Trouble       \nCalls&nbsp;must&nbsp;be&nbsp;assigned&nbsp;instantly&nbsp;after&nbsp;they       \nare&nbsp;created&nbsp;upon&nbsp;receiving&nbsp;a&nbsp;trouble&nbsp;call       \nby&nbsp;a&nbsp;customer&nbsp;so&nbsp;that&nbsp;processing&nbsp;can&nbsp;be       \nspeeded&nbsp;up&nbsp;in&nbsp;comparison&nbsp;to&nbsp;current       \nstandards.&nbsp;It&nbsp;is&nbsp;intended&nbsp;to&nbsp;provide&nbsp;a       \nfast&nbsp;response&nbsp;time&nbsp;to&nbsp;customers?&nbsp;problems       \nin&nbsp;order&nbsp;to&nbsp;increase&nbsp;customer&nbsp;satisfaction       \nand&nbsp;retention.</font><br><br>       \n</p>', '2009-02-04 11:02:10', 'marco.eilers', 'marco.eilers', '2009-02-05 16:03:59'),
(7894, NULL, NULL, 7876, 7653, '4116', '50', '11238', '11231', '11255', 'ChiReq008', '1.0', 'Display pending activities on mobile device', '       \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">Display       \na&nbsp;worker''s&nbsp;pending&nbsp;activities&nbsp;on&nbsp;the       \nmobile&nbsp;device&nbsp;in&nbsp;a&nbsp;clearly&nbsp;arranged&nbsp;and       \ncomprehensible&nbsp;way.&nbsp;Replace&nbsp;manual&nbsp;activity       \nmanagement&nbsp;by&nbsp;computer-aided&nbsp;methods.</font>       \n</p>', '2009-02-04 11:02:15', 'marco.eilers', 'marco.eilers', '2009-02-05 16:04:47'),
(7900, NULL, NULL, NULL, 7653, '4116', '50', '11238', ', ', '745', 'ChiReq009', '1.0', 'Manage transmitter issues on mobile device', '        \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">Provide        \nan&nbsp;option&nbsp;to&nbsp;view,&nbsp;edit,&nbsp;create&nbsp;and        \ndelete&nbsp;information&nbsp;about&nbsp;issues&nbsp;to&nbsp;a&nbsp;type        \nof&nbsp;transmitter.&nbsp;The&nbsp;idea&nbsp;behind&nbsp;this        \nrequirement&nbsp;is&nbsp;to&nbsp;distribute&nbsp;knowledge&nbsp;and        \nknown&nbsp;issues&nbsp;that&nbsp;a&nbsp;field&nbsp;worker&nbsp;has        \nencountered&nbsp;several&nbsp;times&nbsp;before&nbsp;to&nbsp;other        \ncolleagues,&nbsp;providing&nbsp;hints&nbsp;to&nbsp;solving&nbsp;a        \nfairly&nbsp;rare&nbsp;issue.</font><br>        \n</p>', '2009-02-04 11:02:21', 'marco.eilers', 'marco.eilers', '2009-02-05 16:05:26'),
(7932, NULL, 7735, NULL, 7653, '4116', '50', '11246', '11231', NULL, 'ChiReq010', '1.0', 'Travel connections in task and trouble management should be optimized', '<font style="font-size: 9pt;" size="2">Travelling          \nsalesman&nbsp;optimization&nbsp;of&nbsp;the&nbsp;pending&nbsp;tasks          \nof&nbsp;field&nbsp;workers.&nbsp;Tasks&nbsp;should&nbsp;be          \ndistributed&nbsp;in&nbsp;an&nbsp;optimal&nbsp;way&nbsp;so&nbsp;that          \ntravel&nbsp;connections&nbsp;are&nbsp;optimized&nbsp;and&nbsp;the          \nmaximum&nbsp;amount&nbsp;of&nbsp;transmitters&nbsp;per&nbsp;day&nbsp;can          \nbe&nbsp;processed.</font>          \n', '2009-02-04 11:13:31', 'marco.eilers', 'marco.eilers', '2009-02-05 16:05:58'),
(7938, NULL, NULL, NULL, 7653, '107', '50', '11239', '11231', NULL, 'ChiReq011', '1.0', 'Mobile device usability should be assured', '<font style="font-size: 9pt;" size="2">Working          \nwith&nbsp;the&nbsp;mobile&nbsp;device&nbsp;should&nbsp;be&nbsp;easy,          \nstraight-forward&nbsp;and&nbsp;fast.&nbsp;Well-known&nbsp;software          \nstandards&nbsp;are&nbsp;to&nbsp;be&nbsp;implemented&nbsp;and&nbsp;an          \nintuitive&nbsp;use&nbsp;of&nbsp;the&nbsp;system&nbsp;should&nbsp;be          \npossible.&nbsp;The&nbsp;device&nbsp;should&nbsp;be&nbsp;resistant&nbsp;to          \nerrors&nbsp;and&nbsp;fast&nbsp;in&nbsp;response&nbsp;to&nbsp;user          \ninput.<br></font><font style="font-size: 9pt;" size="2">Graphical          \nfeatures&nbsp;may&nbsp;be&nbsp;minimized.</font>          \n', '2009-02-04 11:13:38', 'marco.eilers', 'marco.eilers', '2009-02-05 16:10:32'),
(7944, NULL, NULL, NULL, 7653, '11320', '100', '11239', '11231', '745', 'ChiReq012', '1.0', 'Ensure mobile device availability (power)', '         \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">Ensure         \na&nbsp;sufficient&nbsp;battery&nbsp;life&nbsp;for&nbsp;the&nbsp;used         \nmobile&nbsp;devices.</font><br><br>         \n</p>', '2009-02-04 11:13:42', 'marco.eilers', 'marco.eilers', '2009-02-05 16:12:07'),
(7976, NULL, 7792, NULL, 7653, '107', '20', '11329', '11231', '745', 'ChiReq013', '1.0', 'Short time frame to open manual', '        \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">The        \ntime&nbsp;frame&nbsp;to&nbsp;open&nbsp;manuals&nbsp;should&nbsp;not        \nexceed&nbsp;30&nbsp;seconds&nbsp;from&nbsp;the&nbsp;point&nbsp;of&nbsp;a        \nField&nbsp;worker&nbsp;requesting&nbsp;a&nbsp;manual&nbsp;to&nbsp;the        \npoint&nbsp;they&nbsp;can&nbsp;first&nbsp;access&nbsp;a&nbsp;page&nbsp;in        \nthe&nbsp;document.</font>        \n</p>', '2009-02-04 11:19:23', 'marco.eilers', 'marco.eilers', '2009-02-05 16:13:20'),
(7984, NULL, NULL, NULL, 7653, '110', '100', '11239', '11231', '11255', 'ChiReq014', '1.0', 'The connection to the intranet should be encrypted', '      \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">The      \nconnection&nbsp;from&nbsp;a&nbsp;field&nbsp;workers&nbsp;device&nbsp;to      \nthe&nbsp;intranet&nbsp;must&nbsp;be&nbsp;resistant&nbsp;to&nbsp;attacks      \nand&nbsp;attempts&nbsp;of&nbsp;spying&nbsp;out&nbsp;transmitted&nbsp;data.      \nThe&nbsp;system&nbsp;must&nbsp;provide&nbsp;a&nbsp;sufficient      \nresistance&nbsp;to&nbsp;all&nbsp;currently&nbsp;known&nbsp;forms&nbsp;and      \nmethods&nbsp;of&nbsp;attack.</font><br>      \n</p>', '2009-02-04 11:20:24', 'marco.eilers', 'marco.eilers', '2009-02-05 16:15:42'),
(7990, NULL, NULL, 7984, 7653, '110', '100', '11239', '11231', '5007', 'ChiReq015', '1.0', 'Unauthorized access must not be permitted', '       \n<p>Users       \nmust&#160;be&#160;uniquely&#160;identified&#160;and&#160;given       \nauthorization&#160;to&#160;access&#160;data&#160;according&#160;to       \ntheir&#160;roles.&#160;Field&#160;workers&#160;are&#160;only&#160;granted       \npermission&#160;to&#160;view&#160;customer&#160;data&#160;from       \ntransmitters&#160;within&#160;their&#160;region.&#160;Call&#160;center       \nagents&#160;may&#160;access&#160;all&#160;customers&#160;but&#160;have       \nrestricted&#160;view&#160;and&#160;edit&#160;permissions&#160;with       \nregards&#160;to&#160;customer&#160;attributes&#160;and&#160;contract       \ndata.       \n</p>', '2009-02-04 11:20:30', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:47:34'),
(7996, NULL, NULL, 7876, 7653, '4116', '100', '11239', '11231', '11255', 'ChiReq016', '1.0', 'Existing ERP system must be integrated', '          \n<p style="margin-left: 0.04in; margin-top: 0.06in; margin-bottom: 0.04in; line-height: 100%;" lang="en-CA"><font style="font-size: 9pt;" size="2">The          \nexisting&nbsp;ERP&nbsp;system&nbsp;that&nbsp;is&nbsp;currently&nbsp;used          \nmust&nbsp;be&nbsp;integrated&nbsp;into&nbsp;the&nbsp;new&nbsp;solution.          \nExisting&nbsp;data&nbsp;must&nbsp;be&nbsp;extracted&nbsp;from&nbsp;the          \nERP&nbsp;system&nbsp;to&nbsp;be&nbsp;available.&nbsp;The&nbsp;solution          \nmay&nbsp;read&nbsp;data&nbsp;but&nbsp;changes&nbsp;on&nbsp;master          \ndata&nbsp;may&nbsp;only&nbsp;occur&nbsp;from&nbsp;within&nbsp;the&nbsp;ERP          \nsystem.</font></p><p style="margin-top: 0in; margin-bottom: 0in;"><br>          \n</p>', '2009-02-04 11:20:35', 'marco.eilers', 'marco.eilers', '2009-02-05 16:17:08'),
(8016, NULL, NULL, NULL, 7653, '4116', '50', '11239', '11231', '11255', 'ChiReq017', '1.0', 'Dashboard must be implemented', 'A dashboard must be implemented as a "homepage" in the CRM that lists the most frequent actions and objects accessed by a worker. Dashboards vary according to roles of workers who access the CRM. Different dashboards must be implemented for the roles of a Field Worker, Call Center Agent and System Administrator.', '2009-02-04 11:24:55', 'marco.eilers', 'marco.eilers', '2009-02-05 16:17:59'),
(12419, NULL, 12366, NULL, 12106, NULL, '50', 'myName, Analyst', 'aName, Client', NULL, NULL, '1.0', 'my 1st ChiRequirement', 'Modify this for create your own <b>Requirements</b>.  \n	<br><br>A Business guide line about the \nEnterprise or the project. \n<p>A ChiRequirement represents a condition \nthat needs to be <span >Satisfied</span> by certain \nachievement (a ChiFeature ).</p> \n', '2009-02-10 19:00:05', 'pgiuseppe', 'admin', '2009-03-06 17:56:23'),
(8502, NULL, 7735, NULL, 7653, '4116', '50', '11238', '11231', '5007', 'ChiReq001', '1.0', 'Provide Field Worker with additional information', '            \n<p>Unnecessary            \ntravel and&#160;inappropriate&#160;worker&#160;assignments&#160;due            \nto&#160;missing&#160;task&#160;skills&#160;should&#160;be&#160;eliminated.            \nIncrease&#160;effectiveness&#160;on&#160;the&#160;job&#160;by            \nproviding&#160;additional&#160;information&#160;about&#160;known            \nissues&#160;or&#160;best&#160;practices.&#160;Eliminate&#160;the&#160;need            \nto&#160;call&#160;for&#160;specialists&#160;as&#160;a&#160;result&#160;of            \na&#160;field&#160;worker&#160;not&#160;being&#160;able&#160;to            \nsuccessfully&#160;finish&#160;a&#160;task.            \n</p>', '2009-02-04 13:54:09', 'marco.eilers', 'pgiuseppe', '2009-02-27 11:37:25'),
(8520, NULL, NULL, NULL, 7653, '4116', '100', '11239', '11231', '11255', 'ChiReq018', '1.0', 'Call Center must know the current status of Trouble Call in real-time', '<font style="font-size: 9pt;" size="2">Call    \nCenter&nbsp;Agents&nbsp;must&nbsp;be&nbsp;able&nbsp;to&nbsp;view&nbsp;the    \nhistory&nbsp;and&nbsp;current&nbsp;status&nbsp;of&nbsp;a&nbsp;Trouble    \nCall.&nbsp;He&nbsp;can&nbsp;also&nbsp;change&nbsp;the&nbsp;status&nbsp;or    \nadd&nbsp;additional&nbsp;information&nbsp;about&nbsp;the&nbsp;Trouble    \nCall&nbsp;coming&nbsp;from&nbsp;the&nbsp;Customer&nbsp;or&nbsp;other    \nsources.</font><p style="margin-top: 0in; margin-bottom: 0in;"><br>    \n</p>', '2009-02-04 14:01:07', 'marco.eilers', 'marco.eilers', '2009-02-05 16:06:39'),
(8528, NULL, 7707, NULL, 7653, '4116', '100', '11239', '11231', '11305', 'ChiReq019', '1.0', 'Backoffice support must be linked with frontoffice service', '      \n<p style="margin-top: 0in; margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">Backoffice      \nsupport&nbsp;must&nbsp;be&nbsp;linked&nbsp;with&nbsp;frontoffice      \nservice&nbsp;to&nbsp;exchange&nbsp;information&nbsp;about&nbsp;Trouble      \nCalls&nbsp;and&nbsp;Visit&nbsp;Reports.</font>      \n</p>', '2009-02-04 14:01:53', 'marco.eilers', 'marco.eilers', '2009-02-05 16:09:15');

-- --------------------------------------------------------

--
-- Table structure for table `ChiRequirementStatus`
--

CREATE TABLE IF NOT EXISTS `ChiRequirementStatus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiRequirementStatus`
--

INSERT INTO `ChiRequirementStatus` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`) VALUES
(745, 'Proposed', NULL, '2008-09-02 11:54:52', 'pgiuseppe', 'pgiuseppe', '2008-09-02 11:55:04'),
(750, 'under review', NULL, '2008-09-02 11:55:11', 'pgiuseppe', 'pgiuseppe', '2008-09-02 11:55:25'),
(5005, 'Mandatory', NULL, '2009-01-22 12:17:16', 'admin', 'admin', '2009-01-22 12:19:07'),
(5007, 'Validated', NULL, '2009-01-22 12:19:10', 'admin', 'admin', '2009-01-22 12:19:22'),
(5009, 'Satisfied', NULL, '2009-01-22 12:19:27', 'admin', 'admin', '2009-01-22 12:19:32'),
(11255, 'Agreed', NULL, '2009-02-05 15:59:51', 'marco.eilers', 'marco.eilers', '2009-02-05 15:59:58'),
(11278, 'tbd', NULL, '2009-02-05 16:03:18', 'marco.eilers', 'marco.eilers', '2009-02-05 16:03:27'),
(11305, 'Approved', NULL, '2009-02-05 16:08:42', 'marco.eilers', 'marco.eilers', '2009-02-05 16:08:50');

-- --------------------------------------------------------

--
-- Table structure for table `ChiRequirementType`
--

CREATE TABLE IF NOT EXISTS `ChiRequirementType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiRequirementType`
--

INSERT INTO `ChiRequirementType` (`id`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`) VALUES
(107, 'performance', NULL, '2008-08-26 11:56:12', 'pgiuseppe', 'pgiuseppe', '2008-08-26 11:56:22'),
(110, 'security', NULL, '2008-08-26 11:56:28', 'pgiuseppe', 'pgiuseppe', '2008-08-26 11:56:44'),
(5013, 'Business Rule', NULL, '2009-01-22 12:20:14', 'admin', 'admin', '2009-01-22 12:20:19'),
(5011, 'Persistence', NULL, '2009-01-22 12:19:55', 'admin', 'admin', '2009-01-22 12:20:02'),
(4116, 'Functional', NULL, '2009-01-15 10:45:38', 'admin', 'admin', '2009-01-22 12:17:08'),
(11320, 'Availability', NULL, '2009-02-05 16:11:25', 'marco.eilers', 'marco.eilers', '2009-02-05 16:11:36');

-- --------------------------------------------------------

--
-- Table structure for table `ChiValue`
--

CREATE TABLE IF NOT EXISTS `ChiValue` (
  `id` int(11) NOT NULL,
  `fk_chinode_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `app_data_type` varchar(255) default NULL,
  `db_data_type` varchar(255) default NULL,
  `is_editable` varchar(255) default NULL,
  `input_type` varchar(255) default NULL,
  `display_type` varchar(255) default NULL,
  `restrictions_match` varchar(255) default NULL,
  `restrictions_not_match` varchar(255) default NULL,
  `restrictions_description` varchar(255) default NULL,
  `column_name` varchar(255) default NULL,
  `fk_package_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiValue`
--

INSERT INTO `ChiValue` (`id`, `fk_chinode_id`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `app_data_type`, `db_data_type`, `is_editable`, `input_type`, `display_type`, `restrictions_match`, `restrictions_not_match`, `restrictions_description`, `column_name`, `fk_package_id`) VALUES
(86, 83, NULL, '1.0', 'Name', NULL, '2008-08-26 11:15:22', 'pgiuseppe', 'pgiuseppe', '2008-08-26 11:16:01', 'DATATYPE_ATTRIBUTE', 'VARCHAR(255)', 'true', 'text', 'text', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ChiView`
--

CREATE TABLE IF NOT EXISTS `ChiView` (
  `id` int(11) NOT NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_package_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiView`
--


-- --------------------------------------------------------

--
-- Table structure for table `ChiWorker`
--

CREATE TABLE IF NOT EXISTS `ChiWorker` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiWorker`
--


-- --------------------------------------------------------

--
-- Table structure for table `ChiWorkerExternal`
--

CREATE TABLE IF NOT EXISTS `ChiWorkerExternal` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `is_offlineuser` varchar(255) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_chiworkerexternal_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiWorkerExternal`
--

INSERT INTO `ChiWorkerExternal` (`id`, `fk_chibusinessprocess_id`, `fk_package_id`, `is_offlineuser`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `fk_chiworkerexternal_id`) VALUES
(9667, NULL, 9437, 'true', NULL, '1.0', 'Area Manager', NULL, '2009-02-05 10:39:10', 'marco.eilers', 'marco.eilers', '2009-02-05 10:39:43', NULL),
(9474, NULL, 9437, 'true', NULL, '1.0', 'Field Worker', NULL, '2009-02-04 16:26:42', 'marco.eilers', 'admin', '2009-03-06 17:51:11', NULL),
(9673, NULL, 9437, 'true', NULL, '1.0', 'Technician', NULL, '2009-02-05 10:39:14', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:08:39', NULL),
(9679, NULL, 9437, 'true', NULL, '1.0', 'Specialist', NULL, '2009-02-05 10:39:18', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:08:33', NULL),
(13286, NULL, 12143, 'true', NULL, '1.0', 'my ChiWorkerExternal', NULL, '2009-02-11 16:08:01', 'pgiuseppe', 'pgiuseppe', '2009-02-11 16:08:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ChiWorkerInternal`
--

CREATE TABLE IF NOT EXISTS `ChiWorkerInternal` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_chiworkerinternal_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChiWorkerInternal`
--

INSERT INTO `ChiWorkerInternal` (`id`, `fk_chibusinessprocess_id`, `fk_package_id`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `fk_chiworkerinternal_id`) VALUES
(20927, NULL, 9437, 'Chi008WorI', NULL, 'ERP system', NULL, '2009-03-04 16:59:04', 'pgiuseppe', 'admin', '2009-03-06 17:51:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Counter`
--

CREATE TABLE IF NOT EXISTS `Counter` (
  `id` int(11) NOT NULL,
  `chigoal` varchar(255) default NULL,
  `chirequirement` varchar(255) default NULL,
  `chifeature` varchar(255) default NULL,
  `chiissue` varchar(255) default NULL,
  `chibusinessusecase` varchar(255) default NULL,
  `chibusinessprocess` varchar(255) default NULL,
  `chibusinessusecasecore` varchar(255) default NULL,
  `chibusinesspartneractive` varchar(255) default NULL,
  `chibusinesspartnerpassive` varchar(255) default NULL,
  `chiworkerexternal` varchar(255) default NULL,
  `chiworkerinternal` varchar(255) default NULL,
  `chiworker` varchar(255) default NULL,
  `chibusinesspartner` varchar(255) default NULL,
  `chicontroller` varchar(255) default NULL,
  `chinode` varchar(255) default NULL,
  `chivalue` varchar(255) default NULL,
  `chiview` varchar(255) default NULL,
  `operation` varchar(255) default NULL,
  `activity` varchar(255) default NULL,
  `activitydecision` varchar(255) default NULL,
  `activityreceive` varchar(255) default NULL,
  `activitysend` varchar(255) default NULL,
  `activityinitial` varchar(255) default NULL,
  `activityfinal` varchar(255) default NULL,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Counter`
--

INSERT INTO `Counter` (`id`, `chigoal`, `chirequirement`, `chifeature`, `chiissue`, `chibusinessusecase`, `chibusinessprocess`, `chibusinessusecasecore`, `chibusinesspartneractive`, `chibusinesspartnerpassive`, `chiworkerexternal`, `chiworkerinternal`, `chiworker`, `chibusinesspartner`, `chicontroller`, `chinode`, `chivalue`, `chiview`, `operation`, `activity`, `activitydecision`, `activityreceive`, `activitysend`, `activityinitial`, `activityfinal`, `created`, `creator`, `last_editor`, `modified`) VALUES
(99999999, '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '2', '1', '1', '1', '2', '2', NULL, NULL, 'admin', '2009-03-06 17:56:57');

-- --------------------------------------------------------

--
-- Table structure for table `dbupdate`
--

CREATE TABLE IF NOT EXISTS `dbupdate` (
  `table_id` varchar(150) NOT NULL,
  `column_id` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `table` varchar(255) default NULL,
  `column` varchar(255) default NULL,
  `updated` datetime default NULL,
  PRIMARY KEY  (`table_id`,`column_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dbupdate`
--

INSERT INTO `dbupdate` (`table_id`, `column_id`, `type`, `table`, `column`, `updated`) VALUES
('EAID_03F15877_01B7_4386_A6AA_D42EF3E2579D', '-', 'table', 'NMFeatureRequirements', '-', '2009-01-22 11:32:44'),
('EAID_03F15877_01B7_4386_A6AA_D42EF3E2579D', 'EAID_03F15877_01B7_4386_A6AA_D42EF3E2579D_id', 'column', 'NMFeatureRequirements', 'id', '2009-01-22 11:32:44'),
('EAID_03F15877_01B7_4386_A6AA_D42EF3E2579D', 'EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263_fk_chifeature_id', 'column', 'NMFeatureRequirements', 'fk_chifeature_id', '2009-01-22 11:32:44'),
('EAID_03F15877_01B7_4386_A6AA_D42EF3E2579D', 'EAID_1169EE51_B124_402a_8430_12D6680C48DD_fk_chirequirement_id', 'column', 'NMFeatureRequirements', 'fk_chirequirement_id', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '-', 'table', 'ChiGoal', '-', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', 'EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB_id', 'column', 'ChiGoal', 'id', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'ChiGoal', 'fk_chibusinessprocess_id', '2008-09-08 21:28:36'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiGoal', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', 'EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB_fk_chigoal_id', 'column', 'ChiGoal', 'fk_chigoal_id', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '{F6E9EAC8-F4CA-4fe5-B343-23FE55DC6B6A}', 'column', 'ChiGoal', 'priority', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '{5C83F67E-8051-4cde-AB4D-0C9EDE940D7E}', 'column', 'ChiGoal', 'value_name', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '{D5E47AFF-F63E-4e8a-98F4-D854F99A8607}', 'column', 'ChiGoal', 'value_ammount', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '{4A005AF8-CC83-4169-9D5D-6A71A85F90A0}', 'column', 'ChiGoal', 'value_goal', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiGoal', 'alias', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiGoal', 'version', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiGoal', 'name', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiGoal', 'notes', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiGoal', 'created', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiGoal', 'creator', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiGoal', 'last_editor', '2009-01-22 11:32:44'),
('EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiGoal', 'modified', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '-', 'table', 'ChiRequirement', '-', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', 'EAID_1169EE51_B124_402a_8430_12D6680C48DD_id', 'column', 'ChiRequirement', 'id', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'ChiRequirement', 'fk_chibusinessprocess_id', '2008-09-08 21:28:36'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', 'EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB_fk_chigoal_id', 'column', 'ChiRequirement', 'fk_chigoal_id', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', 'EAID_1169EE51_B124_402a_8430_12D6680C48DD_fk_chirequirement_id', 'column', 'ChiRequirement', 'fk_chirequirement_id', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiRequirement', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{6BE90587-3033-4d4c-9D05-20FCC7B5D2D1}', 'column', 'ChiRequirement', 'reqtype', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{E5696387-DC21-47a7-B0E0-B99AF858D519}', 'column', 'ChiRequirement', 'priority', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{FD9FE2DB-EC74-4362-83DC-2DDD333A4279}', 'column', 'ChiRequirement', 'author', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{BB67DFA4-93B5-4212-AFE0-D59FF31FD90A}', 'column', 'ChiRequirement', 'proofreader', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{87D413FB-7BD7-4ce1-A394-5AC92102484B}', 'column', 'ChiRequirement', 'status', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiRequirement', 'alias', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiRequirement', 'version', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiRequirement', 'name', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiRequirement', 'notes', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiRequirement', 'created', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiRequirement', 'creator', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiRequirement', 'last_editor', '2009-01-22 11:32:44'),
('EAID_1169EE51_B124_402a_8430_12D6680C48DD', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiRequirement', 'modified', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', '-', 'table', 'ChiFeature', '-', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', 'EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263_id', 'column', 'ChiFeature', 'id', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'ChiFeature', 'fk_chibusinessprocess_id', '2008-09-08 21:28:37'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiFeature', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', '{B8B932B0-4DB5-4b2f-B5DC-77539B897D78}', 'column', 'ChiFeature', 'author', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', '{DCB9B590-FB72-4745-8ED3-C194543F17E8}', 'column', 'ChiFeature', 'proofreader', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', '{8DF13718-C83D-4a82-9492-E8E243EE8376}', 'column', 'ChiFeature', 'status', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiFeature', 'alias', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiFeature', 'version', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiFeature', 'name', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiFeature', 'notes', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiFeature', 'created', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiFeature', 'creator', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiFeature', 'last_editor', '2009-01-22 11:32:44'),
('EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiFeature', 'modified', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', '-', 'table', 'ChiIssue', '-', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', 'EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9_id', 'column', 'ChiIssue', 'id', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'ChiIssue', 'fk_chibusinessprocess_id', '2008-09-08 21:28:37'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiIssue', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', 'EAID_1169EE51_B124_402a_8430_12D6680C48DD_fk_chirequirement_id', 'column', 'ChiIssue', 'fk_chirequirement_id', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', '{B0485347-2C52-4f90-BD0A-51636A4286F3}', 'column', 'ChiIssue', 'author', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', '{1EFDFCC4-23FA-4d6b-ABDC-FA778BEA128D}', 'column', 'ChiIssue', 'responsible', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiIssue', 'alias', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiIssue', 'version', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiIssue', 'name', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiIssue', 'notes', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiIssue', 'created', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiIssue', 'creator', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiIssue', 'last_editor', '2009-01-22 11:32:44'),
('EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiIssue', 'modified', '2009-01-22 11:32:44'),
('EAID_4EFCA1BF_35BD_4395_A2E2_CE5ECC2DF98C', '-', 'table', 'ChiFeatureStatus', '-', '2009-01-22 11:32:44'),
('EAID_4EFCA1BF_35BD_4395_A2E2_CE5ECC2DF98C', 'EAID_4EFCA1BF_35BD_4395_A2E2_CE5ECC2DF98C_id', 'column', 'ChiFeatureStatus', 'id', '2009-01-22 11:32:44'),
('EAID_4EFCA1BF_35BD_4395_A2E2_CE5ECC2DF98C', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiFeatureStatus', 'name', '2009-01-22 11:32:44'),
('EAID_4EFCA1BF_35BD_4395_A2E2_CE5ECC2DF98C', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiFeatureStatus', 'notes', '2009-01-22 11:32:44'),
('EAID_4EFCA1BF_35BD_4395_A2E2_CE5ECC2DF98C', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiFeatureStatus', 'created', '2009-01-22 11:32:44'),
('EAID_4EFCA1BF_35BD_4395_A2E2_CE5ECC2DF98C', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiFeatureStatus', 'creator', '2009-01-22 11:32:44'),
('EAID_4EFCA1BF_35BD_4395_A2E2_CE5ECC2DF98C', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiFeatureStatus', 'last_editor', '2009-01-22 11:32:44'),
('EAID_4EFCA1BF_35BD_4395_A2E2_CE5ECC2DF98C', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiFeatureStatus', 'modified', '2009-01-22 11:32:44'),
('EAID_253B1C26_A49E_4b52_BEDD_2F470DC6FEDE', '-', 'table', 'ChiRequirementStatus', '-', '2009-01-22 11:32:44'),
('EAID_253B1C26_A49E_4b52_BEDD_2F470DC6FEDE', 'EAID_253B1C26_A49E_4b52_BEDD_2F470DC6FEDE_id', 'column', 'ChiRequirementStatus', 'id', '2009-01-22 11:32:44'),
('EAID_253B1C26_A49E_4b52_BEDD_2F470DC6FEDE', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiRequirementStatus', 'name', '2009-01-22 11:32:44'),
('EAID_253B1C26_A49E_4b52_BEDD_2F470DC6FEDE', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiRequirementStatus', 'notes', '2009-01-22 11:32:44'),
('EAID_253B1C26_A49E_4b52_BEDD_2F470DC6FEDE', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiRequirementStatus', 'created', '2009-01-22 11:32:44'),
('EAID_253B1C26_A49E_4b52_BEDD_2F470DC6FEDE', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiRequirementStatus', 'creator', '2009-01-22 11:32:44'),
('EAID_253B1C26_A49E_4b52_BEDD_2F470DC6FEDE', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiRequirementStatus', 'last_editor', '2009-01-22 11:32:44'),
('EAID_253B1C26_A49E_4b52_BEDD_2F470DC6FEDE', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiRequirementStatus', 'modified', '2009-01-22 11:32:44'),
('EAID_B4D8CC31_7D39_46cd_A2B6_2D57DF2A04CF', '-', 'table', 'ChiRequirementType', '-', '2009-01-22 11:32:44'),
('EAID_B4D8CC31_7D39_46cd_A2B6_2D57DF2A04CF', 'EAID_B4D8CC31_7D39_46cd_A2B6_2D57DF2A04CF_id', 'column', 'ChiRequirementType', 'id', '2009-01-22 11:32:44'),
('EAID_B4D8CC31_7D39_46cd_A2B6_2D57DF2A04CF', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiRequirementType', 'name', '2009-01-22 11:32:44'),
('EAID_B4D8CC31_7D39_46cd_A2B6_2D57DF2A04CF', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiRequirementType', 'notes', '2009-01-22 11:32:44'),
('EAID_B4D8CC31_7D39_46cd_A2B6_2D57DF2A04CF', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiRequirementType', 'created', '2009-01-22 11:32:44'),
('EAID_B4D8CC31_7D39_46cd_A2B6_2D57DF2A04CF', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiRequirementType', 'creator', '2009-01-22 11:32:44'),
('EAID_B4D8CC31_7D39_46cd_A2B6_2D57DF2A04CF', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiRequirementType', 'last_editor', '2009-01-22 11:32:44'),
('EAID_B4D8CC31_7D39_46cd_A2B6_2D57DF2A04CF', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiRequirementType', 'modified', '2009-01-22 11:32:44'),
('EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292', '-', 'table', 'ChiBusinessPartnerPassive', '-', '2009-01-22 11:32:44'),
('EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292', 'EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292_id', 'column', 'ChiBusinessPartnerPassive', 'id', '2009-01-22 11:32:44'),
('EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'ChiBusinessPartnerPassive', 'fk_chibusinessprocess_id', '2008-09-08 21:28:37'),
('EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiBusinessPartnerPassive', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiBusinessPartnerPassive', 'alias', '2009-01-22 11:32:44'),
('EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiBusinessPartnerPassive', 'version', '2009-01-22 11:32:44'),
('EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiBusinessPartnerPassive', 'name', '2009-01-22 11:32:44'),
('EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiBusinessPartnerPassive', 'notes', '2009-01-22 11:32:44'),
('EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiBusinessPartnerPassive', 'created', '2009-01-22 11:32:44'),
('EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiBusinessPartnerPassive', 'creator', '2009-01-22 11:32:44'),
('EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiBusinessPartnerPassive', 'last_editor', '2009-01-22 11:32:44'),
('EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiBusinessPartnerPassive', 'modified', '2009-01-22 11:32:44'),
('EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20', '-', 'table', 'ChiWorker', '-', '2009-01-22 11:32:44'),
('EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20', 'EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20_id', 'column', 'ChiWorker', 'id', '2009-01-22 11:32:44'),
('EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'ChiWorker', 'fk_chibusinessprocess_id', '2008-09-08 21:28:37'),
('EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiWorker', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiWorker', 'alias', '2009-01-22 11:32:44'),
('EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiWorker', 'version', '2009-01-22 11:32:44'),
('EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiWorker', 'name', '2009-01-22 11:32:44'),
('EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiWorker', 'notes', '2009-01-22 11:32:44'),
('EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiWorker', 'created', '2009-01-22 11:32:44'),
('EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiWorker', 'creator', '2009-01-22 11:32:44'),
('EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiWorker', 'last_editor', '2009-01-22 11:32:44'),
('EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiWorker', 'modified', '2009-01-22 11:32:44'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', '-', 'table', 'ChiWorkerExternal', '-', '2009-01-22 11:32:44'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', 'EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6_id', 'column', 'ChiWorkerExternal', 'id', '2009-01-22 11:32:44'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'ChiWorkerExternal', 'fk_chibusinessprocess_id', '2008-09-08 21:28:37'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiWorkerExternal', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', '{A86A8961-C0FE-49a5-8932-186FB6992842}', 'column', 'ChiWorkerExternal', 'is_offlineuser', '2009-01-22 11:32:44'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiWorkerExternal', 'alias', '2009-01-22 11:32:44'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiWorkerExternal', 'version', '2009-01-22 11:32:44'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiWorkerExternal', 'name', '2009-01-22 11:32:44'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiWorkerExternal', 'notes', '2009-01-22 11:32:44'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiWorkerExternal', 'created', '2009-01-22 11:32:44'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiWorkerExternal', 'creator', '2009-01-22 11:32:44'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiWorkerExternal', 'last_editor', '2009-01-22 11:32:44'),
('EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiWorkerExternal', 'modified', '2009-01-22 11:32:44'),
('EAID_2A793A11_60C7_4108_9C85_18F6F015505F', '-', 'table', 'ChiWorkerInternal', '-', '2009-01-22 11:32:44'),
('EAID_2A793A11_60C7_4108_9C85_18F6F015505F', 'EAID_2A793A11_60C7_4108_9C85_18F6F015505F_id', 'column', 'ChiWorkerInternal', 'id', '2009-01-22 11:32:44'),
('EAID_2A793A11_60C7_4108_9C85_18F6F015505F', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'ChiWorkerInternal', 'fk_chibusinessprocess_id', '2008-09-08 21:28:37'),
('EAID_2A793A11_60C7_4108_9C85_18F6F015505F', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiWorkerInternal', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_2A793A11_60C7_4108_9C85_18F6F015505F', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiWorkerInternal', 'alias', '2009-01-22 11:32:44'),
('EAID_2A793A11_60C7_4108_9C85_18F6F015505F', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiWorkerInternal', 'version', '2009-01-22 11:32:44'),
('EAID_2A793A11_60C7_4108_9C85_18F6F015505F', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiWorkerInternal', 'name', '2009-01-22 11:32:44'),
('EAID_2A793A11_60C7_4108_9C85_18F6F015505F', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiWorkerInternal', 'notes', '2009-01-22 11:32:44'),
('EAID_2A793A11_60C7_4108_9C85_18F6F015505F', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiWorkerInternal', 'created', '2009-01-22 11:32:44'),
('EAID_2A793A11_60C7_4108_9C85_18F6F015505F', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiWorkerInternal', 'creator', '2009-01-22 11:32:44'),
('EAID_2A793A11_60C7_4108_9C85_18F6F015505F', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiWorkerInternal', 'last_editor', '2009-01-22 11:32:44'),
('EAID_2A793A11_60C7_4108_9C85_18F6F015505F', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiWorkerInternal', 'modified', '2009-01-22 11:32:44'),
('EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2', '-', 'table', 'Actor', '-', '2009-01-22 11:32:44'),
('EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2', 'EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2_id', 'column', 'Actor', 'id', '2009-01-22 11:32:44'),
('EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'Actor', 'fk_chibusinessprocess_id', '2008-09-08 21:28:37'),
('EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'Actor', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'Actor', 'alias', '2009-01-22 11:32:44'),
('EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'Actor', 'version', '2009-01-22 11:32:44'),
('EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'Actor', 'name', '2009-01-22 11:32:44'),
('EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'Actor', 'notes', '2009-01-22 11:32:44'),
('EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'Actor', 'created', '2009-01-22 11:32:44'),
('EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'Actor', 'creator', '2009-01-22 11:32:44'),
('EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'Actor', 'last_editor', '2009-01-22 11:32:44'),
('EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'Actor', 'modified', '2009-01-22 11:32:44'),
('EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3', '-', 'table', 'ChiBusinessProcess', '-', '2009-01-22 11:32:44'),
('EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_id', 'column', 'ChiBusinessProcess', 'id', '2009-01-22 11:32:44'),
('EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiBusinessProcess', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiBusinessProcess', 'alias', '2009-01-22 11:32:44'),
('EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiBusinessProcess', 'version', '2009-01-22 11:32:44'),
('EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiBusinessProcess', 'name', '2009-01-22 11:32:44'),
('EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiBusinessProcess', 'notes', '2009-01-22 11:32:44'),
('EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiBusinessProcess', 'created', '2009-01-22 11:32:44'),
('EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiBusinessProcess', 'creator', '2009-01-22 11:32:44'),
('EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiBusinessProcess', 'last_editor', '2009-01-22 11:32:44'),
('EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiBusinessProcess', 'modified', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '-', 'table', 'ChiBusinessUseCase', '-', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', 'EAID_A59A19CD_77D2_4018_9BB1_768011088E88_id', 'column', 'ChiBusinessUseCase', 'id', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'ChiBusinessUseCase', 'fk_chibusinessprocess_id', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{4041F610-32BC-4189-B2DC-A39C60D94F05}', 'column', 'ChiBusinessUseCase', 'primaryactor', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{81EC46D8-DF2B-4ab2-B858-561EAFD144C4}', 'column', 'ChiBusinessUseCase', 'otheractors', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{D8CF4340-B3F6-4a7d-8B89-1ED7CD5A8A3B}', 'column', 'ChiBusinessUseCase', 'goalincontext', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{457D6B8F-5C6C-4614-A4AE-B7219A490CB6}', 'column', 'ChiBusinessUseCase', 'scope', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{473B21EA-AE12-483b-8742-31DC9775A8DE}', 'column', 'ChiBusinessUseCase', 'level', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{FD8341F1-A37A-4e05-995B-C8DF570F5DE9}', 'column', 'ChiBusinessUseCase', 'stakeholders', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{F965589A-94D9-4589-B79A-01000B433301}', 'column', 'ChiBusinessUseCase', 'precondition', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{544C139A-724F-4d10-8F4E-0C0BB70957BC}', 'column', 'ChiBusinessUseCase', 'trigger', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{6B11E95D-EB71-4741-A81D-52F8CE4343F1}', 'column', 'ChiBusinessUseCase', 'mainsuccessscenario', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{A50BA5A6-35A0-46ea-ADE4-A0A65E31FA3A}', 'column', 'ChiBusinessUseCase', 'extensions', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiBusinessUseCase', 'alias', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiBusinessUseCase', 'version', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiBusinessUseCase', 'name', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiBusinessUseCase', 'notes', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiBusinessUseCase', 'created', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiBusinessUseCase', 'creator', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiBusinessUseCase', 'last_editor', '2009-01-22 11:32:44'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiBusinessUseCase', 'modified', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '-', 'table', 'ChiBusinessUseCaseCore', '-', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', 'EAID_63789429_77BC_46a1_81D8_1D06696D0669_id', 'column', 'ChiBusinessUseCaseCore', 'id', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'ChiBusinessUseCaseCore', 'fk_chibusinessprocess_id', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{4041F610-32BC-4189-B2DC-A39C60D94F05}', 'column', 'ChiBusinessUseCaseCore', 'primaryactor', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{81EC46D8-DF2B-4ab2-B858-561EAFD144C4}', 'column', 'ChiBusinessUseCaseCore', 'otheractors', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{D8CF4340-B3F6-4a7d-8B89-1ED7CD5A8A3B}', 'column', 'ChiBusinessUseCaseCore', 'goalincontext', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{457D6B8F-5C6C-4614-A4AE-B7219A490CB6}', 'column', 'ChiBusinessUseCaseCore', 'scope', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{473B21EA-AE12-483b-8742-31DC9775A8DE}', 'column', 'ChiBusinessUseCaseCore', 'level', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{FD8341F1-A37A-4e05-995B-C8DF570F5DE9}', 'column', 'ChiBusinessUseCaseCore', 'stakeholders', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{F965589A-94D9-4589-B79A-01000B433301}', 'column', 'ChiBusinessUseCaseCore', 'precondition', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{544C139A-724F-4d10-8F4E-0C0BB70957BC}', 'column', 'ChiBusinessUseCaseCore', 'trigger', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{6B11E95D-EB71-4741-A81D-52F8CE4343F1}', 'column', 'ChiBusinessUseCaseCore', 'mainsuccessscenario', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{A50BA5A6-35A0-46ea-ADE4-A0A65E31FA3A}', 'column', 'ChiBusinessUseCaseCore', 'extensions', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiBusinessUseCaseCore', 'alias', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiBusinessUseCaseCore', 'version', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiBusinessUseCaseCore', 'name', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiBusinessUseCaseCore', 'notes', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiBusinessUseCaseCore', 'created', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiBusinessUseCaseCore', 'creator', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiBusinessUseCaseCore', 'last_editor', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiBusinessUseCaseCore', 'modified', '2009-01-22 11:32:44'),
('EAID_0518754B_9320_4acd_8B6D_869425C63F2A', '-', 'table', 'ChiBusinessPartner', '-', '2009-01-22 11:32:44'),
('EAID_0518754B_9320_4acd_8B6D_869425C63F2A', 'EAID_0518754B_9320_4acd_8B6D_869425C63F2A_id', 'column', 'ChiBusinessPartner', 'id', '2009-01-22 11:32:44'),
('EAID_0518754B_9320_4acd_8B6D_869425C63F2A', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'ChiBusinessPartner', 'fk_chibusinessprocess_id', '2008-09-05 11:41:24'),
('EAID_0518754B_9320_4acd_8B6D_869425C63F2A', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiBusinessPartner', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_0518754B_9320_4acd_8B6D_869425C63F2A', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiBusinessPartner', 'alias', '2009-01-22 11:32:44'),
('EAID_0518754B_9320_4acd_8B6D_869425C63F2A', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiBusinessPartner', 'version', '2009-01-22 11:32:44'),
('EAID_0518754B_9320_4acd_8B6D_869425C63F2A', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiBusinessPartner', 'name', '2009-01-22 11:32:44'),
('EAID_0518754B_9320_4acd_8B6D_869425C63F2A', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiBusinessPartner', 'notes', '2009-01-22 11:32:44'),
('EAID_0518754B_9320_4acd_8B6D_869425C63F2A', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiBusinessPartner', 'created', '2009-01-22 11:32:44'),
('EAID_0518754B_9320_4acd_8B6D_869425C63F2A', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiBusinessPartner', 'creator', '2009-01-22 11:32:44'),
('EAID_0518754B_9320_4acd_8B6D_869425C63F2A', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiBusinessPartner', 'last_editor', '2009-01-22 11:32:44'),
('EAID_0518754B_9320_4acd_8B6D_869425C63F2A', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiBusinessPartner', 'modified', '2009-01-22 11:32:44'),
('EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110', '-', 'table', 'ChiBusinessPartnerActive', '-', '2009-01-22 11:32:44'),
('EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110', 'EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110_id', 'column', 'ChiBusinessPartnerActive', 'id', '2009-01-22 11:32:44'),
('EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'ChiBusinessPartnerActive', 'fk_chibusinessprocess_id', '2008-09-05 11:41:24'),
('EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiBusinessPartnerActive', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiBusinessPartnerActive', 'alias', '2009-01-22 11:32:44'),
('EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiBusinessPartnerActive', 'version', '2009-01-22 11:32:44'),
('EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiBusinessPartnerActive', 'name', '2009-01-22 11:32:44'),
('EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiBusinessPartnerActive', 'notes', '2009-01-22 11:32:44'),
('EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiBusinessPartnerActive', 'created', '2009-01-22 11:32:44'),
('EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiBusinessPartnerActive', 'creator', '2009-01-22 11:32:44'),
('EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiBusinessPartnerActive', 'last_editor', '2009-01-22 11:32:44'),
('EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiBusinessPartnerActive', 'modified', '2009-01-22 11:32:44'),
('EAID_3C3FC8F0_DD8A_4ad9_BB10_403825A48C9C', '-', 'table', 'adodbseq', '-', '2009-01-22 11:32:44'),
('EAID_3C3FC8F0_DD8A_4ad9_BB10_403825A48C9C', 'EAID_3C3FC8F0_DD8A_4ad9_BB10_403825A48C9C_id', 'column', 'adodbseq', 'id', '2009-01-22 11:32:44'),
('EAID_ADC6F227_2E89_41a1_8EA3_9B73820EC9D8', '-', 'table', 'Locktable', '-', '2009-01-22 11:32:44'),
('EAID_ADC6F227_2E89_41a1_8EA3_9B73820EC9D8', 'EAID_ADC6F227_2E89_41a1_8EA3_9B73820EC9D8_id', 'column', 'Locktable', 'id', '2009-01-22 11:32:44'),
('EAID_ADC6F227_2E89_41a1_8EA3_9B73820EC9D8', 'EAID_B8AEA9E2_2228_42b9_9121_FDA1DF50E05D_fk_user_id', 'column', 'Locktable', 'fk_user_id', '2009-01-22 11:32:44'),
('EAID_ADC6F227_2E89_41a1_8EA3_9B73820EC9D8', '{C18AF095-575E-4c60-9240-37EE7976CEB5}', 'column', 'Locktable', 'oid', '2009-01-22 11:32:44'),
('EAID_ADC6F227_2E89_41a1_8EA3_9B73820EC9D8', '{C690480B-E434-4675-807B-7DA3C1FC71E9}', 'column', 'Locktable', 'sid', '2009-01-22 11:32:44'),
('EAID_ADC6F227_2E89_41a1_8EA3_9B73820EC9D8', '{436EB7C1-122C-42c2-81F2-D519B950E934}', 'column', 'Locktable', 'since', '2009-01-22 11:32:44'),
('EAID_4AB7C88E_CE09_4fba_A8C9_1DBEEC9B5EFC', '-', 'table', 'nm_user_role', '-', '2009-01-22 11:32:44'),
('EAID_4AB7C88E_CE09_4fba_A8C9_1DBEEC9B5EFC', 'EAID_4AB7C88E_CE09_4fba_A8C9_1DBEEC9B5EFC_id', 'column', 'nm_user_role', 'id', '2009-01-22 11:32:44'),
('EAID_4AB7C88E_CE09_4fba_A8C9_1DBEEC9B5EFC', 'EAID_B8AEA9E2_2228_42b9_9121_FDA1DF50E05D_fk_user_id', 'column', 'nm_user_role', 'fk_user_id', '2009-01-22 11:32:44'),
('EAID_4AB7C88E_CE09_4fba_A8C9_1DBEEC9B5EFC', 'EAID_74CB3FF5_27C7_435e_BECA_F3511F6A181D_fk_role_id', 'column', 'nm_user_role', 'fk_role_id', '2009-01-22 11:32:44'),
('EAID_74CB3FF5_27C7_435e_BECA_F3511F6A181D', '-', 'table', 'RoleRDB', '-', '2009-01-22 11:32:44'),
('EAID_74CB3FF5_27C7_435e_BECA_F3511F6A181D', 'EAID_74CB3FF5_27C7_435e_BECA_F3511F6A181D_id', 'column', 'RoleRDB', 'id', '2009-01-22 11:32:44'),
('EAID_74CB3FF5_27C7_435e_BECA_F3511F6A181D', '{451E3B0C-4DF2-4f43-9F9E-88306EFE8D68}', 'column', 'RoleRDB', 'name', '2009-01-22 11:32:44'),
('EAID_B8AEA9E2_2228_42b9_9121_FDA1DF50E05D', '-', 'table', 'user', '-', '2009-01-22 11:32:44'),
('EAID_B8AEA9E2_2228_42b9_9121_FDA1DF50E05D', 'EAID_B8AEA9E2_2228_42b9_9121_FDA1DF50E05D_id', 'column', 'user', 'id', '2009-01-22 11:32:44'),
('EAID_B8AEA9E2_2228_42b9_9121_FDA1DF50E05D', '{6FFE27BD-3B95-4828-B26A-A41AEC65B651}', 'column', 'user', 'login', '2009-01-22 11:32:44'),
('EAID_B8AEA9E2_2228_42b9_9121_FDA1DF50E05D', '{0F69EA9D-4963-4608-99DB-F35CE1159BDB}', 'column', 'user', 'password', '2009-01-22 11:32:44'),
('EAID_B8AEA9E2_2228_42b9_9121_FDA1DF50E05D', '{23BEDAEE-0278-4fb6-ABD1-E12AEE461A12}', 'column', 'user', 'name', '2009-01-22 11:32:44'),
('EAID_B8AEA9E2_2228_42b9_9121_FDA1DF50E05D', '{7AA15204-4902-45a5-AF96-599B511B4812}', 'column', 'user', 'firstname', '2009-01-22 11:32:44'),
('EAID_B8AEA9E2_2228_42b9_9121_FDA1DF50E05D', '{F0758E3B-E9D4-4dd9-A108-472A2CBE8CDA}', 'column', 'user', 'config', '2009-01-22 11:32:44'),
('EAID_5FE413E3_1A62_481e_BA5D_E6DB6DDDF19C', '-', 'table', 'ChiAuthors', '-', '2009-01-22 11:32:44'),
('EAID_5FE413E3_1A62_481e_BA5D_E6DB6DDDF19C', 'EAID_5FE413E3_1A62_481e_BA5D_E6DB6DDDF19C_id', 'column', 'ChiAuthors', 'id', '2009-01-22 11:32:44'),
('EAID_5FE413E3_1A62_481e_BA5D_E6DB6DDDF19C', '{D45593F8-C3B5-402d-B584-D98FE9F5D224}', 'column', 'ChiAuthors', 'role', '2009-01-22 11:32:44'),
('EAID_5FE413E3_1A62_481e_BA5D_E6DB6DDDF19C', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiAuthors', 'name', '2009-01-22 11:32:44'),
('EAID_5FE413E3_1A62_481e_BA5D_E6DB6DDDF19C', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiAuthors', 'notes', '2009-01-22 11:32:44'),
('EAID_5FE413E3_1A62_481e_BA5D_E6DB6DDDF19C', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiAuthors', 'created', '2009-01-22 11:32:44'),
('EAID_5FE413E3_1A62_481e_BA5D_E6DB6DDDF19C', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiAuthors', 'creator', '2009-01-22 11:32:44'),
('EAID_5FE413E3_1A62_481e_BA5D_E6DB6DDDF19C', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiAuthors', 'last_editor', '2009-01-22 11:32:44'),
('EAID_5FE413E3_1A62_481e_BA5D_E6DB6DDDF19C', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiAuthors', 'modified', '2009-01-22 11:32:44'),
('EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2', '-', 'table', 'ChiBase', '-', '2008-11-15 12:47:37'),
('EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2', 'EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2_id', 'column', 'ChiBase', 'id', '2008-11-15 12:47:37'),
('EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiBase', 'alias', '2008-11-15 12:47:37'),
('EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiBase', 'version', '2008-11-15 12:47:37'),
('EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiBase', 'name', '2008-11-15 12:47:37'),
('EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiBase', 'notes', '2008-11-15 12:47:37'),
('EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiBase', 'created', '2008-11-15 12:47:37'),
('EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiBase', 'creator', '2008-11-15 12:47:37'),
('EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiBase', 'last_editor', '2008-11-15 12:47:37'),
('EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiBase', 'modified', '2008-11-15 12:47:37'),
('EAID_8DF7B5BB_D115_4091_9813_2FC5E5BAA738', '-', 'table', 'EntityBase', '-', '2008-11-15 12:47:37'),
('EAID_8DF7B5BB_D115_4091_9813_2FC5E5BAA738', 'EAID_8DF7B5BB_D115_4091_9813_2FC5E5BAA738_id', 'column', 'EntityBase', 'id', '2008-11-15 12:47:37'),
('EAID_8DF7B5BB_D115_4091_9813_2FC5E5BAA738', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'EntityBase', 'created', '2008-11-15 12:47:37'),
('EAID_8DF7B5BB_D115_4091_9813_2FC5E5BAA738', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'EntityBase', 'creator', '2008-11-15 12:47:37'),
('EAID_8DF7B5BB_D115_4091_9813_2FC5E5BAA738', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'EntityBase', 'last_editor', '2008-11-15 12:47:37'),
('EAID_8DF7B5BB_D115_4091_9813_2FC5E5BAA738', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'EntityBase', 'modified', '2008-11-15 12:47:37'),
('EAID_B9B245DB_0CBD_4500_AE96_C0FFE7DEFB50', '-', 'table', 'EntityBaseExtended', '-', '2008-11-15 12:47:37'),
('EAID_B9B245DB_0CBD_4500_AE96_C0FFE7DEFB50', 'EAID_B9B245DB_0CBD_4500_AE96_C0FFE7DEFB50_id', 'column', 'EntityBaseExtended', 'id', '2008-11-15 12:47:37'),
('EAID_B9B245DB_0CBD_4500_AE96_C0FFE7DEFB50', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'EntityBaseExtended', 'name', '2008-11-15 12:47:37'),
('EAID_B9B245DB_0CBD_4500_AE96_C0FFE7DEFB50', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'EntityBaseExtended', 'notes', '2008-11-15 12:47:37'),
('EAID_B9B245DB_0CBD_4500_AE96_C0FFE7DEFB50', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'EntityBaseExtended', 'created', '2008-11-15 12:47:37'),
('EAID_B9B245DB_0CBD_4500_AE96_C0FFE7DEFB50', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'EntityBaseExtended', 'creator', '2008-11-15 12:47:37'),
('EAID_B9B245DB_0CBD_4500_AE96_C0FFE7DEFB50', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'EntityBaseExtended', 'last_editor', '2008-11-15 12:47:37'),
('EAID_B9B245DB_0CBD_4500_AE96_C0FFE7DEFB50', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'EntityBaseExtended', 'modified', '2008-11-15 12:47:37'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', '-', 'table', 'Package', '-', '2009-01-22 11:32:45'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_id', 'column', 'Package', 'id', '2009-01-22 11:32:45'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'Package', 'fk_chibusinessprocess_id', '2008-09-05 11:41:25'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'Package', 'fk_package_id', '2009-01-22 11:32:45'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'Package', 'alias', '2008-09-05 11:41:25'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'Package', 'version', '2008-09-05 11:41:25'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'Package', 'name', '2009-01-22 11:32:45'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'Package', 'notes', '2009-01-22 11:32:45'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'Package', 'created', '2009-01-22 11:32:45'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'Package', 'creator', '2009-01-22 11:32:45'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'Package', 'last_editor', '2009-01-22 11:32:45'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'Package', 'modified', '2009-01-22 11:32:45'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '-', 'table', 'ChiNode', '-', '2009-01-22 11:32:44'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', 'EAID_8AFE696D_2AAD_4e0d_A928_30389C846838_id', 'column', 'ChiNode', 'id', '2009-01-22 11:32:44'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', 'EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E_fk_chicontroller_id', 'column', 'ChiNode', 'fk_chicontroller_id', '2009-01-22 11:32:44'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiNode', 'alias', '2009-01-22 11:32:44'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiNode', 'version', '2009-01-22 11:32:44'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiNode', 'name', '2009-01-22 11:32:44'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiNode', 'notes', '2009-01-22 11:32:44'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiNode', 'created', '2009-01-22 11:32:44'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiNode', 'creator', '2009-01-22 11:32:44'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiNode', 'last_editor', '2009-01-22 11:32:44'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiNode', 'modified', '2009-01-22 11:32:44'),
('EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E', '-', 'table', 'ChiController', '-', '2009-01-22 11:32:44'),
('EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E', 'EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E_id', 'column', 'ChiController', 'id', '2009-01-22 11:32:44'),
('EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiController', 'alias', '2009-01-22 11:32:44'),
('EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiController', 'version', '2009-01-22 11:32:44'),
('EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiController', 'name', '2009-01-22 11:32:44'),
('EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiController', 'notes', '2009-01-22 11:32:44'),
('EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiController', 'created', '2009-01-22 11:32:44'),
('EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiController', 'creator', '2009-01-22 11:32:44'),
('EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiController', 'last_editor', '2009-01-22 11:32:44'),
('EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiController', 'modified', '2009-01-22 11:32:44'),
('EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3', '-', 'table', 'ChiView', '-', '2009-01-22 11:32:45'),
('EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3', 'EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3_id', 'column', 'ChiView', 'id', '2009-01-22 11:32:45'),
('EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiView', 'alias', '2009-01-22 11:32:45'),
('EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiView', 'version', '2009-01-22 11:32:45'),
('EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiView', 'name', '2009-01-22 11:32:45'),
('EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiView', 'notes', '2009-01-22 11:32:45'),
('EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiView', 'created', '2009-01-22 11:32:45'),
('EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiView', 'creator', '2009-01-22 11:32:45'),
('EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiView', 'last_editor', '2009-01-22 11:32:45'),
('EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiView', 'modified', '2009-01-22 11:32:45'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '-', 'table', 'ChiValue', '-', '2009-01-22 11:32:45'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', 'EAID_75A961F2_4EE3_452e_B190_A5838FB6879E_id', 'column', 'ChiValue', 'id', '2009-01-22 11:32:45'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', 'EAID_8AFE696D_2AAD_4e0d_A928_30389C846838_fk_chinode_id', 'column', 'ChiValue', 'fk_chinode_id', '2009-01-22 11:32:45'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'ChiValue', 'alias', '2009-01-22 11:32:45'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'ChiValue', 'version', '2009-01-22 11:32:45'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'ChiValue', 'name', '2009-01-22 11:32:45');
INSERT INTO `dbupdate` (`table_id`, `column_id`, `type`, `table`, `column`, `updated`) VALUES
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'ChiValue', 'notes', '2009-01-22 11:32:45'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'ChiValue', 'created', '2009-01-22 11:32:45'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'ChiValue', 'creator', '2009-01-22 11:32:45'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'ChiValue', 'last_editor', '2009-01-22 11:32:45'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'ChiValue', 'modified', '2009-01-22 11:32:45'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{AB2B0FEC-CBCD-465b-9D31-6503A09C7741}', 'column', 'ChiNode', 'display_value', '2008-08-26 10:28:17'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{02DEC154-2049-4fb0-901E-1B990421F241}', 'column', 'ChiNode', 'parent_order', '2008-08-26 10:28:17'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{FB5F7482-861C-4053-B5F3-285F9D01CD94}', 'column', 'ChiNode', 'child_order', '2008-08-26 10:28:17'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{30155F3E-BB5A-40fa-84D1-BD17EABF44D8}', 'column', 'ChiNode', 'pk_name', '2008-08-26 10:28:17'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{65DFFF39-0075-4beb-AD7A-6C97F9527B53}', 'column', 'ChiNode', 'is_searchable', '2008-08-26 10:28:17'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{70012A42-F789-4756-896C-409AC7B493B0}', 'column', 'ChiNode', 'orderby', '2008-08-26 10:28:17'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{9C0E72F3-47AD-4a3d-9D00-31CB1B617B36}', 'column', 'ChiNode', 'is_soap', '2008-08-26 10:28:17'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', '{337B081D-5E11-4e73-A08A-16C33B84CCF4}', 'column', 'ChiNode', 'initparams', '2008-08-26 10:28:17'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{4EDDF18E-E3FD-49bc-8F4D-6C300DA7D8D7}', 'column', 'ChiValue', 'app_data_type', '2008-08-26 10:28:17'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{FF516439-8D2C-43b5-8470-44107939958D}', 'column', 'ChiValue', 'db_data_type', '2008-08-26 10:28:17'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{DBED7B52-D7BE-44fe-86A2-756232173623}', 'column', 'ChiValue', 'is_editable', '2008-08-26 10:28:17'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{C61E1E54-D98E-49ca-89A9-13CF9DD3921E}', 'column', 'ChiValue', 'input_type', '2008-08-26 10:28:17'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{75D506FE-41FB-4c79-87FB-CDBAE4D3730F}', 'column', 'ChiValue', 'display_type', '2008-08-26 10:28:17'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{6D2F808D-FB97-4fca-98D7-2F7F8835FDE6}', 'column', 'ChiValue', 'restrictions_match', '2008-08-26 10:28:17'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{D1513686-1F67-4a06-97C9-800C081CB7B9}', 'column', 'ChiValue', 'restrictions_not_match', '2008-08-26 10:28:17'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{75896064-3B72-47a3-B2EA-65592B917467}', 'column', 'ChiValue', 'restrictions_description', '2008-08-26 10:28:17'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', '{2C3ABB2B-FCDF-4330-9E0E-993954BAA8EF}', 'column', 'ChiValue', 'column_name', '2008-08-26 10:28:17'),
('EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3', 'EAID_B92F55CA_30CA_468d_9088_A1880481B6C2_fk_model_id', 'column', 'ChiBusinessProcess', 'fk_model_id', '2008-09-05 11:41:24'),
('EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB', 'EAID_B92F55CA_30CA_468d_9088_A1880481B6C2_fk_model_id', 'column', 'Package', 'fk_model_id', '2009-01-22 11:32:45'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', '-', 'table', 'Diagram', '-', '2009-01-22 11:32:45'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', 'EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1_id', 'column', 'Diagram', 'id', '2009-01-22 11:32:45'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'Diagram', 'fk_chibusinessprocess_id', '2008-09-05 11:41:25'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'Diagram', 'fk_package_id', '2009-01-22 11:32:45'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', '{C920C9C4-4CD6-451c-BA0C-F79F4065D67D}', 'column', 'Diagram', 'width', '2009-01-22 11:32:45'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', '{C44650C8-6BA5-4129-A77E-A2D7D2B3983B}', 'column', 'Diagram', 'height', '2009-01-22 11:32:45'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'Diagram', 'alias', '2008-09-05 11:41:25'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'Diagram', 'version', '2008-09-05 11:41:25'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'Diagram', 'name', '2009-01-22 11:32:45'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'Diagram', 'notes', '2009-01-22 11:32:45'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'Diagram', 'created', '2009-01-22 11:32:45'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'Diagram', 'creator', '2009-01-22 11:32:45'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'Diagram', 'last_editor', '2009-01-22 11:32:45'),
('EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'Diagram', 'modified', '2009-01-22 11:32:45'),
('EAID_B92F55CA_30CA_468d_9088_A1880481B6C2', '-', 'table', 'Model', '-', '2009-01-22 11:32:45'),
('EAID_B92F55CA_30CA_468d_9088_A1880481B6C2', 'EAID_B92F55CA_30CA_468d_9088_A1880481B6C2_id', 'column', 'Model', 'id', '2009-01-22 11:32:45'),
('EAID_B92F55CA_30CA_468d_9088_A1880481B6C2', '{62D889AE-2BBF-4d32-AE69-72968C6EB738}', 'column', 'Model', 'alias', '2008-09-05 11:41:25'),
('EAID_B92F55CA_30CA_468d_9088_A1880481B6C2', '{DD7945CB-802B-468f-BA11-ECC32A722079}', 'column', 'Model', 'version', '2008-09-05 11:41:25'),
('EAID_B92F55CA_30CA_468d_9088_A1880481B6C2', '{FC5837B7-DD71-49ab-8015-87DC927CD034}', 'column', 'Model', 'name', '2009-01-22 11:32:45'),
('EAID_B92F55CA_30CA_468d_9088_A1880481B6C2', '{BC0FDE16-552E-4c0b-89A7-DAE24A40F4EC}', 'column', 'Model', 'notes', '2009-01-22 11:32:45'),
('EAID_B92F55CA_30CA_468d_9088_A1880481B6C2', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'Model', 'created', '2009-01-22 11:32:45'),
('EAID_B92F55CA_30CA_468d_9088_A1880481B6C2', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'Model', 'creator', '2009-01-22 11:32:45'),
('EAID_B92F55CA_30CA_468d_9088_A1880481B6C2', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'Model', 'last_editor', '2009-01-22 11:32:45'),
('EAID_B92F55CA_30CA_468d_9088_A1880481B6C2', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'Model', 'modified', '2009-01-22 11:32:45'),
('EAID_A59A19CD_77D2_4018_9BB1_768011088E88', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiBusinessUseCase', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_63789429_77BC_46a1_81D8_1D06696D0669', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiBusinessUseCaseCore', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_8AFE696D_2AAD_4e0d_A928_30389C846838', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiNode', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiController', 'fk_package_id', '2009-01-22 11:32:44'),
('EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiView', 'fk_package_id', '2009-01-22 11:32:45'),
('EAID_75A961F2_4EE3_452e_B190_A5838FB6879E', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiValue', 'fk_package_id', '2009-01-22 11:32:45'),
('EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2', 'EAID_05C9EAF6_8B0B_44f9_AED7_CBC223C935FB_fk_package_id', 'column', 'ChiBase', 'fk_package_id', '2008-11-15 12:47:37'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', '-', 'table', 'Figure', '-', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_7A186367_446B_4fab_9CA9_20ADC1531450_id', 'column', 'Figure', 'id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_C78BC7DD_DA11_463c_A937_F5BFA7660EAB_fk_chigoal_id', 'column', 'Figure', 'fk_chigoal_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_81FDBF74_10F8_403a_A886_BA51DFFA2263_fk_chifeature_id', 'column', 'Figure', 'fk_chifeature_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_1169EE51_B124_402a_8430_12D6680C48DD_fk_chirequirement_id', 'column', 'Figure', 'fk_chirequirement_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_E7461E91_24F7_4be8_9913_0E53305ED0E9_fk_chiissue_id', 'column', 'Figure', 'fk_chiissue_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_75A961F2_4EE3_452e_B190_A5838FB6879E_fk_chivalue_id', 'column', 'Figure', 'fk_chivalue_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_8DC5A1D2_AA2C_4d96_9B47_B1C7C93F9DA3_fk_chiview_id', 'column', 'Figure', 'fk_chiview_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_8AFE696D_2AAD_4e0d_A928_30389C846838_fk_chinode_id', 'column', 'Figure', 'fk_chinode_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_AF6EF41B_69E6_49d4_ADE9_5BF995414A9E_fk_chicontroller_id', 'column', 'Figure', 'fk_chicontroller_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_63789429_77BC_46a1_81D8_1D06696D0669_fk_chibusinessusecasecore_id', 'column', 'Figure', 'fk_chibusinessusecasecore_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_A59A19CD_77D2_4018_9BB1_768011088E88_fk_chibusinessusecase_id', 'column', 'Figure', 'fk_chibusinessusecase_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_CF3A013D_F615_45c5_BE80_2604A693AAD3_fk_chibusinessprocess_id', 'column', 'Figure', 'fk_chibusinessprocess_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6_fk_chiworkerexternal_id', 'column', 'Figure', 'fk_chiworkerexternal_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_2A793A11_60C7_4108_9C85_18F6F015505F_fk_chiworkerinternal_id', 'column', 'Figure', 'fk_chiworkerinternal_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20_fk_chiworker_id', 'column', 'Figure', 'fk_chiworker_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110_fk_chibusinesspartneractive_id', 'column', 'Figure', 'fk_chibusinesspartneractive_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292_fk_chibusinesspartnerpassive_id', 'column', 'Figure', 'fk_chibusinesspartnerpassive_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_0518754B_9320_4acd_8B6D_869425C63F2A_fk_chibusinesspartner_id', 'column', 'Figure', 'fk_chibusinesspartner_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2_fk_actor_id', 'column', 'Figure', 'fk_actor_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_0DD1F31D_98F5_4ddb_8F98_A177FCECD6A2_fk_chibase_id', 'column', 'Figure', 'fk_chibase_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', '{6077E09C-AE54-4ebb-BBEF-15B9DFEBFA97}', 'column', 'Figure', 'backgroundcolor', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', '{C44AF534-BE12-4f51-B06B-3E75C11A3F4A}', 'column', 'Figure', 'foregroundcolor', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', '{4B291134-0BC8-41df-BD0B-96E770CB8741}', 'column', 'Figure', 'gid', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', '{4947C61E-996C-471a-B72B-4DB80DF44C6B}', 'column', 'Figure', 'positiony', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', '{DBD27EEA-B85C-43b6-9DE9-B93EE38F2E1A}', 'column', 'Figure', 'positionx', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'Figure', 'created', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'Figure', 'creator', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'Figure', 'last_editor', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'Figure', 'modified', '2009-01-22 11:32:45'),
('EAID_466BBC51_15B0_4a62_ACC9_433587D48B91', '-', 'table', 'NMFiguresDiagram', '-', '2009-01-22 11:32:45'),
('EAID_466BBC51_15B0_4a62_ACC9_433587D48B91', 'EAID_466BBC51_15B0_4a62_ACC9_433587D48B91_id', 'column', 'NMFiguresDiagram', 'id', '2009-01-22 11:32:45'),
('EAID_466BBC51_15B0_4a62_ACC9_433587D48B91', '{EB5FAE3E-D59B-4615-BB11-35876802B4A0}', 'column', 'NMFiguresDiagram', 'created', '2009-01-22 11:32:45'),
('EAID_466BBC51_15B0_4a62_ACC9_433587D48B91', '{4008A23B-BA19-4f87-B52E-49746E5464E8}', 'column', 'NMFiguresDiagram', 'creator', '2009-01-22 11:32:45'),
('EAID_466BBC51_15B0_4a62_ACC9_433587D48B91', '{5395DABE-40A0-4290-9D1D-709A43DCD183}', 'column', 'NMFiguresDiagram', 'last_editor', '2009-01-22 11:32:45'),
('EAID_466BBC51_15B0_4a62_ACC9_433587D48B91', '{FE2FEF68-4845-4c43-BF1D-F219979BA7E7}', 'column', 'NMFiguresDiagram', 'modified', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', 'EAID_F6E80A6E_A203_4fb4_9DD0_FE227031ADD1_fk_diagram_id', 'column', 'Figure', 'fk_diagram_id', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', '{5FEC0C75-A1DB-4fa5-B8DA-8A3D0A6CD66B}', 'column', 'Figure', 'height', '2009-01-22 11:32:45'),
('EAID_7A186367_446B_4fab_9CA9_20ADC1531450', '{C6A5D90E-E5BF-4def-8357-7A667348C2C6}', 'column', 'Figure', 'width', '2009-01-22 11:32:45'),
('EAID_0863D9E9_ADE5_4c27_9118_97B5FEECAEAE', '-', 'table', 'NMUCActor', '-', '2009-01-22 11:32:45'),
('EAID_0863D9E9_ADE5_4c27_9118_97B5FEECAEAE', 'EAID_0863D9E9_ADE5_4c27_9118_97B5FEECAEAE_id', 'column', 'NMUCActor', 'id', '2009-01-22 11:32:45'),
('EAID_0863D9E9_ADE5_4c27_9118_97B5FEECAEAE', 'EAID_63789429_77BC_46a1_81D8_1D06696D0669_fk_chibusinessusecasecore_id', 'column', 'NMUCActor', 'fk_chibusinessusecasecore_id', '2009-01-22 11:32:45'),
('EAID_0863D9E9_ADE5_4c27_9118_97B5FEECAEAE', 'EAID_52B75F68_6CC4_42bc_875F_E778C772B4C6_fk_chiworkerexternal_id', 'column', 'NMUCActor', 'fk_chiworkerexternal_id', '2009-01-22 11:32:45'),
('EAID_0863D9E9_ADE5_4c27_9118_97B5FEECAEAE', 'EAID_2A793A11_60C7_4108_9C85_18F6F015505F_fk_chiworkerinternal_id', 'column', 'NMUCActor', 'fk_chiworkerinternal_id', '2009-01-22 11:32:45'),
('EAID_0863D9E9_ADE5_4c27_9118_97B5FEECAEAE', 'EAID_4B1FF5A9_E03E_441c_ADD2_BD9B082D4D20_fk_chiworker_id', 'column', 'NMUCActor', 'fk_chiworker_id', '2009-01-22 11:32:45'),
('EAID_0863D9E9_ADE5_4c27_9118_97B5FEECAEAE', 'EAID_A7C01B9A_19CF_43e8_AD85_7FD7DB295110_fk_chibusinesspartneractive_id', 'column', 'NMUCActor', 'fk_chibusinesspartneractive_id', '2009-01-22 11:32:45'),
('EAID_0863D9E9_ADE5_4c27_9118_97B5FEECAEAE', 'EAID_E82AFF41_CB05_4829_AA2A_402A1EAB7292_fk_chibusinesspartnerpassive_id', 'column', 'NMUCActor', 'fk_chibusinesspartnerpassive_id', '2009-01-22 11:32:45'),
('EAID_0863D9E9_ADE5_4c27_9118_97B5FEECAEAE', 'EAID_0518754B_9320_4acd_8B6D_869425C63F2A_fk_chibusinesspartner_id', 'column', 'NMUCActor', 'fk_chibusinesspartner_id', '2009-01-22 11:32:45'),
('EAID_0863D9E9_ADE5_4c27_9118_97B5FEECAEAE', 'EAID_A59A19CD_77D2_4018_9BB1_768011088E88_fk_chibusinessusecase_id', 'column', 'NMUCActor', 'fk_chibusinessusecase_id', '2009-01-22 11:32:45'),
('EAID_0863D9E9_ADE5_4c27_9118_97B5FEECAEAE', 'EAID_1134220A_E3FE_4daf_BC34_1DBA7BBB7DB2_fk_actor_id', 'column', 'NMUCActor', 'fk_actor_id', '2009-01-22 11:32:45'),
('b9e322f2-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'Adodbseq', '-', '2009-02-11 14:46:22'),
('b9e322f2-e7cf-11dd-925e-6920adbc19ca', '_xF1TgOfPEd2gQt5d1rMYcw', 'column', 'Adodbseq', 'id', '2009-02-11 14:46:22'),
('b9e322f3-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'locktable', '-', '2009-01-22 15:44:08'),
('b9e322f3-e7cf-11dd-925e-6920adbc19ca', '_xGR_defPEd2gQt5d1rMYcw', 'column', 'locktable', 'id', '2009-01-22 15:44:08'),
('b9e322f3-e7cf-11dd-925e-6920adbc19ca', '_xGR_cOfPEd2gQt5d1rMYcw', 'column', 'locktable', 'fk_userrdb_id', '2009-01-22 15:44:08'),
('b9e322f3-e7cf-11dd-925e-6920adbc19ca', '_vfnjrufPEd2gQt5d1rMYcw', 'column', 'locktable', 'objectid', '2009-01-22 15:44:08'),
('b9e322f3-e7cf-11dd-925e-6920adbc19ca', '_vfnjsufPEd2gQt5d1rMYcw', 'column', 'locktable', 'sessionid', '2009-01-22 15:44:08'),
('b9e322f3-e7cf-11dd-925e-6920adbc19ca', '_vfwtkefPEd2gQt5d1rMYcw', 'column', 'locktable', 'since', '2009-01-22 15:44:08'),
('b9ef09d7-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'NMUserRole', '-', '2009-01-22 15:44:08'),
('b9ef09d7-e7cf-11dd-925e-6920adbc19ca', '_xG4caufPEd2gQt5d1rMYcw', 'column', 'NMUserRole', 'fk_role_id', '2009-01-22 15:44:08'),
('b9ef09d7-e7cf-11dd-925e-6920adbc19ca', '_xG4cZefPEd2gQt5d1rMYcw', 'column', 'NMUserRole', 'fk_user_id', '2009-01-22 15:44:08'),
('b9ef09d7-e7cf-11dd-925e-6920adbc19ca', '_xG4cYOfPEd2gQt5d1rMYcw', 'column', 'NMUserRole', 'fk_userrdb_id', '2009-01-22 15:44:08'),
('b9ef09d7-e7cf-11dd-925e-6920adbc19ca', '_xGurYOfPEd2gQt5d1rMYcw', 'column', 'NMUserRole', 'fk_rolerdb_id', '2009-01-22 15:44:08'),
('b9fd61bc-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'role', '-', '2009-01-22 15:44:08'),
('b9fd61bc-e7cf-11dd-925e-6920adbc19ca', '_xHLXUOfPEd2gQt5d1rMYcw', 'column', 'role', 'id', '2009-01-22 15:44:08'),
('b9fd61bc-e7cf-11dd-925e-6920adbc19ca', '_vfwtl-fPEd2gQt5d1rMYcw', 'column', 'role', 'name', '2009-01-22 15:44:08'),
('ba021cad-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'UserRDB', '-', '2009-01-22 15:44:09'),
('ba021cad-e7cf-11dd-925e-6920adbc19ca', '_xHeSQOfPEd2gQt5d1rMYcw', 'column', 'UserRDB', 'id', '2009-01-22 15:44:09'),
('ba021cad-e7cf-11dd-925e-6920adbc19ca', '_vfwtnOfPEd2gQt5d1rMYcw', 'column', 'UserRDB', 'login', '2009-01-22 15:44:09'),
('ba021cad-e7cf-11dd-925e-6920adbc19ca', '_vfwtoOfPEd2gQt5d1rMYcw', 'column', 'UserRDB', 'password', '2009-01-22 15:44:09'),
('ba021cad-e7cf-11dd-925e-6920adbc19ca', '_vf6ekOfPEd2gQt5d1rMYcw', 'column', 'UserRDB', 'name', '2009-01-22 15:44:09'),
('ba021cad-e7cf-11dd-925e-6920adbc19ca', '_vf6elOfPEd2gQt5d1rMYcw', 'column', 'UserRDB', 'firstname', '2009-01-22 15:44:09'),
('ba021cad-e7cf-11dd-925e-6920adbc19ca', '_vf6emOfPEd2gQt5d1rMYcw', 'column', 'UserRDB', 'config', '2009-01-22 15:44:09'),
('ba369a2f-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'NMUCActor', '-', '2009-01-22 15:44:09'),
('ba369a2f-e7cf-11dd-925e-6920adbc19ca', '_xIXqKufPEd2gQt5d1rMYcw', 'column', 'NMUCActor', 'id', '2009-01-22 15:44:09'),
('ba369a2f-e7cf-11dd-925e-6920adbc19ca', '_xIXqJefPEd2gQt5d1rMYcw', 'column', 'NMUCActor', 'fk_chibusinesspartner_id', '2009-01-22 15:44:09'),
('ba369a2f-e7cf-11dd-925e-6920adbc19ca', '_xIXqIOfPEd2gQt5d1rMYcw', 'column', 'NMUCActor', 'fk_chiworker_id', '2009-01-22 15:44:09'),
('ba369a2f-e7cf-11dd-925e-6920adbc19ca', '_xIN5KufPEd2gQt5d1rMYcw', 'column', 'NMUCActor', 'fk_chibusinessusecasecore_id', '2009-01-22 15:44:09'),
('ba369a2f-e7cf-11dd-925e-6920adbc19ca', '_xIN5JefPEd2gQt5d1rMYcw', 'column', 'NMUCActor', 'fk_actor_id', '2009-01-22 15:44:09'),
('ba369a2f-e7cf-11dd-925e-6920adbc19ca', '_xIN5IOfPEd2gQt5d1rMYcw', 'column', 'NMUCActor', 'fk_chibusinessusecase_id', '2009-01-22 15:44:09'),
('ba44f214-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiBusinessProcess', '-', '2009-01-22 15:44:09'),
('ba44f214-e7cf-11dd-925e-6920adbc19ca', '_xJHRBefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessProcess', 'id', '2009-01-22 15:44:09'),
('ba44f214-e7cf-11dd-925e-6920adbc19ca', '_xJHRAOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessProcess', 'fk_package_id', '2009-01-22 15:44:09'),
('ba44f214-e7cf-11dd-925e-6920adbc19ca', '_xIqlEOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessProcess', 'alias', '2009-01-22 15:44:09'),
('ba44f214-e7cf-11dd-925e-6920adbc19ca', '_xIqlFefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessProcess', 'version', '2009-01-22 15:44:09'),
('ba44f214-e7cf-11dd-925e-6920adbc19ca', '_xIqlGufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessProcess', 'name', '2009-01-22 15:44:09'),
('ba44f214-e7cf-11dd-925e-6920adbc19ca', '_xIqlH-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessProcess', 'notes', '2009-01-22 15:44:09'),
('ba44f214-e7cf-11dd-925e-6920adbc19ca', '_xI0WEOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessProcess', 'created', '2009-01-22 15:44:09'),
('ba44f214-e7cf-11dd-925e-6920adbc19ca', '_xI0WFefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessProcess', 'creator', '2009-01-22 15:44:09'),
('ba44f214-e7cf-11dd-925e-6920adbc19ca', '_xI0WGufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessProcess', 'last_editor', '2009-01-22 15:44:09'),
('ba44f214-e7cf-11dd-925e-6920adbc19ca', '_xI0WH-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessProcess', 'modified', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiBusinessUseCase', '-', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_xKAo6ufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'id', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_xKAo5efPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'fk_package_id', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_xKAo4OfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'fk_chibusinessprocess_id', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_vgDokefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'primaryactor', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_vgDolufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'otheractors', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_vgNZgefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'goalincontext', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_vgNZhufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'scope', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_vgNZi-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'level', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_vgNZkOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'stakeholders', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_vgNZlefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'precondition', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_vgNZmufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'trigger', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_vgNZn-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'mainsuccessscenario', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_vgXKgufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'extensions', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_xJaL-ufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'alias', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_xJj89OfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'version', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_xJj8-efPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'name', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_xJj8_ufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'notes', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_xJj9A-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'created', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_xJj9COfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'creator', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_xJj9DefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'last_editor', '2009-01-22 15:44:09'),
('ba5349f9-e7cf-11dd-925e-6920adbc19ca', '_xJtt9OfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCase', 'modified', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiBusinessUseCaseCore', '-', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xLM7tefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'id', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xLM7sOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'fk_package_id', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xLDKsOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'fk_chibusinessprocess_id', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKTj2ufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'primaryactor', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKdU0-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'otheractors', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKdU2OfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'goalincontext', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKdU3efPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'scope', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKdU4ufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'level', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKdU5-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'stakeholders', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKmewOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'precondition', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKmexefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'trigger', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKmeyufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'mainsuccessscenario', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKmez-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'extensions', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKme1OfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'alias', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKme2efPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'version', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKwPwOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'name', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKwPxefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'notes', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKwPyufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'created', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKwPz-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'creator', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKwP1OfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'last_editor', '2009-01-22 15:44:09'),
('ba807484-e7cf-11dd-925e-6920adbc19ca', '_xKwP2efPEd2gQt5d1rMYcw', 'column', 'ChiBusinessUseCaseCore', 'modified', '2009-01-22 15:44:09'),
('ba82e585-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiBusinessPartnerActive', '-', '2009-01-22 15:44:09'),
('ba82e585-e7cf-11dd-925e-6920adbc19ca', '_xLpnoOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerActive', 'id', '2009-01-22 15:44:09'),
('ba82e585-e7cf-11dd-925e-6920adbc19ca', '_xLWFoOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerActive', 'alias', '2009-01-22 15:44:09'),
('ba82e585-e7cf-11dd-925e-6920adbc19ca', '_xLWFpefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerActive', 'version', '2009-01-22 15:44:09'),
('ba82e585-e7cf-11dd-925e-6920adbc19ca', '_xLWFqufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerActive', 'name', '2009-01-22 15:44:09'),
('ba82e585-e7cf-11dd-925e-6920adbc19ca', '_xLWFr-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerActive', 'notes', '2009-01-22 15:44:09'),
('ba82e585-e7cf-11dd-925e-6920adbc19ca', '_xLWFtOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerActive', 'created', '2009-01-22 15:44:09'),
('ba82e585-e7cf-11dd-925e-6920adbc19ca', '_xLWFuefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerActive', 'creator', '2009-01-22 15:44:09'),
('ba82e585-e7cf-11dd-925e-6920adbc19ca', '_xLf2pOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerActive', 'last_editor', '2009-01-22 15:44:09'),
('ba82e585-e7cf-11dd-925e-6920adbc19ca', '_xLf2qefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerActive', 'modified', '2009-01-22 15:44:09'),
('ba8a1178-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiBusinessPartnerPassive', '-', '2009-01-22 15:44:09'),
('ba8a1178-e7cf-11dd-925e-6920adbc19ca', '_xMGTkOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerPassive', 'id', '2009-01-22 15:44:09'),
('ba8a1178-e7cf-11dd-925e-6920adbc19ca', '_xLyxkOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerPassive', 'alias', '2009-01-22 15:44:09'),
('ba8a1178-e7cf-11dd-925e-6920adbc19ca', '_xLyxlefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerPassive', 'version', '2009-01-22 15:44:09'),
('ba8a1178-e7cf-11dd-925e-6920adbc19ca', '_xLyxmufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerPassive', 'name', '2009-01-22 15:44:09'),
('ba8a1178-e7cf-11dd-925e-6920adbc19ca', '_xLyxn-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerPassive', 'notes', '2009-01-22 15:44:09'),
('ba8a1178-e7cf-11dd-925e-6920adbc19ca', '_xLyxpOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerPassive', 'created', '2009-01-22 15:44:09'),
('ba8a1178-e7cf-11dd-925e-6920adbc19ca', '_xL8ilOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerPassive', 'creator', '2009-01-22 15:44:09'),
('ba8a1178-e7cf-11dd-925e-6920adbc19ca', '_xL8imefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerPassive', 'last_editor', '2009-01-22 15:44:09'),
('ba8a1178-e7cf-11dd-925e-6920adbc19ca', '_xL8inufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartnerPassive', 'modified', '2009-01-22 15:44:09'),
('ba8ecc6b-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiWorker', '-', '2009-01-22 15:44:09'),
('ba8ecc6b-e7cf-11dd-925e-6920adbc19ca', '_xMiYcOfPEd2gQt5d1rMYcw', 'column', 'ChiWorker', 'id', '2009-01-22 15:44:09'),
('ba8ecc6b-e7cf-11dd-925e-6920adbc19ca', '_xMPdgOfPEd2gQt5d1rMYcw', 'column', 'ChiWorker', 'alias', '2009-01-22 15:44:09'),
('ba8ecc6b-e7cf-11dd-925e-6920adbc19ca', '_xMPdhefPEd2gQt5d1rMYcw', 'column', 'ChiWorker', 'version', '2009-01-22 15:44:09'),
('ba8ecc6b-e7cf-11dd-925e-6920adbc19ca', '_xMPdiufPEd2gQt5d1rMYcw', 'column', 'ChiWorker', 'name', '2009-01-22 15:44:09'),
('ba8ecc6b-e7cf-11dd-925e-6920adbc19ca', '_xMZOhOfPEd2gQt5d1rMYcw', 'column', 'ChiWorker', 'notes', '2009-01-22 15:44:09'),
('ba8ecc6b-e7cf-11dd-925e-6920adbc19ca', '_xMZOiefPEd2gQt5d1rMYcw', 'column', 'ChiWorker', 'created', '2009-01-22 15:44:09'),
('ba8ecc6b-e7cf-11dd-925e-6920adbc19ca', '_xMZOjufPEd2gQt5d1rMYcw', 'column', 'ChiWorker', 'creator', '2009-01-22 15:44:09'),
('ba8ecc6b-e7cf-11dd-925e-6920adbc19ca', '_xMZOk-fPEd2gQt5d1rMYcw', 'column', 'ChiWorker', 'last_editor', '2009-01-22 15:44:09'),
('ba8ecc6b-e7cf-11dd-925e-6920adbc19ca', '_xMZOmOfPEd2gQt5d1rMYcw', 'column', 'ChiWorker', 'modified', '2009-01-22 15:44:09'),
('baa1df42-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiWorkerExternal', '-', '2009-01-22 15:44:09'),
('baa1df42-e7cf-11dd-925e-6920adbc19ca', '_xNI1YOfPEd2gQt5d1rMYcw', 'column', 'ChiWorkerExternal', 'id', '2009-01-22 15:44:09'),
('baa1df42-e7cf-11dd-925e-6920adbc19ca', '_vgXKjefPEd2gQt5d1rMYcw', 'column', 'ChiWorkerExternal', 'is_offlineuser', '2009-01-22 15:44:09'),
('baa1df42-e7cf-11dd-925e-6920adbc19ca', '_xMsJeufPEd2gQt5d1rMYcw', 'column', 'ChiWorkerExternal', 'alias', '2009-01-22 15:44:09'),
('baa1df42-e7cf-11dd-925e-6920adbc19ca', '_xMsJf-fPEd2gQt5d1rMYcw', 'column', 'ChiWorkerExternal', 'version', '2009-01-22 15:44:09'),
('baa1df42-e7cf-11dd-925e-6920adbc19ca', '_xMsJhOfPEd2gQt5d1rMYcw', 'column', 'ChiWorkerExternal', 'name', '2009-01-22 15:44:09'),
('baa1df42-e7cf-11dd-925e-6920adbc19ca', '_xM16dOfPEd2gQt5d1rMYcw', 'column', 'ChiWorkerExternal', 'notes', '2009-01-22 15:44:09'),
('baa1df42-e7cf-11dd-925e-6920adbc19ca', '_xM16eefPEd2gQt5d1rMYcw', 'column', 'ChiWorkerExternal', 'created', '2009-01-22 15:44:09'),
('baa1df42-e7cf-11dd-925e-6920adbc19ca', '_xM16fufPEd2gQt5d1rMYcw', 'column', 'ChiWorkerExternal', 'creator', '2009-01-22 15:44:09'),
('baa1df42-e7cf-11dd-925e-6920adbc19ca', '_xM16g-fPEd2gQt5d1rMYcw', 'column', 'ChiWorkerExternal', 'last_editor', '2009-01-22 15:44:09'),
('baa1df42-e7cf-11dd-925e-6920adbc19ca', '_xM16iOfPEd2gQt5d1rMYcw', 'column', 'ChiWorkerExternal', 'modified', '2009-01-22 15:44:09'),
('baa45043-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiWorkerInternal', '-', '2009-01-22 15:44:09'),
('baa45043-e7cf-11dd-925e-6920adbc19ca', '_xNlhUOfPEd2gQt5d1rMYcw', 'column', 'ChiWorkerInternal', 'id', '2009-01-22 15:44:09'),
('baa45043-e7cf-11dd-925e-6920adbc19ca', '_xNI1b-fPEd2gQt5d1rMYcw', 'column', 'ChiWorkerInternal', 'alias', '2009-01-22 15:44:09'),
('baa45043-e7cf-11dd-925e-6920adbc19ca', '_xNI1dOfPEd2gQt5d1rMYcw', 'column', 'ChiWorkerInternal', 'version', '2009-01-22 15:44:09'),
('baa45043-e7cf-11dd-925e-6920adbc19ca', '_xNSmY-fPEd2gQt5d1rMYcw', 'column', 'ChiWorkerInternal', 'name', '2009-01-22 15:44:09'),
('baa45043-e7cf-11dd-925e-6920adbc19ca', '_xNSmaOfPEd2gQt5d1rMYcw', 'column', 'ChiWorkerInternal', 'notes', '2009-01-22 15:44:09'),
('baa45043-e7cf-11dd-925e-6920adbc19ca', '_xNSmbefPEd2gQt5d1rMYcw', 'column', 'ChiWorkerInternal', 'created', '2009-01-22 15:44:09'),
('baa45043-e7cf-11dd-925e-6920adbc19ca', '_xNSmcufPEd2gQt5d1rMYcw', 'column', 'ChiWorkerInternal', 'creator', '2009-01-22 15:44:09'),
('baa45043-e7cf-11dd-925e-6920adbc19ca', '_xNSmd-fPEd2gQt5d1rMYcw', 'column', 'ChiWorkerInternal', 'last_editor', '2009-01-22 15:44:09'),
('baa45043-e7cf-11dd-925e-6920adbc19ca', '_xNSmfOfPEd2gQt5d1rMYcw', 'column', 'ChiWorkerInternal', 'modified', '2009-01-22 15:44:09'),
('baa69a34-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'Actor', '-', '2009-01-22 15:44:09'),
('baa69a34-e7cf-11dd-925e-6920adbc19ca', '_xOVINefPEd2gQt5d1rMYcw', 'column', 'Actor', 'id', '2009-01-22 15:44:09'),
('baa69a34-e7cf-11dd-925e-6920adbc19ca', '_xOVIMOfPEd2gQt5d1rMYcw', 'column', 'Actor', 'fk_package_id', '2009-01-22 15:44:09'),
('baa69a34-e7cf-11dd-925e-6920adbc19ca', '_xNurSufPEd2gQt5d1rMYcw', 'column', 'Actor', 'alias', '2009-01-22 15:44:09'),
('baa69a34-e7cf-11dd-925e-6920adbc19ca', '_xNurT-fPEd2gQt5d1rMYcw', 'column', 'Actor', 'version', '2009-01-22 15:44:09'),
('baa69a34-e7cf-11dd-925e-6920adbc19ca', '_xNurVOfPEd2gQt5d1rMYcw', 'column', 'Actor', 'name', '2009-01-22 15:44:09'),
('baa69a34-e7cf-11dd-925e-6920adbc19ca', '_xN4cROfPEd2gQt5d1rMYcw', 'column', 'Actor', 'notes', '2009-01-22 15:44:09'),
('baa69a34-e7cf-11dd-925e-6920adbc19ca', '_xN4cSefPEd2gQt5d1rMYcw', 'column', 'Actor', 'created', '2009-01-22 15:44:09'),
('baa69a34-e7cf-11dd-925e-6920adbc19ca', '_xN4cTufPEd2gQt5d1rMYcw', 'column', 'Actor', 'creator', '2009-01-22 15:44:09'),
('baa69a34-e7cf-11dd-925e-6920adbc19ca', '_xN4cU-fPEd2gQt5d1rMYcw', 'column', 'Actor', 'last_editor', '2009-01-22 15:44:09'),
('baa69a34-e7cf-11dd-925e-6920adbc19ca', '_xN4cWOfPEd2gQt5d1rMYcw', 'column', 'Actor', 'modified', '2009-01-22 15:44:09'),
('be05cb72-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiBusinessPartner', '-', '2009-01-22 15:44:09'),
('be05cb72-e7cf-11dd-925e-6920adbc19ca', '_xPEvFefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartner', 'id', '2009-01-22 15:44:09'),
('be05cb72-e7cf-11dd-925e-6920adbc19ca', '_xPEvEOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartner', 'fk_package_id', '2009-01-22 15:44:09'),
('be05cb72-e7cf-11dd-925e-6920adbc19ca', '_xOoDKufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartner', 'alias', '2009-01-22 15:44:09'),
('be05cb72-e7cf-11dd-925e-6920adbc19ca', '_xOoDL-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartner', 'version', '2009-01-22 15:44:09'),
('be05cb72-e7cf-11dd-925e-6920adbc19ca', '_xOoDNOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartner', 'name', '2009-01-22 15:44:09'),
('be05cb72-e7cf-11dd-925e-6920adbc19ca', '_xOx0I-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartner', 'notes', '2009-01-22 15:44:09'),
('be05cb72-e7cf-11dd-925e-6920adbc19ca', '_xOx0KOfPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartner', 'created', '2009-01-22 15:44:09'),
('be05cb72-e7cf-11dd-925e-6920adbc19ca', '_xOx0LefPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartner', 'creator', '2009-01-22 15:44:09'),
('be05cb72-e7cf-11dd-925e-6920adbc19ca', '_xOx0MufPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartner', 'last_editor', '2009-01-22 15:44:09'),
('be05cb72-e7cf-11dd-925e-6920adbc19ca', '_xOx0N-fPEd2gQt5d1rMYcw', 'column', 'ChiBusinessPartner', 'modified', '2009-01-22 15:44:09'),
('badb17ba-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiGoalType', '-', '2009-01-22 15:44:09'),
('badb17ba-e7cf-11dd-925e-6920adbc19ca', '_xPhbAOfPEd2gQt5d1rMYcw', 'column', 'ChiGoalType', 'id', '2009-01-22 15:44:09'),
('badb17ba-e7cf-11dd-925e-6920adbc19ca', '_xPOgEOfPEd2gQt5d1rMYcw', 'column', 'ChiGoalType', 'name', '2009-01-22 15:44:09'),
('badb17ba-e7cf-11dd-925e-6920adbc19ca', '_xPOgFefPEd2gQt5d1rMYcw', 'column', 'ChiGoalType', 'notes', '2009-01-22 15:44:09'),
('badb17ba-e7cf-11dd-925e-6920adbc19ca', '_xPOgGufPEd2gQt5d1rMYcw', 'column', 'ChiGoalType', 'created', '2009-01-22 15:44:09'),
('badb17ba-e7cf-11dd-925e-6920adbc19ca', '_xPOgH-fPEd2gQt5d1rMYcw', 'column', 'ChiGoalType', 'creator', '2009-01-22 15:44:09'),
('badb17ba-e7cf-11dd-925e-6920adbc19ca', '_xPXqAOfPEd2gQt5d1rMYcw', 'column', 'ChiGoalType', 'last_editor', '2009-01-22 15:44:09'),
('badb17ba-e7cf-11dd-925e-6920adbc19ca', '_xPXqBefPEd2gQt5d1rMYcw', 'column', 'ChiGoalType', 'modified', '2009-01-22 15:44:09'),
('bae243ad-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'NMFeatureRequirements', '-', '2009-01-22 15:44:09'),
('bae243ad-e7cf-11dd-925e-6920adbc19ca', '_xP-G-ufPEd2gQt5d1rMYcw', 'column', 'NMFeatureRequirements', 'id', '2009-01-22 15:44:09'),
('bae243ad-e7cf-11dd-925e-6920adbc19ca', '_xP-G9efPEd2gQt5d1rMYcw', 'column', 'NMFeatureRequirements', 'fk_chifeature_id', '2009-01-22 15:44:09'),
('bae243ad-e7cf-11dd-925e-6920adbc19ca', '_xP-G8OfPEd2gQt5d1rMYcw', 'column', 'NMFeatureRequirements', 'fk_chirequirement_id', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiGoal', '-', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_xQ3e2ufPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'id', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_xQ3e1efPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'fk_package_id', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_xQ3e0OfPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'fk_chigoal_id', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_vggUiOfPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'goaltype', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_vggUi-fPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'value_name', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_vggUkOfPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'value_ammount', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_vgqFcefPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'value_goal', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_xQay4OfPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'alias', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_xQay5efPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'version', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_xQay6ufPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'name', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_xQay7-fPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'notes', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_xQay9OfPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'created', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_xQj81OfPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'creator', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_xQj82efPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'last_editor', '2009-01-22 15:44:09'),
('baf2e582-e7cf-11dd-925e-6920adbc19ca', '_xQj83ufPEd2gQt5d1rMYcw', 'column', 'ChiGoal', 'modified', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiRequirement', '-', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_xRwPr-fPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'id', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_xRwPqufPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'fk_package_id', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_xRwPpefPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'fk_chirequirement_id', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_xRwPoOfPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'fk_chigoal_id', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_vgqFd-fPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'reqtype', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_vgqFeufPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'priority', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_vgqFf-fPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'author', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_vgqFhOfPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'proofreader', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_vgqFiefPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'status', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_xRTjs-fPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'alias', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_xRTjuOfPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'version', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_xRTjvefPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'name', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_xRTjwufPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'notes', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_xRdUsOfPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'created', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_xRdUtefPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'creator', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_xRdUuufPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'last_editor', '2009-01-22 15:44:09'),
('bb14503b-e7cf-11dd-925e-6920adbc19ca', '_xRdUv-fPEd2gQt5d1rMYcw', 'column', 'ChiRequirement', 'modified', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiFeature', '-', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_xSf2hefPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'id', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_xSf2gOfPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'fk_package_id', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_vgqFjefPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'author', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_vgz2cOfPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'proofreader', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_vgz2dufPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'status', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_xSDxqufPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'alias', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_xSDxr-fPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'version', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_xSDxtOfPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'name', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_xSM7kOfPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'notes', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_xSM7lefPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'created', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_xSM7mufPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'creator', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_xSM7n-fPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'last_editor', '2009-01-22 15:44:09'),
('bb3a75e4-e7cf-11dd-925e-6920adbc19ca', '_xSM7pOfPEd2gQt5d1rMYcw', 'column', 'ChiFeature', 'modified', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiIssue', '-', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_xU4cKufPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'id', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_xU4cJefPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'fk_package_id', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_xU4cIOfPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'fk_chirequirement_id', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_vgz2fOfPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'author', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_vgz2gefPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'responsible', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_xUcXSufPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'alias', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_xUcXT-fPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'version', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_xUcXVOfPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'name', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_xUcXWefPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'notes', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_xUlhM-fPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'created', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_xUlhOOfPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'creator', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_xUlhPefPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'last_editor', '2009-01-22 15:44:09'),
('bb4d88ba-e7cf-11dd-925e-6920adbc19ca', '_xUlhQufPEd2gQt5d1rMYcw', 'column', 'ChiIssue', 'modified', '2009-01-22 15:44:09'),
('bb609b8f-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiFeatureStatus', '-', '2009-01-22 15:44:09'),
('bb609b8f-e7cf-11dd-925e-6920adbc19ca', '_xVVIEOfPEd2gQt5d1rMYcw', 'column', 'ChiFeatureStatus', 'id', '2009-01-22 15:44:09'),
('bb609b8f-e7cf-11dd-925e-6920adbc19ca', '_xVCNIOfPEd2gQt5d1rMYcw', 'column', 'ChiFeatureStatus', 'name', '2009-01-22 15:44:09'),
('bb609b8f-e7cf-11dd-925e-6920adbc19ca', '_xVCNJefPEd2gQt5d1rMYcw', 'column', 'ChiFeatureStatus', 'notes', '2009-01-22 15:44:09'),
('bb609b8f-e7cf-11dd-925e-6920adbc19ca', '_xVCNKufPEd2gQt5d1rMYcw', 'column', 'ChiFeatureStatus', 'created', '2009-01-22 15:44:09'),
('bb609b8f-e7cf-11dd-925e-6920adbc19ca', '_xVCNL-fPEd2gQt5d1rMYcw', 'column', 'ChiFeatureStatus', 'creator', '2009-01-22 15:44:09'),
('bb609b8f-e7cf-11dd-925e-6920adbc19ca', '_xVL-JOfPEd2gQt5d1rMYcw', 'column', 'ChiFeatureStatus', 'last_editor', '2009-01-22 15:44:09'),
('bb609b8f-e7cf-11dd-925e-6920adbc19ca', '_xVL-KefPEd2gQt5d1rMYcw', 'column', 'ChiFeatureStatus', 'modified', '2009-01-22 15:44:09'),
('bb67c782-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiRequirementStatus', '-', '2009-01-22 15:44:09'),
('bb67c782-e7cf-11dd-925e-6920adbc19ca', '_xVoqEOfPEd2gQt5d1rMYcw', 'column', 'ChiRequirementStatus', 'id', '2009-01-22 15:44:09'),
('bb67c782-e7cf-11dd-925e-6920adbc19ca', '_xVVIFefPEd2gQt5d1rMYcw', 'column', 'ChiRequirementStatus', 'name', '2009-01-22 15:44:09'),
('bb67c782-e7cf-11dd-925e-6920adbc19ca', '_xVVIGufPEd2gQt5d1rMYcw', 'column', 'ChiRequirementStatus', 'notes', '2009-01-22 15:44:09'),
('bb67c782-e7cf-11dd-925e-6920adbc19ca', '_xVe5E-fPEd2gQt5d1rMYcw', 'column', 'ChiRequirementStatus', 'created', '2009-01-22 15:44:09'),
('bb67c782-e7cf-11dd-925e-6920adbc19ca', '_xVe5GOfPEd2gQt5d1rMYcw', 'column', 'ChiRequirementStatus', 'creator', '2009-01-22 15:44:09'),
('bb67c782-e7cf-11dd-925e-6920adbc19ca', '_xVe5HefPEd2gQt5d1rMYcw', 'column', 'ChiRequirementStatus', 'last_editor', '2009-01-22 15:44:09'),
('bb67c782-e7cf-11dd-925e-6920adbc19ca', '_xVe5IufPEd2gQt5d1rMYcw', 'column', 'ChiRequirementStatus', 'modified', '2009-01-22 15:44:09'),
('bb6c8275-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiRequirementType', '-', '2009-01-22 15:44:09'),
('bb6c8275-e7cf-11dd-925e-6920adbc19ca', '_xWEu8OfPEd2gQt5d1rMYcw', 'column', 'ChiRequirementType', 'id', '2009-01-22 15:44:09'),
('bb6c8275-e7cf-11dd-925e-6920adbc19ca', '_xVx0AOfPEd2gQt5d1rMYcw', 'column', 'ChiRequirementType', 'name', '2009-01-22 15:44:09'),
('bb6c8275-e7cf-11dd-925e-6920adbc19ca', '_xVx0BefPEd2gQt5d1rMYcw', 'column', 'ChiRequirementType', 'notes', '2009-01-22 15:44:09'),
('bb6c8275-e7cf-11dd-925e-6920adbc19ca', '_xVx0CufPEd2gQt5d1rMYcw', 'column', 'ChiRequirementType', 'created', '2009-01-22 15:44:09'),
('bb6c8275-e7cf-11dd-925e-6920adbc19ca', '_xVx0D-fPEd2gQt5d1rMYcw', 'column', 'ChiRequirementType', 'creator', '2009-01-22 15:44:09'),
('bb6c8275-e7cf-11dd-925e-6920adbc19ca', '_xVx0FOfPEd2gQt5d1rMYcw', 'column', 'ChiRequirementType', 'last_editor', '2009-01-22 15:44:09'),
('bb6c8275-e7cf-11dd-925e-6920adbc19ca', '_xVx0GefPEd2gQt5d1rMYcw', 'column', 'ChiRequirementType', 'modified', '2009-01-22 15:44:09'),
('bba82be9-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiController', '-', '2009-01-22 15:44:09'),
('bba82be9-e7cf-11dd-925e-6920adbc19ca', '_xW084OfPEd2gQt5d1rMYcw', 'column', 'ChiController', 'id', '2009-01-22 15:44:09'),
('bba82be9-e7cf-11dd-925e-6920adbc19ca', '_xWrL4OfPEd2gQt5d1rMYcw', 'column', 'ChiController', 'fk_package_id', '2009-01-22 15:44:09'),
('bba82be9-e7cf-11dd-925e-6920adbc19ca', '_xWOf-ufPEd2gQt5d1rMYcw', 'column', 'ChiController', 'alias', '2009-01-22 15:44:09'),
('bba82be9-e7cf-11dd-925e-6920adbc19ca', '_xWOf_-fPEd2gQt5d1rMYcw', 'column', 'ChiController', 'version', '2009-01-22 15:44:09'),
('bba82be9-e7cf-11dd-925e-6920adbc19ca', '_xWYQ8OfPEd2gQt5d1rMYcw', 'column', 'ChiController', 'name', '2009-01-22 15:44:09'),
('bba82be9-e7cf-11dd-925e-6920adbc19ca', '_xWYQ9efPEd2gQt5d1rMYcw', 'column', 'ChiController', 'notes', '2009-01-22 15:44:09'),
('bba82be9-e7cf-11dd-925e-6920adbc19ca', '_xWYQ-ufPEd2gQt5d1rMYcw', 'column', 'ChiController', 'created', '2009-01-22 15:44:09');
INSERT INTO `dbupdate` (`table_id`, `column_id`, `type`, `table`, `column`, `updated`) VALUES
('bba82be9-e7cf-11dd-925e-6920adbc19ca', '_xWYQ_-fPEd2gQt5d1rMYcw', 'column', 'ChiController', 'creator', '2009-01-22 15:44:09'),
('bba82be9-e7cf-11dd-925e-6920adbc19ca', '_xWYRBOfPEd2gQt5d1rMYcw', 'column', 'ChiController', 'last_editor', '2009-01-22 15:44:09'),
('bba82be9-e7cf-11dd-925e-6920adbc19ca', '_xWYRCefPEd2gQt5d1rMYcw', 'column', 'ChiController', 'modified', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiNode', '-', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_xXtttefPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'id', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_xXttsOfPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'fk_package_id', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_xXkjwOfPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'fk_chicontroller_id', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_vhP7WOfPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'display_value', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_vhP7XefPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'parent_order', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_vhP7YufPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'child_order', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_vhP7Z-fPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'pk_name', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_vhP7bOfPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'is_searchable', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_vhP7cefPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'orderby', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_vhP7dufPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'is_soap', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_vhZsUufPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'initparams', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_vhZsV-fPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'table_name', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_vhZsW-fPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'is_ordered', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_xXH32ufPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'alias', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_xXH33-fPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'version', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_xXH35OfPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'name', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_xXRBxOfPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'notes', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_xXRByefPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'created', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_xXRBzufPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'creator', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_xXRB0-fPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'last_editor', '2009-01-22 15:44:09'),
('bbbdafc0-e7cf-11dd-925e-6920adbc19ca', '_xXRB2OfPEd2gQt5d1rMYcw', 'column', 'ChiNode', 'modified', '2009-01-22 15:44:09'),
('bc40c298-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'ChiAuthors', '-', '2009-01-22 15:44:09'),
('bc40c298-e7cf-11dd-925e-6920adbc19ca', '_xc7k4OfPEd2gQt5d1rMYcw', 'column', 'ChiAuthors', 'id', '2009-01-22 15:44:09'),
('bc40c298-e7cf-11dd-925e-6920adbc19ca', '_vhsnUefPEd2gQt5d1rMYcw', 'column', 'ChiAuthors', 'role', '2009-01-22 15:44:09'),
('bc40c298-e7cf-11dd-925e-6920adbc19ca', '_xcop9efPEd2gQt5d1rMYcw', 'column', 'ChiAuthors', 'name', '2009-01-22 15:44:09'),
('bc40c298-e7cf-11dd-925e-6920adbc19ca', '_xcop-ufPEd2gQt5d1rMYcw', 'column', 'ChiAuthors', 'notes', '2009-01-22 15:44:09'),
('bc40c298-e7cf-11dd-925e-6920adbc19ca', '_xcop_-fPEd2gQt5d1rMYcw', 'column', 'ChiAuthors', 'created', '2009-01-22 15:44:09'),
('bc40c298-e7cf-11dd-925e-6920adbc19ca', '_xcya9OfPEd2gQt5d1rMYcw', 'column', 'ChiAuthors', 'creator', '2009-01-22 15:44:09'),
('bc40c298-e7cf-11dd-925e-6920adbc19ca', '_xcya-efPEd2gQt5d1rMYcw', 'column', 'ChiAuthors', 'last_editor', '2009-01-22 15:44:09'),
('bc40c298-e7cf-11dd-925e-6920adbc19ca', '_xcya_ufPEd2gQt5d1rMYcw', 'column', 'ChiAuthors', 'modified', '2009-01-22 15:44:09'),
('bcae7892-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'Diagram', '-', '2009-01-22 15:44:09'),
('bcae7892-e7cf-11dd-925e-6920adbc19ca', '_xeH3tefPEd2gQt5d1rMYcw', 'column', 'Diagram', 'id', '2009-01-22 15:44:09'),
('bcae7892-e7cf-11dd-925e-6920adbc19ca', '_xeH3sOfPEd2gQt5d1rMYcw', 'column', 'Diagram', 'fk_package_id', '2009-01-22 15:44:09'),
('bcae7892-e7cf-11dd-925e-6920adbc19ca', '_vicOM-fPEd2gQt5d1rMYcw', 'column', 'Diagram', 'width', '2009-01-22 15:44:09'),
('bcae7892-e7cf-11dd-925e-6920adbc19ca', '_vicOOOfPEd2gQt5d1rMYcw', 'column', 'Diagram', 'height', '2009-01-22 15:44:09'),
('bcae7892-e7cf-11dd-925e-6920adbc19ca', '_xdrLwOfPEd2gQt5d1rMYcw', 'column', 'Diagram', 'name', '2009-01-22 15:44:09'),
('bcae7892-e7cf-11dd-925e-6920adbc19ca', '_xd08wOfPEd2gQt5d1rMYcw', 'column', 'Diagram', 'notes', '2009-01-22 15:44:09'),
('bcae7892-e7cf-11dd-925e-6920adbc19ca', '_xd08xefPEd2gQt5d1rMYcw', 'column', 'Diagram', 'created', '2009-01-22 15:44:09'),
('bcae7892-e7cf-11dd-925e-6920adbc19ca', '_xd08yufPEd2gQt5d1rMYcw', 'column', 'Diagram', 'creator', '2009-01-22 15:44:09'),
('bcae7892-e7cf-11dd-925e-6920adbc19ca', '_xd08z-fPEd2gQt5d1rMYcw', 'column', 'Diagram', 'last_editor', '2009-01-22 15:44:09'),
('bcae7892-e7cf-11dd-925e-6920adbc19ca', '_xd081OfPEd2gQt5d1rMYcw', 'column', 'Diagram', 'modified', '2009-01-22 15:44:09'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'Figure', '-', '2009-01-22 15:44:09'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xggdUOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'id', '2009-01-22 15:44:09'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgXTdOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chibusinesspartnerpassive_id', '2009-01-22 15:44:09'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgXTb-fPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chibusinesspartneractive_id', '2009-01-22 15:44:09'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgXTaufPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chiworker_id', '2009-01-22 15:44:09'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgXTZefPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chiview_id', '2009-01-22 15:44:09'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgXTYOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chivalue_id', '2009-01-22 15:44:09'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgNib-fPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chinode_id', '2009-01-22 15:44:09'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgNiaufPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chicontroller_id', '2009-01-22 15:44:09'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgNiZefPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chiissue_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgNiYOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chifeature_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgDxdOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chirequirement_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgDxb-fPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chigoal_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgDxaufPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chibusinesspartner_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgDxZefPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_actor_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xgDxYOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chibusinessusecasecore_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xf6nhOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chibusinessusecase_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xf6nf-fPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chibusinessprocess_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xf6neufPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_activityfinal_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xf6ndefPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_activityinitial_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xf6ncOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_activity_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xfw2f-fPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_activitysend_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xfw2eufPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_activityreceive_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xfw2defPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_activitydecision_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xfw2cOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_diagram_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xfnFcOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'fk_chibase_id', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_vil_QufPEd2gQt5d1rMYcw', 'column', 'Figure', 'backgroundcolor', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_vivwIOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'foregroundcolor', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_vivwJefPEd2gQt5d1rMYcw', 'column', 'Figure', 'gid', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_vivwKefPEd2gQt5d1rMYcw', 'column', 'Figure', 'height', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_vivwLefPEd2gQt5d1rMYcw', 'column', 'Figure', 'positiony', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_vivwMufPEd2gQt5d1rMYcw', 'column', 'Figure', 'positionx', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_vivwN-fPEd2gQt5d1rMYcw', 'column', 'Figure', 'width', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xfUKgOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'created', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xfUKhefPEd2gQt5d1rMYcw', 'column', 'Figure', 'creator', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xfUKiufPEd2gQt5d1rMYcw', 'column', 'Figure', 'last_editor', '2009-01-22 15:44:10'),
('bcfd0dd5-e7cf-11dd-925e-6920adbc19ca', '_xfd7hOfPEd2gQt5d1rMYcw', 'column', 'Figure', 'modified', '2009-01-22 15:44:10'),
('bd06aac6-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'Model', '-', '2009-01-22 15:44:10'),
('bd06aac6-e7cf-11dd-925e-6920adbc19ca', '_xg9JQOfPEd2gQt5d1rMYcw', 'column', 'Model', 'id', '2009-01-22 15:44:10'),
('bd06aac6-e7cf-11dd-925e-6920adbc19ca', '_xgqOUOfPEd2gQt5d1rMYcw', 'column', 'Model', 'name', '2009-01-22 15:44:10'),
('bd06aac6-e7cf-11dd-925e-6920adbc19ca', '_xgqOVefPEd2gQt5d1rMYcw', 'column', 'Model', 'notes', '2009-01-22 15:44:10'),
('bd06aac6-e7cf-11dd-925e-6920adbc19ca', '_xgqOWufPEd2gQt5d1rMYcw', 'column', 'Model', 'created', '2009-01-22 15:44:10'),
('bd06aac6-e7cf-11dd-925e-6920adbc19ca', '_xgqOX-fPEd2gQt5d1rMYcw', 'column', 'Model', 'creator', '2009-01-22 15:44:10'),
('bd06aac6-e7cf-11dd-925e-6920adbc19ca', '_xgzYQOfPEd2gQt5d1rMYcw', 'column', 'Model', 'last_editor', '2009-01-22 15:44:10'),
('bd06aac6-e7cf-11dd-925e-6920adbc19ca', '_xgzYRefPEd2gQt5d1rMYcw', 'column', 'Model', 'modified', '2009-01-22 15:44:10'),
('bd0dd6b9-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'NMFiguresDiagram', '-', '2009-01-22 15:44:10'),
('bd0dd6b9-e7cf-11dd-925e-6920adbc19ca', '_xhQEMOfPEd2gQt5d1rMYcw', 'column', 'NMFiguresDiagram', 'id', '2009-01-22 15:44:10'),
('bd0dd6b9-e7cf-11dd-925e-6920adbc19ca', '_xg9JRefPEd2gQt5d1rMYcw', 'column', 'NMFiguresDiagram', 'created', '2009-01-22 15:44:10'),
('bd0dd6b9-e7cf-11dd-925e-6920adbc19ca', '_xg9JSufPEd2gQt5d1rMYcw', 'column', 'NMFiguresDiagram', 'creator', '2009-01-22 15:44:10'),
('bd0dd6b9-e7cf-11dd-925e-6920adbc19ca', '_xg9JT-fPEd2gQt5d1rMYcw', 'column', 'NMFiguresDiagram', 'last_editor', '2009-01-22 15:44:10'),
('bd0dd6b9-e7cf-11dd-925e-6920adbc19ca', '_xg9JVOfPEd2gQt5d1rMYcw', 'column', 'NMFiguresDiagram', 'modified', '2009-01-22 15:44:10'),
('bd1020aa-e7cf-11dd-925e-6920adbc19ca', '-', 'table', 'Package', '-', '2009-01-22 15:44:10'),
('bd1020aa-e7cf-11dd-925e-6920adbc19ca', '_xicXCufPEd2gQt5d1rMYcw', 'column', 'Package', 'id', '2009-01-22 15:44:10'),
('bd1020aa-e7cf-11dd-925e-6920adbc19ca', '_xicXBefPEd2gQt5d1rMYcw', 'column', 'Package', 'fk_package_id', '2009-01-22 15:44:10'),
('bd1020aa-e7cf-11dd-925e-6920adbc19ca', '_xicXAOfPEd2gQt5d1rMYcw', 'column', 'Package', 'fk_model_id', '2009-01-22 15:44:10'),
('bd1020aa-e7cf-11dd-925e-6920adbc19ca', '_xh_rEOfPEd2gQt5d1rMYcw', 'column', 'Package', 'name', '2009-01-22 15:44:10'),
('bd1020aa-e7cf-11dd-925e-6920adbc19ca', '_xh_rFefPEd2gQt5d1rMYcw', 'column', 'Package', 'notes', '2009-01-22 15:44:10'),
('bd1020aa-e7cf-11dd-925e-6920adbc19ca', '_xh_rGufPEd2gQt5d1rMYcw', 'column', 'Package', 'created', '2009-01-22 15:44:10'),
('bd1020aa-e7cf-11dd-925e-6920adbc19ca', '_xh_rH-fPEd2gQt5d1rMYcw', 'column', 'Package', 'creator', '2009-01-22 15:44:10'),
('bd1020aa-e7cf-11dd-925e-6920adbc19ca', '_xiJcEOfPEd2gQt5d1rMYcw', 'column', 'Package', 'last_editor', '2009-01-22 15:44:10'),
('bd1020aa-e7cf-11dd-925e-6920adbc19ca', '_xiJcFefPEd2gQt5d1rMYcw', 'column', 'Package', 'modified', '2009-01-22 15:44:10');

-- --------------------------------------------------------

--
-- Table structure for table `Diagram`
--

CREATE TABLE IF NOT EXISTS `Diagram` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `width` varchar(255) default NULL,
  `height` varchar(255) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Diagram`
--

INSERT INTO `Diagram` (`id`, `fk_chibusinessprocess_id`, `fk_package_id`, `width`, `height`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`) VALUES
(20936, NULL, 9694, NULL, NULL, NULL, NULL, 'Interface specification', NULL, '2009-03-04 16:59:36', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:59:55'),
(7702, NULL, 7673, NULL, NULL, NULL, NULL, 'Goals Overview', NULL, '2009-02-04 10:33:05', 'marco.eilers', 'marco.eilers', '2009-02-04 10:33:23'),
(7838, NULL, 7641, NULL, NULL, NULL, NULL, 'General Overview', NULL, '2009-02-04 11:00:04', 'marco.eilers', 'marco.eilers', '2009-02-04 11:00:19'),
(7847, NULL, 7653, NULL, NULL, NULL, NULL, 'Requirements Overview', NULL, '2009-02-04 11:00:39', 'marco.eilers', 'marco.eilers', '2009-02-04 11:00:52'),
(8146, NULL, 8143, NULL, NULL, NULL, NULL, 'Issues Overview', NULL, '2009-02-04 11:43:41', 'marco.eilers', 'marco.eilers', '2009-02-04 11:44:16'),
(8226, NULL, 7652, NULL, NULL, NULL, NULL, 'Features Overview', NULL, '2009-02-04 11:51:53', 'marco.eilers', 'marco.eilers', '2009-02-04 11:52:13'),
(9433, NULL, 9430, NULL, NULL, NULL, NULL, 'Processes Overview', NULL, '2009-02-04 16:24:11', 'marco.eilers', 'marco.eilers', '2009-02-04 16:24:26'),
(9440, NULL, 9437, NULL, NULL, NULL, NULL, 'Actors Overview', NULL, '2009-02-04 16:24:52', 'marco.eilers', 'marco.eilers', '2009-02-04 16:25:06'),
(9697, NULL, 9694, NULL, NULL, NULL, NULL, 'Use Cases Overview', NULL, '2009-02-05 10:40:36', 'marco.eilers', 'marco.eilers', '2009-02-05 10:41:25'),
(12202, NULL, 12099, NULL, NULL, NULL, NULL, 'Goals overview', NULL, '2009-02-10 17:57:58', 'pgiuseppe', 'pgiuseppe', '2009-02-10 18:42:05'),
(12267, NULL, 12138, NULL, NULL, NULL, NULL, 'Issues overview', NULL, '2009-02-10 18:06:43', 'pgiuseppe', 'pgiuseppe', '2009-02-11 11:28:10'),
(12214, NULL, 12143, NULL, NULL, NULL, NULL, 'Actors overview', NULL, '2009-02-10 17:58:51', 'pgiuseppe', 'pgiuseppe', '2009-02-11 16:06:21'),
(12496, NULL, 12390, NULL, NULL, NULL, NULL, 'Processes overview', NULL, '2009-02-11 11:27:26', 'pgiuseppe', 'pgiuseppe', '2009-02-11 11:27:45'),
(12232, NULL, 12106, NULL, NULL, NULL, NULL, 'Requirements overview', NULL, '2009-02-10 18:00:14', 'pgiuseppe', 'pgiuseppe', '2009-02-11 11:28:55'),
(12235, NULL, 12126, NULL, NULL, NULL, NULL, 'Features overview ', NULL, '2009-02-10 18:00:25', 'pgiuseppe', 'pgiuseppe', '2009-02-11 11:28:22'),
(12257, NULL, 12148, NULL, NULL, NULL, NULL, 'Use Cases overview ', NULL, '2009-02-10 18:05:24', 'pgiuseppe', 'pgiuseppe', '2009-02-11 11:27:59'),
(12465, NULL, 12468, NULL, NULL, NULL, NULL, 'Services  Cases overview ', NULL, '2009-02-10 19:42:18', 'pgiuseppe', 'pgiuseppe', '2009-02-11 11:46:05'),
(12527, NULL, 12098, NULL, NULL, NULL, NULL, 'Requirements overview', NULL, '2009-02-11 11:29:10', 'pgiuseppe', 'pgiuseppe', '2009-02-11 11:29:22'),
(12531, NULL, 12458, NULL, NULL, NULL, NULL, 'Domain Objects overview ', NULL, '2009-02-11 11:29:38', 'pgiuseppe', 'pgiuseppe', '2009-02-11 11:49:39'),
(12534, NULL, 12473, NULL, NULL, NULL, NULL, 'Views overview ', NULL, '2009-02-11 11:31:52', 'pgiuseppe', 'pgiuseppe', '2009-02-11 11:49:18'),
(12549, NULL, 12455, NULL, NULL, NULL, NULL, 'Domain Overview', NULL, '2009-02-11 11:49:48', 'pgiuseppe', 'pgiuseppe', '2009-02-11 11:50:21'),
(21055, NULL, 7673, NULL, NULL, NULL, NULL, 'vision mission', NULL, '2009-03-05 13:29:02', 'pgiuseppe', 'pgiuseppe', '2009-03-05 14:16:26'),
(21007, NULL, 21002, NULL, NULL, NULL, NULL, 'New Diagram', NULL, '2009-03-04 17:32:29', 'ibm', 'ibm', '2009-03-04 17:32:31'),
(15932, NULL, 12142, NULL, NULL, NULL, NULL, 'Analysis overview', NULL, '2009-02-20 14:27:17', 'pgiuseppe', 'pgiuseppe', '2009-02-20 14:27:34'),
(18654, NULL, 9694, NULL, NULL, NULL, NULL, 'Use cases candidates', NULL, '2009-02-27 14:13:30', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:10:07'),
(21243, NULL, 7652, NULL, NULL, NULL, NULL, 'requirements features diagram', NULL, '2009-03-05 14:49:29', 'pgiuseppe', 'pgiuseppe', '2009-03-05 14:51:30');

-- --------------------------------------------------------

--
-- Table structure for table `DisplayType`
--

CREATE TABLE IF NOT EXISTS `DisplayType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `DisplayType`
--


-- --------------------------------------------------------

--
-- Table structure for table `EntityBase`
--

CREATE TABLE IF NOT EXISTS `EntityBase` (
  `id` int(11) NOT NULL,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `EntityBase`
--


-- --------------------------------------------------------

--
-- Table structure for table `EntityBaseExtended`
--

CREATE TABLE IF NOT EXISTS `EntityBaseExtended` (
  `id` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `EntityBaseExtended`
--


-- --------------------------------------------------------

--
-- Table structure for table `Figure`
--

CREATE TABLE IF NOT EXISTS `Figure` (
  `id` int(11) NOT NULL,
  `fk_chigoal_id` int(11) default NULL,
  `fk_chifeature_id` int(11) default NULL,
  `fk_chirequirement_id` int(11) default NULL,
  `fk_chiissue_id` int(11) default NULL,
  `fk_chivalue_id` int(11) default NULL,
  `fk_chiview_id` int(11) default NULL,
  `fk_chinode_id` int(11) default NULL,
  `fk_chicontroller_id` int(11) default NULL,
  `fk_chibusinessusecasecore_id` int(11) default NULL,
  `fk_chibusinessusecase_id` int(11) default NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_chiworkerexternal_id` int(11) default NULL,
  `fk_chiworkerinternal_id` int(11) default NULL,
  `fk_chiworker_id` int(11) default NULL,
  `fk_chibusinesspartneractive_id` int(11) default NULL,
  `fk_chibusinesspartnerpassive_id` int(11) default NULL,
  `fk_chibusinesspartner_id` int(11) default NULL,
  `fk_actor_id` int(11) default NULL,
  `fk_chibase_id` int(11) default NULL,
  `backgroundcolor` varchar(255) default NULL,
  `foregroundcolor` varchar(255) default NULL,
  `gid` varchar(255) default NULL,
  `positiony` varchar(255) default NULL,
  `positionx` varchar(255) default NULL,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_diagram_id` int(11) default NULL,
  `height` varchar(255) default NULL,
  `width` varchar(255) default NULL,
  `fk_activityfinal_id` int(11) default NULL,
  `fk_activityinitial_id` int(11) default NULL,
  `fk_activity_id` int(11) default NULL,
  `fk_activitysend_id` int(11) default NULL,
  `fk_activityreceive_id` int(11) default NULL,
  `fk_activitydecision_id` int(11) default NULL,
  `fk_activityset_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Figure`
--

INSERT INTO `Figure` (`id`, `fk_chigoal_id`, `fk_chifeature_id`, `fk_chirequirement_id`, `fk_chiissue_id`, `fk_chivalue_id`, `fk_chiview_id`, `fk_chinode_id`, `fk_chicontroller_id`, `fk_chibusinessusecasecore_id`, `fk_chibusinessusecase_id`, `fk_chibusinessprocess_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_actor_id`, `fk_chibase_id`, `backgroundcolor`, `foregroundcolor`, `gid`, `positiony`, `positionx`, `created`, `creator`, `last_editor`, `modified`, `fk_diagram_id`, `height`, `width`, `fk_activityfinal_id`, `fk_activityinitial_id`, `fk_activity_id`, `fk_activitysend_id`, `fk_activityreceive_id`, `fk_activitydecision_id`, `fk_activityset_id`) VALUES
(20537, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9956, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5395', '5741', '2009-03-04 16:05:48', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:06:15', 18654, '79', '116', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20532, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9950, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5273', '5741', '2009-03-04 16:05:46', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:06:19', 18654, '79', '116', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20527, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9944, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5140', '5741', '2009-03-04 16:05:43', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:06:21', 18654, '79', '116', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20542, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9961, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5513', '5756', '2009-03-04 16:05:51', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:06:13', 18654, '79', '116', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20615, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9679, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6101', '5680', '2009-03-04 16:07:43', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:07:44', 9697, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20928, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20927, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5208', '5215', '2009-03-04 16:59:05', 'pgiuseppe', 'pgiuseppe', '2009-03-04 17:00:22', 9440, '52', '48', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20716, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20715, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4809', '4626', '2009-03-04 16:37:18', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:37:20', 9433, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20513, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9932, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5505', '5482', '2009-03-04 16:05:34', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:06:11', 18654, '79', '116', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20508, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9926, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5395', '5482', '2009-03-04 16:05:29', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:06:07', 18654, '79', '116', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20733, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9938, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4666', '4943', '2009-03-04 16:39:00', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:39:20', 9433, '79', '116', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12592, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 12593, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5454', '5103', '2009-02-11 12:06:58', 'pgiuseppe', 'pgiuseppe', '2009-02-11 12:07:12', 12202, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12586, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 12587, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5406', '5442', '2009-02-11 12:06:51', 'pgiuseppe', 'pgiuseppe', '2009-02-11 12:07:07', 12202, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12576, NULL, NULL, NULL, 12577, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5346', '5081', '2009-02-11 11:52:23', 'pgiuseppe', 'pgiuseppe', '2009-02-11 12:00:06', 12202, '45', '164', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12569, NULL, 12570, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5207', '5362', '2009-02-11 11:52:15', 'pgiuseppe', 'pgiuseppe', '2009-02-11 12:00:00', 12202, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20724, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20723, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4624', '4644', '2009-03-04 16:38:33', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:39:22', 9433, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7706, 7707, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5190', '5051', '2009-02-04 10:34:07', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:20:14', 7702, '55', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7734, 7735, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4948', '5342', '2009-02-04 10:41:47', 'marco.eilers', 'marco.eilers', '2009-02-05 14:57:56', 7702, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7762, 7763, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5155', '5637', '2009-02-04 10:47:29', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:20:53', 7702, '53', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7773, 7774, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5245', '5229', '2009-02-04 10:49:06', 'marco.eilers', 'marco.eilers', '2009-02-05 14:57:57', 7702, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7784, 7785, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5383', '5337', '2009-02-04 10:51:07', 'marco.eilers', 'marco.eilers', '2009-02-05 14:57:58', 7702, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7791, 7792, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5245', '5445', '2009-02-04 10:51:13', 'marco.eilers', 'marco.eilers', '2009-02-05 14:57:58', 7702, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8527, NULL, NULL, 8528, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5327', '5661', '2009-02-04 14:01:52', 'marco.eilers', 'marco.eilers', '2009-02-04 14:03:05', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12512, NULL, NULL, 12419, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5119', '5133', '2009-02-11 11:28:28', 'pgiuseppe', 'pgiuseppe', '2009-02-11 11:28:32', 12496, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7857, NULL, NULL, 7858, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5084', '5192', '2009-02-04 11:01:46', 'marco.eilers', 'marco.eilers', '2009-02-05 12:28:52', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7863, NULL, NULL, 7864, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5085', '5512', '2009-02-04 11:01:51', 'marco.eilers', 'marco.eilers', '2009-02-05 12:28:54', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7869, NULL, NULL, 7870, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5163', '5064', '2009-02-04 11:01:56', 'marco.eilers', 'marco.eilers', '2009-02-04 11:16:18', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7875, NULL, NULL, 7876, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5161', '5353', '2009-02-04 11:02:00', 'marco.eilers', 'marco.eilers', '2009-02-04 11:16:21', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7881, NULL, NULL, 7882, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5161', '5654', '2009-02-04 11:02:04', 'marco.eilers', 'marco.eilers', '2009-02-04 11:16:29', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7887, NULL, NULL, 7888, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5241', '5064', '2009-02-04 11:02:09', 'marco.eilers', 'marco.eilers', '2009-02-04 11:16:34', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7893, NULL, NULL, 7894, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5242', '5352', '2009-02-04 11:02:14', 'marco.eilers', 'marco.eilers', '2009-02-04 11:16:39', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7899, NULL, NULL, 7900, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5242', '5654', '2009-02-04 11:02:20', 'marco.eilers', 'marco.eilers', '2009-02-04 11:16:44', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7931, NULL, NULL, 7932, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5312', '5065', '2009-02-04 11:13:30', 'marco.eilers', 'marco.eilers', '2009-02-04 14:03:03', 7847, '69', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7937, NULL, NULL, 7938, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5561', '5067', '2009-02-04 11:13:37', 'marco.eilers', 'marco.eilers', '2009-02-04 14:08:44', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7943, NULL, NULL, 7944, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5558', '5354', '2009-02-04 11:13:42', 'marco.eilers', 'marco.eilers', '2009-02-04 14:08:47', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7975, NULL, NULL, 7976, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5567', '5682', '2009-02-04 11:19:22', 'marco.eilers', 'marco.eilers', '2009-02-04 14:08:48', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7983, NULL, NULL, 7984, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5643', '5069', '2009-02-04 11:20:23', 'marco.eilers', 'marco.eilers', '2009-02-04 14:08:42', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7989, NULL, NULL, 7990, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5643', '5353', '2009-02-04 11:20:29', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:46:35', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8765, 7707, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4578', '5940', '2009-02-04 14:12:10', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:45', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8770, NULL, NULL, 7864, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4807', '5211', '2009-02-04 14:12:27', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:44', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8883, NULL, 8886, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5483', '5297', '2009-02-04 14:24:09', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:48:38', 8226, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8501, NULL, NULL, 8502, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5405', '5665', '2009-02-04 13:54:08', 'marco.eilers', 'marco.eilers', '2009-02-04 14:47:49', 7847, '67', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8856, NULL, 8861, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5482', '5497', '2009-02-04 14:21:45', 'marco.eilers', 'marco.eilers', '2009-02-05 14:59:27', 8226, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8877, NULL, 8878, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5203', '5508', '2009-02-04 14:24:04', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:48:29', 8226, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8565, NULL, NULL, 7996, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5407', '5066', '2009-02-04 14:04:36', 'marco.eilers', 'marco.eilers', '2009-02-04 14:08:40', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8901, NULL, 8902, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5153', '5283', '2009-02-04 14:25:33', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:48:49', 8226, '81', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8568, NULL, NULL, 8016, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5405', '5353', '2009-02-04 14:04:53', 'marco.eilers', 'marco.eilers', '2009-02-04 14:08:39', 7847, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8519, NULL, NULL, 8520, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5320', '5352', '2009-02-04 14:01:05', 'marco.eilers', 'marco.eilers', '2009-02-04 14:01:37', 7847, '65', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8879, NULL, 8885, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5389', '5513', '2009-02-04 14:24:07', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:48:32', 8226, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8839, NULL, 8840, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5283', '5518', '2009-02-04 14:20:50', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:48:30', 8226, '72', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8849, NULL, 8850, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5122', '5511', '2009-02-04 14:21:41', 'marco.eilers', 'marco.eilers', '2009-02-05 14:59:30', 8226, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8851, NULL, 8855, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5282', '5087', '2009-02-04 14:21:43', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:48:54', 8226, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8780, 7735, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4950', '4821', '2009-02-04 14:12:53', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:45', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8775, NULL, NULL, 7888, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5103', '5260', '2009-02-04 14:12:34', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:47', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8790, NULL, NULL, 7932, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4921', '5031', '2009-02-04 14:13:26', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:47', 7838, '68', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8785, NULL, NULL, 8502, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4438', '4569', '2009-02-04 14:13:01', 'marco.eilers', 'pgiuseppe', '2009-02-27 11:37:28', 7838, '82', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9290, NULL, NULL, 7984, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4162', '5468', '2009-02-04 15:08:26', 'marco.eilers', 'marco.eilers', '2009-02-27 17:14:04', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8833, NULL, 8834, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5172', '5061', '2009-02-04 14:19:57', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:48:52', 8226, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8818, 7792, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4921', '5249', '2009-02-04 14:17:04', 'marco.eilers', 'pgiuseppe', '2009-02-27 11:38:00', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8806, 7774, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4331', '6222', '2009-02-04 14:15:23', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:49', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8797, 7763, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5021', '5007', '2009-02-04 14:13:49', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:50', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8813, 7785, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4681', '4364', '2009-02-04 14:16:33', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:50', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8150, NULL, NULL, NULL, 8151, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5151', '5130', '2009-02-04 11:43:54', 'marco.eilers', 'marco.eilers', '2009-02-05 12:43:32', 8146, '63', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8156, NULL, NULL, NULL, 8157, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5150', '5394', '2009-02-04 11:44:00', 'marco.eilers', 'marco.eilers', '2009-02-05 12:47:55', 8146, '64', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8161, NULL, NULL, NULL, 8163, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5157', '5667', '2009-02-04 11:44:03', 'marco.eilers', 'marco.eilers', '2009-02-05 12:47:56', 8146, '62', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8308, NULL, 8309, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5395', '5307', '2009-02-04 12:12:45', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:48:47', 8226, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8903, NULL, 8909, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5279', '5298', '2009-02-04 14:25:35', 'marco.eilers', 'pgiuseppe', '2009-03-05 14:48:41', 8226, '69', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8984, NULL, 8886, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4582', '4921', '2009-02-04 14:31:03', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:50', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8981, NULL, 8855, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4495', '5023', '2009-02-04 14:30:58', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:51', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8991, NULL, NULL, 7858, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4444', '6211', '2009-02-04 14:32:02', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:51', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8996, NULL, 8309, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4334', '5859', '2009-02-04 14:32:18', 'marco.eilers', 'marco.eilers', '2009-02-27 17:14:16', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9013, NULL, 8850, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4631', '5541', '2009-02-04 14:32:54', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:52', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9017, NULL, NULL, 7870, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4455', '5902', '2009-02-04 14:33:22', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:53', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9023, NULL, 8834, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4573', '5685', '2009-02-04 14:34:36', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:53', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9027, NULL, 8840, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4327', '5611', '2009-02-04 14:34:53', 'marco.eilers', 'marco.eilers', '2009-02-27 17:14:17', 7838, '67', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9040, NULL, NULL, 7876, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4541', '5484', '2009-02-04 14:36:21', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:54', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9048, NULL, 8861, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5366', '5140', '2009-02-04 14:36:58', 'marco.eilers', 'pgiuseppe', '2009-02-27 11:38:03', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9053, NULL, NULL, 7882, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4441', '5482', '2009-02-04 14:37:35', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:55', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9063, NULL, 8878, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5360', '4962', '2009-02-04 14:40:05', 'marco.eilers', 'pgiuseppe', '2009-02-27 11:38:10', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9070, NULL, NULL, 7894, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4454', '5712', '2009-02-04 14:41:30', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:56', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9079, NULL, NULL, 7900, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4512', '5303', '2009-02-04 14:42:59', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:57', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9123, NULL, NULL, 8520, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4948', '5570', '2009-02-04 14:49:34', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:57', 7838, '70', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9127, NULL, NULL, 8528, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4719', '5901', '2009-02-04 14:49:58', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:58', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9131, NULL, NULL, 7938, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4225', '6162', '2009-02-04 14:50:35', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:58', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9157, NULL, NULL, 7944, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4476', '6595', '2009-02-04 14:51:11', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:58', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9160, NULL, 8885, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4519', '6900', '2009-02-04 14:51:21', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:58', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9288, NULL, NULL, 7976, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4819', '5659', '2009-02-04 15:07:22', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:59', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9294, NULL, NULL, 7990, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4343', '5389', '2009-02-04 15:09:09', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:59', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9299, NULL, NULL, 7996, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4312', '5140', '2009-02-04 15:10:47', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:59', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9302, NULL, 8909, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4120', '4930', '2009-02-04 15:11:09', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:59', 7838, '81', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9310, NULL, NULL, 8016, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4650', '5275', '2009-02-04 15:12:13', 'marco.eilers', 'marco.eilers', '2009-02-05 15:46:59', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9367, NULL, NULL, NULL, 8151, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5213', '5577', '2009-02-04 15:16:10', 'marco.eilers', 'marco.eilers', '2009-02-05 15:47:00', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9368, NULL, NULL, NULL, 8157, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5327', '5570', '2009-02-04 15:16:12', 'marco.eilers', 'pgiuseppe', '2009-02-27 11:37:46', 7838, '77', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9473, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9474, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5064', '5506', '2009-02-04 16:26:40', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:11:04', 9440, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9678, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9679, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5160', '5367', '2009-02-05 10:39:17', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:58:23', 9440, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9672, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9673, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5064', '5378', '2009-02-05 10:39:14', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:11:03', 9440, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9666, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9667, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5178', '5481', '2009-02-05 10:39:09', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:58:23', 9440, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9701, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9702, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5367', '5216', '2009-02-05 10:41:30', 'marco.eilers', 'marco.eilers', '2009-02-05 10:52:55', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21061, 21060, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5148', '5129', '2009-03-05 13:29:17', 'pgiuseppe', 'pgiuseppe', '2009-03-05 13:30:26', 21055, '85', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9719, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9720, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5348', '5429', '2009-02-05 10:41:47', 'marco.eilers', 'marco.eilers', '2009-02-05 10:52:57', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9733, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9474, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5314', '5056', '2009-02-05 10:46:48', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:06:45', 9697, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12365, 12366, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5066', '5285', '2009-02-10 18:40:12', 'pgiuseppe', 'pgiuseppe', '2009-02-20 16:45:34', 12202, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9866, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9867, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5369', '5662', '2009-02-05 11:01:18', 'marco.eilers', 'marco.eilers', '2009-02-05 11:01:22', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12418, NULL, NULL, 12419, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5207', '5074', '2009-02-10 19:00:04', 'pgiuseppe', 'pgiuseppe', '2009-02-10 19:02:32', 12202, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9919, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9920, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5570', '5197', '2009-02-05 11:05:57', 'marco.eilers', 'marco.eilers', '2009-02-05 11:05:59', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9925, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9926, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5590', '5427', '2009-02-05 11:08:24', 'marco.eilers', 'marco.eilers', '2009-02-05 11:08:26', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9931, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9932, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5607', '5637', '2009-02-05 11:10:34', 'marco.eilers', 'marco.eilers', '2009-02-05 11:10:36', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9937, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9938, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5788', '5176', '2009-02-05 11:12:42', 'marco.eilers', 'marco.eilers', '2009-02-05 11:12:45', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9943, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9944, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5841', '5427', '2009-02-05 11:14:19', 'marco.eilers', 'marco.eilers', '2009-02-05 11:14:23', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9949, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9950, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5860', '5631', '2009-02-05 11:16:57', 'marco.eilers', 'marco.eilers', '2009-02-05 11:17:22', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9955, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9956, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6073', '5166', '2009-02-05 11:17:29', 'marco.eilers', 'marco.eilers', '2009-02-05 11:17:31', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9957, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9961, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6096', '5438', '2009-02-05 11:17:30', 'marco.eilers', 'marco.eilers', '2009-02-05 11:17:33', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9985, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9991, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6338', '5468', '2009-02-05 11:26:34', 'marco.eilers', 'marco.eilers', '2009-02-05 11:26:38', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9983, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9984, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6335', '5215', '2009-02-05 11:26:31', 'marco.eilers', 'marco.eilers', '2009-02-05 11:26:35', 9697, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10263, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9961, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4850', '4902', '2009-02-05 12:20:51', 'marco.eilers', 'pgiuseppe', '2009-02-27 16:39:11', 9433, '95', '170', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10192, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9679, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4909', '5252', '2009-02-05 12:15:10', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:14:08', 9433, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10182, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9474, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5095', '5220', '2009-02-05 12:15:04', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:12:55', 9433, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10187, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9673, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4817', '5201', '2009-02-05 12:15:07', 'marco.eilers', 'marco.eilers', '2009-02-05 12:18:00', 9433, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10177, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9667, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4693', '5187', '2009-02-05 12:15:00', 'marco.eilers', 'marco.eilers', '2009-02-05 12:23:51', 9433, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10268, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9956, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5054', '4903', '2009-02-05 12:21:07', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:12:46', 9433, '95', '204', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10657, NULL, NULL, NULL, 8163, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5513', '5473', '2009-02-05 13:54:24', 'marco.eilers', 'marco.eilers', '2009-02-27 17:12:53', 7838, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13285, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 13286, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5153', '5210', '2009-02-11 16:08:00', 'pgiuseppe', 'pgiuseppe', '2009-02-11 16:08:25', 12214, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21107, 21060, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5054', '5298', '2009-03-05 14:19:53', 'pgiuseppe', 'pgiuseppe', '2009-03-05 14:20:45', 7702, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21072, 21071, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5235', '5462', '2009-03-05 13:29:51', 'pgiuseppe', 'pgiuseppe', '2009-03-05 14:16:43', 21055, '99', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21270, NULL, NULL, 8502, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5211', '5444', '2009-03-05 14:53:33', 'pgiuseppe', 'pgiuseppe', '2009-03-05 14:53:37', 21243, '69', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21253, NULL, 8834, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5370', '5450', '2009-03-05 14:51:53', 'pgiuseppe', 'pgiuseppe', '2009-03-05 14:54:03', 21243, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21264, NULL, NULL, 7858, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5209', '5240', '2009-03-05 14:53:08', 'pgiuseppe', 'pgiuseppe', '2009-03-05 14:53:10', 21243, '50', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20503, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9920, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5191', '5445', '2009-03-04 16:05:26', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:10:26', 18654, '79', '116', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20498, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9720, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5046', '5451', '2009-03-04 16:05:15', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:10:23', 18654, '79', '116', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16071, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 13286, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5434', '5670', '2009-02-20 16:45:06', 'pgiuseppe', 'pgiuseppe', '2009-02-20 16:45:08', 12202, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18662, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5088', '5106', '2009-02-27 14:16:23', 'marco.eilers', 'marco.eilers', '2009-02-27 14:16:26', NULL, '40', '40', NULL, 18663, NULL, NULL, NULL, NULL, 18658),
(18680, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5139', '5470', '2009-02-27 14:23:17', 'marco.eilers', 'marco.eilers', '2009-02-27 14:23:21', NULL, '60', '95', NULL, NULL, 18681, NULL, NULL, NULL, 18658),
(18689, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5290', '5470', '2009-02-27 14:25:27', 'marco.eilers', 'marco.eilers', '2009-02-27 14:25:33', NULL, '60', '95', NULL, NULL, 18690, NULL, NULL, NULL, 18658),
(18699, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5224', '5172', '2009-02-27 14:27:53', 'marco.eilers', 'marco.eilers', '2009-02-27 14:28:13', NULL, '45', '75', NULL, NULL, NULL, NULL, 18700, NULL, 18658),
(18706, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5336', '5204', '2009-02-27 14:28:21', 'marco.eilers', 'marco.eilers', '2009-02-27 14:28:29', NULL, '45', '80', NULL, NULL, NULL, 18707, NULL, NULL, 18658),
(18713, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5108', '5688', '2009-02-27 14:28:39', 'marco.eilers', 'marco.eilers', '2009-02-27 14:28:44', NULL, '60', '95', NULL, NULL, 18714, NULL, NULL, NULL, 18658),
(18721, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5235', '5639', '2009-02-27 14:28:53', 'marco.eilers', 'marco.eilers', '2009-02-27 14:29:00', NULL, '40', '40', 18722, NULL, NULL, NULL, NULL, NULL, 18658),
(18730, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5063', '5295', '2009-02-27 14:31:58', 'marco.eilers', 'marco.eilers', '2009-02-27 14:32:06', NULL, '60', '95', NULL, NULL, 18731, NULL, NULL, NULL, 18658),
(18737, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2009-02-27 14:32:15', 'marco.eilers', 'marco.eilers', '2009-02-27 14:32:22', NULL, NULL, NULL, 18738, NULL, NULL, NULL, NULL, NULL, 18658),
(18789, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5022', '5062', '2009-02-27 16:40:26', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:47:22', NULL, '40', '40', NULL, 18790, NULL, NULL, NULL, NULL, 18779),
(20964, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9938, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5247', '5226', '2009-03-04 17:02:06', 'pgiuseppe', 'pgiuseppe', '2009-03-04 17:03:34', 20936, '79', '162', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20492, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9984, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5191', '5246', '2009-03-04 16:05:01', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:10:24', 18654, '78', '117', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18899, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9702, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5046', '5239', '2009-02-27 16:49:30', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:10:21', 18654, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18903, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9991, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5513', '5246', '2009-02-27 16:49:43', 'marco.eilers', 'marco.eilers', '2009-02-27 17:10:54', 18654, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19128, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9867, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5387', '5246', '2009-02-27 17:25:57', 'marco.eilers', 'pgiuseppe', '2009-03-04 16:05:57', 18654, '95', '96', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19150, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9667, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5108', '5151', '2009-02-27 17:37:03', 'pgiuseppe', 'pgiuseppe', '2009-02-27 17:37:05', 9697, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19156, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9673, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5212', '5579', '2009-02-27 17:37:17', 'pgiuseppe', 'pgiuseppe', '2009-02-27 17:37:29', 9697, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21511, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5428', '5232', '2009-03-06 17:56:57', 'admin', 'admin', '2009-03-06 17:56:58', NULL, '40', '40', 21510, NULL, NULL, NULL, NULL, NULL, 21489),
(21505, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5267', '5193', '2009-03-06 17:56:54', 'admin', 'admin', '2009-03-06 17:56:55', NULL, '60', '95', NULL, NULL, 21504, NULL, NULL, NULL, 21489),
(21499, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5113', '5192', '2009-03-06 17:56:49', 'admin', 'admin', '2009-03-06 17:56:50', NULL, '40', '40', NULL, 21498, NULL, NULL, NULL, NULL, 21489),
(20739, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9932, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4549', '4935', '2009-03-04 16:39:11', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:39:19', 9433, '79', '116', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20958, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20927, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5071', '5340', '2009-03-04 17:01:45', 'pgiuseppe', 'pgiuseppe', '2009-03-04 17:03:27', 20936, '52', '48', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20794, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5039', '5510', '2009-03-04 16:45:19', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:49:01', NULL, '74', '95', NULL, NULL, 20793, NULL, NULL, NULL, 18779),
(20823, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5198', '5483', '2009-03-04 16:46:25', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:49:04', NULL, '99', '95', NULL, NULL, 20822, NULL, NULL, NULL, 18779),
(20838, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5418', '5444', '2009-03-04 16:46:53', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:47:36', NULL, '40', '40', 20837, NULL, NULL, NULL, NULL, NULL, 18779),
(20864, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5024', '5273', '2009-03-04 16:47:48', 'pgiuseppe', 'pgiuseppe', '2009-03-04 16:49:01', NULL, '106', '113', NULL, NULL, 20863, NULL, NULL, NULL, 18779),
(20969, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 9474, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5249', '5498', '2009-03-04 17:02:17', 'pgiuseppe', 'pgiuseppe', '2009-03-04 17:02:21', 20936, '50', '52', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `History`
--

CREATE TABLE IF NOT EXISTS `History` (
  `id` int(11) NOT NULL,
  `data` text,
  `duplicate` tinyint(1) default NULL,
  `eventtype` enum('create','delete','changeProperty','associate','disassociate') default NULL,
  `affectedoid` varchar(255) default NULL,
  `otheroid` varchar(255) default NULL,
  `timestamp` bigint(20) default NULL,
  `user` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `History`
--

INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES
(15536, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:15535', NULL, 1235130530, 'niko'),
(15539, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5289";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5117";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:15534', NULL, 1235130531, 'niko'),
(15540, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:15537', NULL, 1235130532, 'niko'),
(15545, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:20:"New ActivityDecision";}}}', 0, '', 'ActivityDecision:15544', NULL, 1235130536, 'niko'),
(15547, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5289";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5259";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:15543', NULL, 1235130537, 'niko'),
(15549, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:20:"New ActivityDecision";}}}', 0, '', 'ActivityDecision:15546', NULL, 1235130538, 'niko'),
(15555, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, '', 'ActivityFinal:15554', NULL, 1235130545, 'niko'),
(15557, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5310";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5484";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:15553', NULL, 1235130545, 'niko'),
(15559, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, '', 'ActivityFinal:15556', NULL, 1235130546, 'niko'),
(15564, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, '', 'ActivityInitial:15563', NULL, 1235130555, 'niko'),
(15569, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, '', 'ActivityInitial:15565', NULL, 1235130557, 'niko'),
(15570, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5299";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5037";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:15562', NULL, 1235130557, 'niko'),
(15573, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:19:"New ActivityReceive";}}}', 0, '', 'ActivityReceive:15572', NULL, 1235130565, 'niko'),
(15576, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5076";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5256";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"75";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"45";}}}', 0, '', 'Figure:15571', NULL, 1235130566, 'niko'),
(15580, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:16:"New ActivitySend";}}}', 0, '', 'ActivitySend:15579', NULL, 1235130573, 'niko'),
(15582, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5544";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5263";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"80";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"45";}}}', 0, '', 'Figure:15578', NULL, 1235130575, 'niko'),
(15587, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:16:"New ActivitySend";}}}', 0, '', 'ActivitySend:15581', NULL, 1235130577, 'niko'),
(15643, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New ChiValue";}}}', 0, '', 'ChiValue:15642', NULL, 1235130726, 'niko'),
(15648, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Package";}}}', 0, '', 'Package:15647', NULL, 1235130841, 'niko'),
(15651, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"AAA";}}}', 0, '', 'Package:15647', NULL, 1235130852, 'niko'),
(15653, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:15652', NULL, 1235130858, 'niko'),
(15658, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New ChiNode";}}}', 0, '', 'ChiNode:15657', NULL, 1235130868, 'niko'),
(15660, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5330";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5171";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"65";}}}', 0, '', 'Figure:15656', NULL, 1235130869, 'niko'),
(15664, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New ChiValue";}}}', 0, '', 'ChiValue:15663', NULL, 1235130873, 'niko'),
(15666, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"81";}}}', 0, '', 'Figure:15656', NULL, 1235130874, 'niko'),
(15668, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:10:"numBallons";}}}', 0, '', 'ChiValue:15663', NULL, 1235130885, 'niko'),
(15670, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:13:"New Operation";}}}', 0, '', 'Operation:15669', NULL, 1235130891, 'niko'),
(15672, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"97";}}}', 0, '', 'Figure:15656', NULL, 1235130892, 'niko'),
(15674, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"killBallons";}}}', 0, '', 'Operation:15669', NULL, 1235130900, 'niko'),
(15811, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5894";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"6195";}}}', 0, '', 'Figure:15072', NULL, 1235134319, 'andreas.herdt'),
(15839, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5173";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5144";}}}', 0, '', 'Figure:15656', NULL, 1235135116, 'pgiuseppe'),
(15842, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New ChiNode";}}}', 0, '', 'ChiNode:15841', NULL, 1235135124, 'pgiuseppe'),
(15845, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5411";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5142";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"65";}}}', 0, '', 'Figure:15840', NULL, 1235135125, 'pgiuseppe'),
(15846, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5409";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5232";}}}', 0, '', 'Figure:15840', NULL, 1235135129, 'pgiuseppe'),
(15847, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5295";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5346";}}}', 0, '', 'Figure:15840', NULL, 1235135136, 'pgiuseppe'),
(15850, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New ChiView";}}}', 0, '', 'ChiView:15849', NULL, 1235135161, 'pgiuseppe'),
(15854, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5147";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5426";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:15848', NULL, 1235135162, 'pgiuseppe'),
(15856, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5041";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5331";}}}', 0, '', 'Figure:15848', NULL, 1235135164, 'pgiuseppe'),
(15859, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"New ChiController";}}}', 0, '', 'ChiController:15858', NULL, 1235135169, 'pgiuseppe'),
(15861, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5467";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5142";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:15857', NULL, 1235135170, 'pgiuseppe'),
(15864, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5173";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5143";}}}', 0, '', 'Figure:15656', NULL, 1235135243, 'pgiuseppe'),
(15865, 'a:1:{i:0;a:1:{s:5:"Alias";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"test";}}}', 0, '', 'ChiController:15858', NULL, 1235135248, 'pgiuseppe'),
(15866, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"test";}}}', 0, '', 'ChiController:15858', NULL, 1235135252, 'pgiuseppe'),
(15868, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5041";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5333";}}}', 0, '', 'Figure:15848', NULL, 1235135462, 'pgiuseppe'),
(15870, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5161";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5344";}}}', 0, '', 'Figure:15848', NULL, 1235135463, 'pgiuseppe'),
(15873, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:8:"customer";}}}', 0, '', 'ChiNode:15657', NULL, 1235135483, 'pgiuseppe'),
(15878, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:10:"enterprise";}}}', 0, '', 'ChiNode:15841', NULL, 1235135498, 'pgiuseppe'),
(15885, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5173";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5129";}}}', 0, '', 'Figure:15656', NULL, 1235135526, 'pgiuseppe'),
(15886, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5174";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5129";}}}', 0, '', 'Figure:15656', NULL, 1235135558, 'pgiuseppe'),
(15887, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5296";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5345";}}}', 0, '', 'Figure:15840', NULL, 1235135592, 'pgiuseppe'),
(15889, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New ChiValue";}}}', 0, '', 'ChiValue:15888', NULL, 1235135599, 'pgiuseppe'),
(15892, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"81";}}}', 0, '', 'Figure:15840', NULL, 1235135601, 'pgiuseppe'),
(15893, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"97";}}}', 0, '', 'Figure:15840', NULL, 1235135602, 'pgiuseppe'),
(15895, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New ChiValue";}}}', 0, '', 'ChiValue:15894', NULL, 1235135617, 'pgiuseppe'),
(15898, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"113";}}}', 0, '', 'Figure:15656', NULL, 1235135618, 'pgiuseppe'),
(15899, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"129";}}}', 0, '', 'Figure:15656', NULL, 1235135619, 'pgiuseppe'),
(15900, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5297";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5345";}}}', 0, '', 'Figure:15840', NULL, 1235135657, 'pgiuseppe'),
(15902, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:13:"New Operation";}}}', 0, '', 'Operation:15901', NULL, 1235135666, 'pgiuseppe'),
(15905, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"145";}}}', 0, '', 'Figure:15656', NULL, 1235135668, 'pgiuseppe'),
(15906, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"161";}}}', 0, '', 'Figure:15656', NULL, 1235135668, 'pgiuseppe'),
(15909, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"220";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"161";}}}', 0, '', 'Figure:15656', NULL, 1235135706, 'pgiuseppe'),
(15933, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:15932', NULL, 1235136438, 'pgiuseppe'),
(15954, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"Analysis overview";}}}', 0, '', 'Diagram:15932', NULL, 1235136454, 'pgiuseppe'),
(16012, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Package";}}}', 0, '', 'Package:16011', NULL, 1235143060, 'pgiuseppe'),
(16015, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:6:"issues";}}}', 0, '', 'Package:16011', NULL, 1235143069, 'pgiuseppe'),
(16017, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Package";}}}', 0, '', 'Package:16016', NULL, 1235143079, 'pgiuseppe'),
(16020, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:9:"Release 1";}}}', 0, '', 'Package:16016', NULL, 1235143091, 'pgiuseppe'),
(16022, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Package";}}}', 0, '', 'Package:16021', NULL, 1235143094, 'pgiuseppe'),
(16025, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:9:"Release 1";}}}', 0, '', 'Package:16021', NULL, 1235143100, 'pgiuseppe'),
(16047, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessPartner";}}}', 0, '', 'ChiBusinessPartner:16046', NULL, 1235144618, 'pgiuseppe'),
(16050, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5713";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5365";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"26";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"52";}}}', 0, '', 'Figure:16045', NULL, 1235144620, 'pgiuseppe'),
(16060, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5628";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5542";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"52";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16057', NULL, 1235144669, 'pgiuseppe'),
(16072, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5670";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5434";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"52";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16071', NULL, 1235144708, 'pgiuseppe'),
(16085, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5285";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5066";}}}', 0, '', 'Figure:12365', NULL, 1235144734, 'pgiuseppe'),
(16103, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:21:"my 1st ChiRequirement";}}}', 0, '', 'ChiRequirement:14585', NULL, 1235145280, 'pgiuseppe'),
(16106, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:21:"my 2nd ChiRequirement";}}}', 0, '', 'ChiRequirement:12419', NULL, 1235145288, 'pgiuseppe'),
(16109, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:21:"my 3rd ChiRequirement";}}}', 0, '', 'ChiRequirement:14598', NULL, 1235145294, 'pgiuseppe'),
(16111, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:255:"Modify this for create your own <b>Requirements</b>.  \n	<br><br>A Business guide line about the \nEnterprise or the project. \n<p>A ChiRequirement represents a condition \nthat needs to be <span>Satisfied</span> by certain \nachievement (a ChiFeature ).</p> \n";}}}', 0, '', 'ChiRequirement:14598', NULL, 1235147219, 'pgiuseppe'),
(16152, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:16150', NULL, 1235162674, 'pgiuseppe'),
(16156, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5158";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5101";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16154', NULL, 1235162682, 'pgiuseppe'),
(16163, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5163";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5178";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16160', NULL, 1235162687, 'pgiuseppe'),
(16168, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5165";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5259";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16166', NULL, 1235162692, 'pgiuseppe'),
(16174, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5357";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5100";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16172', NULL, 1235162697, 'pgiuseppe'),
(16180, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5414";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5185";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16177', NULL, 1235162707, 'pgiuseppe'),
(16182, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5365";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5173";}}}', 0, '', 'Figure:16177', NULL, 1235162709, 'pgiuseppe'),
(16185, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:14:"Ziele Overview";}}}', 0, '', 'Diagram:16150', NULL, 1235162720, 'pgiuseppe'),
(16187, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:16186', NULL, 1235162761, 'pgiuseppe'),
(16194, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:10:"Nebenziele";}}}', 0, '', 'Diagram:16186', NULL, 1235162771, 'pgiuseppe'),
(16197, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5115";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5102";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16195', NULL, 1235162778, 'pgiuseppe'),
(16202, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5110";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5169";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16201', NULL, 1235162782, 'pgiuseppe'),
(16209, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5117";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5244";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16207', NULL, 1235162790, 'pgiuseppe'),
(16216, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5321";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5104";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16213', NULL, 1235162796, 'pgiuseppe'),
(16222, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5348";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5175";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16219', NULL, 1235162801, 'pgiuseppe'),
(16224, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5327";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5171";}}}', 0, '', 'Figure:16219', NULL, 1235162803, 'pgiuseppe'),
(16226, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:16225', NULL, 1235162878, 'pgiuseppe'),
(16233, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:24:"Technische Infrastruktur";}}}', 0, '', 'Diagram:16225', NULL, 1235162898, 'pgiuseppe'),
(16237, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5035";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5036";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16234', NULL, 1235162909, 'pgiuseppe'),
(16242, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5047";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5111";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16240', NULL, 1235162915, 'pgiuseppe'),
(16247, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5049";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5174";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16245', NULL, 1235162920, 'pgiuseppe'),
(16253, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5035";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5111";}}}', 0, '', 'Figure:16240', NULL, 1235162928, 'pgiuseppe'),
(16255, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5035";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5174";}}}', 0, '', 'Figure:16245', NULL, 1235162929, 'pgiuseppe'),
(16259, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5051";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5271";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16257', NULL, 1235162938, 'pgiuseppe'),
(16262, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5035";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5256";}}}', 0, '', 'Figure:16257', NULL, 1235162940, 'pgiuseppe'),
(16267, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5033";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5346";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16263', NULL, 1235162949, 'pgiuseppe'),
(16269, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5035";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5340";}}}', 0, '', 'Figure:16263', NULL, 1235162951, 'pgiuseppe'),
(16272, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5248";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5033";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16270', NULL, 1235162959, 'pgiuseppe'),
(16275, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5227";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5036";}}}', 0, '', 'Figure:16270', NULL, 1235162960, 'pgiuseppe'),
(16277, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5242";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5125";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16276', NULL, 1235162966, 'pgiuseppe'),
(16280, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5227";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5111";}}}', 0, '', 'Figure:16276', NULL, 1235162967, 'pgiuseppe'),
(16285, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5222";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5181";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16282', NULL, 1235162977, 'pgiuseppe'),
(16287, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5211";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5223";}}}', 0, '', 'Figure:16282', NULL, 1235162979, 'pgiuseppe'),
(16289, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5227";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5174";}}}', 0, '', 'Figure:16282', NULL, 1235162981, 'pgiuseppe'),
(16292, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5234";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5264";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16290', NULL, 1235162991, 'pgiuseppe'),
(16296, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5227";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5251";}}}', 0, '', 'Figure:16290', NULL, 1235162994, 'pgiuseppe'),
(16300, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5232";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5343";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16297', NULL, 1235162998, 'pgiuseppe'),
(16302, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5227";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5340";}}}', 0, '', 'Figure:16297', NULL, 1235163001, 'pgiuseppe'),
(16307, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5426";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5029";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16303', NULL, 1235163009, 'pgiuseppe'),
(16309, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5425";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5036";}}}', 0, '', 'Figure:16303', NULL, 1235163013, 'pgiuseppe'),
(16314, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5435";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5114";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16310', NULL, 1235163018, 'pgiuseppe'),
(16316, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5425";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5111";}}}', 0, '', 'Figure:16310', NULL, 1235163022, 'pgiuseppe'),
(16318, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5433";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5194";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16317', NULL, 1235163030, 'pgiuseppe'),
(16322, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5425";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5174";}}}', 0, '', 'Figure:16317', NULL, 1235163035, 'pgiuseppe'),
(16325, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5416";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5239";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16323', NULL, 1235163040, 'pgiuseppe'),
(16329, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5425";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5251";}}}', 0, '', 'Figure:16323', NULL, 1235163044, 'pgiuseppe'),
(16332, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5427";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5356";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16330', NULL, 1235163050, 'pgiuseppe'),
(16336, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5425";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5340";}}}', 0, '', 'Figure:16330', NULL, 1235163053, 'pgiuseppe'),
(16340, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5602";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5029";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16337', NULL, 1235163061, 'pgiuseppe'),
(16343, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5602";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5036";}}}', 0, '', 'Figure:16337', NULL, 1235163063, 'pgiuseppe'),
(16347, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5620";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5111";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16344', NULL, 1235163069, 'pgiuseppe'),
(16349, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5602";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5111";}}}', 0, '', 'Figure:16344', NULL, 1235163071, 'pgiuseppe'),
(16353, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5630";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5185";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16350', NULL, 1235163078, 'pgiuseppe'),
(16356, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5602";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5251";}}}', 0, '', 'Figure:16350', NULL, 1235163084, 'pgiuseppe'),
(16359, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"64";}}}', 0, '', 'Figure:16344', NULL, 1235163090, 'pgiuseppe'),
(16363, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5623";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5342";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16360', NULL, 1235163100, 'pgiuseppe'),
(16366, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5602";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5340";}}}', 0, '', 'Figure:16360', NULL, 1235163104, 'pgiuseppe'),
(16370, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5053";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5421";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16367', NULL, 1235163119, 'pgiuseppe'),
(16372, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5035";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5423";}}}', 0, '', 'Figure:16367', NULL, 1235163121, 'pgiuseppe'),
(16373, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"63";}}}', 0, '', 'Figure:16367', NULL, 1235163122, 'pgiuseppe'),
(16377, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5262";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5421";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16374', NULL, 1235163127, 'pgiuseppe'),
(16379, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5227";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5423";}}}', 0, '', 'Figure:16374', NULL, 1235163134, 'pgiuseppe'),
(16383, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5440";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5430";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16380', NULL, 1235163139, 'pgiuseppe'),
(16385, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5425";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5423";}}}', 0, '', 'Figure:16380', NULL, 1235163144, 'pgiuseppe'),
(16389, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5626";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5421";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16386', NULL, 1235163149, 'pgiuseppe'),
(16392, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5602";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5423";}}}', 0, '', 'Figure:16386', NULL, 1235163154, 'pgiuseppe'),
(16395, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:16393', NULL, 1235163279, 'pgiuseppe'),
(16401, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:21:"Requirements overview";}}}', 0, '', 'Diagram:16393', NULL, 1235163301, 'pgiuseppe'),
(16404, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5051";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5060";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16402', NULL, 1235163307, 'pgiuseppe'),
(16410, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5255";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5068";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16408', NULL, 1235163314, 'pgiuseppe'),
(16413, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5238";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5061";}}}', 0, '', 'Figure:16408', NULL, 1235163317, 'pgiuseppe'),
(16416, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5447";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5055";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16414', NULL, 1235163322, 'pgiuseppe'),
(16419, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5431";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5059";}}}', 0, '', 'Figure:16414', NULL, 1235163324, 'pgiuseppe'),
(16448, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5175";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"6040";}}}', 0, '', 'Figure:15092', NULL, 1235163427, 'pgiuseppe'),
(16449, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5067";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5896";}}}', 0, '', 'Figure:15092', NULL, 1235163433, 'pgiuseppe'),
(16452, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5546";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5898";}}}', 0, '', 'Figure:15003', NULL, 1235163435, 'pgiuseppe'),
(16455, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5276";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4978";}}}', 0, '', 'Figure:14938', NULL, 1235163472, 'pgiuseppe'),
(16458, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5141";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4869";}}}', 0, '', 'Figure:14944', NULL, 1235163480, 'pgiuseppe'),
(16461, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5374";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4866";}}}', 0, '', 'Figure:14950', NULL, 1235163492, 'pgiuseppe'),
(16462, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5454";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5087";}}}', 0, '', 'Figure:14950', NULL, 1235163499, 'pgiuseppe'),
(16485, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5403";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5546";}}}', 0, '', 'Figure:14887', NULL, 1235164168, 'pgiuseppe'),
(16489, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5148";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5241";}}}', 0, '', 'Figure:14744', NULL, 1235164242, 'pgiuseppe'),
(16492, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5576";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5158";}}}', 0, '', 'Figure:14840', NULL, 1235164266, 'pgiuseppe'),
(16494, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5366";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5206";}}}', 0, '', 'Figure:14751', NULL, 1235164269, 'pgiuseppe'),
(16511, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5227";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5317";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16509', NULL, 1235164534, 'pgiuseppe'),
(16515, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5605";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5132";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"52";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16513', NULL, 1235164545, 'pgiuseppe'),
(16528, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5436";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5327";}}}', 0, '', 'Figure:5151', NULL, 1235164609, 'pgiuseppe'),
(16544, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"70";}}}', 0, '', 'Figure:6010', NULL, 1235164689, 'pgiuseppe'),
(16546, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5376";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5171";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16545', NULL, 1235164706, 'pgiuseppe'),
(16548, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"70";}}}', 0, '', 'Figure:16545', NULL, 1235164714, 'pgiuseppe'),
(16549, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5422";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5175";}}}', 0, '', 'Figure:16545', NULL, 1235164716, 'pgiuseppe'),
(16555, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5209";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5138";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16552', NULL, 1235164780, 'pgiuseppe'),
(16558, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5116";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5174";}}}', 0, '', 'Figure:16552', NULL, 1235164790, 'pgiuseppe'),
(16561, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5114";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5038";}}}', 0, '', 'Figure:5140', NULL, 1235164794, 'pgiuseppe'),
(16568, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5136";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5328";}}}', 0, '', 'Figure:16552', NULL, 1235164831, 'pgiuseppe'),
(16571, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5117";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5170";}}}', 0, '', 'Figure:5140', NULL, 1235164837, 'pgiuseppe'),
(16583, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5455";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5445";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:16581', NULL, 1235164992, 'pgiuseppe'),
(16587, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5202";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5509";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16585', NULL, 1235164999, 'pgiuseppe'),
(16592, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5723";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5505";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"52";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16589', NULL, 1235165013, 'pgiuseppe'),
(16622, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"New ActivitySet";}}}', 0, '', 'ActivitySet:16620', NULL, 1235214494, 'pgiuseppe'),
(16626, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, '', 'ActivityInitial:16625', NULL, 1235214508, 'pgiuseppe'),
(16628, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5269";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5112";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:16624', NULL, 1235214508, 'pgiuseppe'),
(16632, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5295";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5073";}}}', 0, '', 'Figure:16624', NULL, 1235214514, 'pgiuseppe'),
(16635, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"new activity";}}}', 0, '', 'ActivitySet:16620', NULL, 1235214531, 'pgiuseppe'),
(16638, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:16637', NULL, 1235214541, 'pgiuseppe'),
(16642, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5227";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5183";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:16636', NULL, 1235214542, 'pgiuseppe'),
(16644, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5287";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5214";}}}', 0, '', 'Figure:16636', NULL, 1235214543, 'pgiuseppe'),
(16645, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5270";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5205";}}}', 0, '', 'Figure:16636', NULL, 1235214544, 'pgiuseppe'),
(16646, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5256";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5226";}}}', 0, '', 'Figure:16636', NULL, 1235214551, 'pgiuseppe'),
(16649, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:16648', NULL, 1235214560, 'pgiuseppe'),
(16652, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:16650', NULL, 1235214561, 'pgiuseppe'),
(16653, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5318";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5411";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:16647', NULL, 1235214561, 'pgiuseppe'),
(16657, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5266";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5400";}}}', 0, '', 'Figure:16647', NULL, 1235214562, 'pgiuseppe'),
(16662, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5223";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5546";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:16658', NULL, 1235214578, 'pgiuseppe'),
(16664, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5281";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5519";}}}', 0, '', 'Figure:16658', NULL, 1235214583, 'pgiuseppe'),
(16669, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5270";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5532";}}}', 0, '', 'Figure:16658', NULL, 1235214586, 'pgiuseppe');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES
(16672, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:20:"New ActivityDecision";}}}', 0, '', 'ActivityDecision:16671', NULL, 1235214598, 'pgiuseppe'),
(16675, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:20:"New ActivityDecision";}}}', 0, '', 'ActivityDecision:16673', NULL, 1235214599, 'pgiuseppe'),
(16677, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5445";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5505";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:16670', NULL, 1235214599, 'pgiuseppe'),
(16681, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5450";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5111";}}}', 0, '', 'Figure:16636', NULL, 1235214603, 'pgiuseppe'),
(16684, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5259";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5219";}}}', 0, '', 'Figure:16647', NULL, 1235214606, 'pgiuseppe'),
(16687, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5254";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5363";}}}', 0, '', 'Figure:16658', NULL, 1235214608, 'pgiuseppe'),
(16707, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New ChiNode";}}}', 0, '', 'ChiNode:16706', NULL, 1235390427, 'admin'),
(16709, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5111";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5688";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"65";}}}', 0, '', 'Figure:16705', NULL, 1235390428, 'admin'),
(16714, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New ChiNode";}}}', 0, '', 'ChiNode:16713', NULL, 1235390435, 'admin'),
(16717, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5368";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5735";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"65";}}}', 0, '', 'Figure:16712', NULL, 1235390438, 'admin'),
(16721, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"New ChiController";}}}', 0, '', 'ChiController:16720', NULL, 1235390460, 'admin'),
(16725, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5201";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5628";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:16719', NULL, 1235390462, 'admin'),
(16729, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5020";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5606";}}}', 0, '', 'Figure:16705', NULL, 1235390465, 'admin'),
(16755, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"New ChiController";}}}', 0, '', 'ChiController:16754', NULL, 1235390678, 'admin'),
(16757, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5055";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5738";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:16753', NULL, 1235390679, 'admin'),
(16817, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5242";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5629";}}}', 0, '', 'Figure:16719', NULL, 1235581760, 'pgiuseppe'),
(16820, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5420";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5765";}}}', 0, '', 'Figure:16712', NULL, 1235581761, 'pgiuseppe'),
(16822, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5241";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5629";}}}', 0, '', 'Figure:16719', NULL, 1235581771, 'pgiuseppe'),
(16825, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5420";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5766";}}}', 0, '', 'Figure:16712', NULL, 1235581776, 'pgiuseppe'),
(16828, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New ChiValue";}}}', 0, '', 'ChiValue:16827', NULL, 1235581780, 'pgiuseppe'),
(16830, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"81";}}}', 0, '', 'Figure:16712', NULL, 1235581781, 'pgiuseppe'),
(16833, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5415";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5748";}}}', 0, '', 'Figure:16712', NULL, 1235581787, 'pgiuseppe'),
(16836, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Package";}}}', 0, '', 'Package:16835', NULL, 1235581807, 'pgiuseppe'),
(16839, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:31:"How to become addicted: process";}}}', 0, '', 'Package:16835', NULL, 1235581826, 'pgiuseppe'),
(16841, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:16840', NULL, 1235581837, 'pgiuseppe'),
(16845, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:31:"How to become addicted: process";}}}', 0, '', 'Diagram:16840', NULL, 1235581845, 'pgiuseppe'),
(16848, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessPartner";}}}', 0, '', 'ChiBusinessPartner:16847', NULL, 1235581858, 'pgiuseppe'),
(16851, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5243";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5223";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"26";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"52";}}}', 0, '', 'Figure:16846', NULL, 1235581859, 'pgiuseppe'),
(16853, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5235";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5196";}}}', 0, '', 'Figure:16846', NULL, 1235581859, 'pgiuseppe'),
(16854, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"me";}}}', 0, '', 'ChiBusinessPartner:16847', NULL, 1235581866, 'pgiuseppe'),
(16857, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, '', 'ChiBusinessUseCase:16856', NULL, 1235581869, 'pgiuseppe'),
(16859, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5369";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5211";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:16855', NULL, 1235581870, 'pgiuseppe'),
(16862, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5347";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5183";}}}', 0, '', 'Figure:16855', NULL, 1235581871, 'pgiuseppe'),
(16865, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5202";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5196";}}}', 0, '', 'Figure:16846', NULL, 1235581872, 'pgiuseppe'),
(16868, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"become addicted";}}}', 0, '', 'ChiBusinessUseCase:16856', NULL, 1235581886, 'pgiuseppe'),
(16871, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:26:"New ChiBusinessUseCaseCore";}}}', 0, '', 'ChiBusinessUseCaseCore:16870', NULL, 1235581888, 'pgiuseppe'),
(16872, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5371";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5362";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:16869', NULL, 1235581889, 'pgiuseppe'),
(16876, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:23:"become adicted to drugs";}}}', 0, '', 'ChiBusinessUseCaseCore:16870', NULL, 1235581908, 'pgiuseppe'),
(16877, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5228";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5341";}}}', 0, '', 'Figure:16869', NULL, 1235581910, 'pgiuseppe'),
(16879, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Package";}}}', 0, '', 'Package:16878', NULL, 1235581975, 'pgiuseppe'),
(16882, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"Become rich";}}}', 0, '', 'Package:16878', NULL, 1235581984, 'pgiuseppe'),
(16885, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:16883', NULL, 1235581987, 'pgiuseppe'),
(16892, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"Become rich";}}}', 0, '', 'Diagram:16883', NULL, 1235581997, 'pgiuseppe'),
(16895, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, '', 'ChiBusinessUseCase:16894', NULL, 1235582002, 'pgiuseppe'),
(16900, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5170";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5166";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:16893', NULL, 1235582004, 'pgiuseppe'),
(16901, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:26:"write the perfect software";}}}', 0, '', 'ChiBusinessUseCase:16894', NULL, 1235582026, 'pgiuseppe'),
(16906, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"New ActivitySet";}}}', 0, '', 'ActivitySet:16904', NULL, 1235582030, 'pgiuseppe'),
(16930, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:16929', NULL, 1235582122, 'marco.eilers'),
(16933, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5676";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5098";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16928', NULL, 1235582122, 'marco.eilers'),
(16939, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New ChiGoal";}}}', 0, '', 'ChiGoal:16937', NULL, 1235582125, 'marco.eilers'),
(16941, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5579";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5262";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16936', NULL, 1235582126, 'marco.eilers'),
(16947, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:14:"New ChiFeature";}}}', 0, '', 'ChiFeature:16946', NULL, 1235582129, 'marco.eilers'),
(16951, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5689";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5469";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16945', NULL, 1235582131, 'marco.eilers'),
(16954, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:16949', NULL, 1235582132, 'pgiuseppe'),
(16955, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5328";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5191";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:16948', NULL, 1235582132, 'pgiuseppe'),
(16959, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:16952', NULL, 1235582134, 'pgiuseppe'),
(16961, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5326";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5191";}}}', 0, '', 'Figure:16948', NULL, 1235582134, 'pgiuseppe'),
(16966, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:29:"dann bekommst Du ein 2 GB JAR";}}}', 0, '', 'Activity:16949', NULL, 1235582137, 'pgiuseppe'),
(16967, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5182";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5180";}}}', 0, '', 'Figure:16948', NULL, 1235582139, 'pgiuseppe'),
(16969, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5651";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5152";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:16968', NULL, 1235582145, 'marco.eilers'),
(16974, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:16973', NULL, 1235582150, 'pgiuseppe'),
(16977, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5224";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5340";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:16972', NULL, 1235582150, 'pgiuseppe'),
(16983, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5545";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5216";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:16980', NULL, 1235582160, 'pgiuseppe'),
(16987, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:20:"New ActivityDecision";}}}', 0, '', 'ActivityDecision:16981', NULL, 1235582161, 'pgiuseppe'),
(16988, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5484";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5237";}}}', 0, '', 'Figure:16980', NULL, 1235582161, 'pgiuseppe'),
(16989, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:36:"leider musst Du noch 10 Jahre warten";}}}', 0, '', 'ActivityDecision:16981', NULL, 1235582165, 'pgiuseppe'),
(16990, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5393";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5233";}}}', 0, '', 'Figure:16980', NULL, 1235582167, 'pgiuseppe'),
(16993, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5237";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5098";}}}', 0, '', 'Figure:16948', NULL, 1235582168, 'pgiuseppe'),
(16995, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5225";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5397";}}}', 0, '', 'Figure:16972', NULL, 1235582169, 'pgiuseppe'),
(17000, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5277";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5261";}}}', 0, '', 'Figure:16980', NULL, 1235582171, 'pgiuseppe'),
(17003, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:61:"bis Du einen Rechner kaufen kannst, auf dem es ausführbar ist";}}}', 0, '', 'Activity:16973', NULL, 1235582185, 'pgiuseppe'),
(17004, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5246";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5404";}}}', 0, '', 'Figure:16972', NULL, 1235582188, 'pgiuseppe'),
(17007, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5259";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5252";}}}', 0, '', 'Figure:16980', NULL, 1235582189, 'pgiuseppe'),
(17009, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5259";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5358";}}}', 0, '', 'Figure:16980', NULL, 1235582194, 'pgiuseppe'),
(17010, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"51";}}}', 0, '', 'Figure:16980', NULL, 1235582194, 'pgiuseppe'),
(17011, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5259";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5240";}}}', 0, '', 'Figure:16980', NULL, 1235582195, 'pgiuseppe'),
(17015, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5229";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5402";}}}', 0, '', 'Figure:16972', NULL, 1235582198, 'pgiuseppe'),
(17018, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5124";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5147";}}}', 0, '', 'Figure:16948', NULL, 1235582200, 'pgiuseppe'),
(17021, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5313";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5156";}}}', 0, '', 'Figure:16980', NULL, 1235582201, 'pgiuseppe'),
(17024, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5454";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5151";}}}', 0, '', 'Figure:16972', NULL, 1235582204, 'pgiuseppe'),
(17025, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"155";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:16972', NULL, 1235582210, 'pgiuseppe'),
(17028, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5065";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5147";}}}', 0, '', 'Figure:16948', NULL, 1235582212, 'pgiuseppe'),
(17029, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"154";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:16948', NULL, 1235582213, 'pgiuseppe'),
(17033, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, '', 'ActivityInitial:17031', NULL, 1235582235, 'pgiuseppe'),
(17036, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5083";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5059";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:17030', NULL, 1235582235, 'pgiuseppe'),
(17038, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, '', 'ActivityInitial:17032', NULL, 1235582236, 'pgiuseppe'),
(17040, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5082";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5041";}}}', 0, '', 'Figure:17030', NULL, 1235582236, 'pgiuseppe'),
(17043, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:17042', NULL, 1235582253, 'pgiuseppe'),
(17046, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:17044', NULL, 1235582254, 'pgiuseppe'),
(17048, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5447";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5362";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:17041', NULL, 1235582255, 'pgiuseppe'),
(17050, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:31:"dann startest Du es und -- ZACK";}}}', 0, '', 'Activity:17042', NULL, 1235582260, 'pgiuseppe'),
(17051, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"161";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:17041', NULL, 1235582262, 'pgiuseppe'),
(17052, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5451";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5333";}}}', 0, '', 'Figure:17041', NULL, 1235582264, 'pgiuseppe'),
(17061, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5683";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5152";}}}', 0, '', 'Figure:17041', NULL, 1235582288, 'pgiuseppe'),
(17062, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5711";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5151";}}}', 0, '', 'Figure:17041', NULL, 1235582290, 'pgiuseppe'),
(17065, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5038";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5012";}}}', 0, '', 'Figure:17030', NULL, 1235582297, 'pgiuseppe'),
(17069, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, '', 'ActivityFinal:17067', NULL, 1235582314, 'pgiuseppe'),
(17070, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5741";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5315";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:17066', NULL, 1235582314, 'pgiuseppe'),
(17074, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5713";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5309";}}}', 0, '', 'Figure:17066', NULL, 1235582315, 'pgiuseppe'),
(17075, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:31:"dann startest Du es und -- ZACK";}}}', 0, '', 'ActivityFinal:17067', NULL, 1235582323, 'pgiuseppe'),
(17076, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5775";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5310";}}}', 0, '', 'Figure:17066', NULL, 1235582327, 'pgiuseppe'),
(17081, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:17080', NULL, 1235582364, 'pgiuseppe'),
(17083, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5219";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5065";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:17079', NULL, 1235582364, 'pgiuseppe'),
(17087, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5118";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5354";}}}', 0, '', 'Figure:17079', NULL, 1235582365, 'pgiuseppe'),
(17088, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:28:"ein intelligenter Textparser";}}}', 0, '', 'Activity:17080', NULL, 1235582371, 'pgiuseppe'),
(17089, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5124";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5373";}}}', 0, '', 'Figure:17079', NULL, 1235582373, 'pgiuseppe'),
(17090, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5209";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5032";}}}', 0, '', 'Figure:17079', NULL, 1235582520, 'pgiuseppe'),
(17094, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:17092', NULL, 1235582540, 'pgiuseppe'),
(17097, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5414";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5052";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:17091', NULL, 1235582540, 'pgiuseppe'),
(17100, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:17093', NULL, 1235582541, 'pgiuseppe'),
(17101, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:40:"Du gibst ein "Erzeuge Modell für MoMa"";}}}', 0, '', 'Activity:17092', NULL, 1235582546, 'pgiuseppe'),
(17102, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5394";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5026";}}}', 0, '', 'Figure:17091', NULL, 1235582550, 'pgiuseppe'),
(17103, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"152";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:17091', NULL, 1235582552, 'pgiuseppe'),
(17104, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5394";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5049";}}}', 0, '', 'Figure:17091', NULL, 1235582555, 'pgiuseppe'),
(17105, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5379";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5027";}}}', 0, '', 'Figure:17091', NULL, 1235582557, 'pgiuseppe'),
(17108, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5186";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5032";}}}', 0, '', 'Figure:17079', NULL, 1235582563, 'pgiuseppe'),
(17112, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:17110', NULL, 1235582587, 'pgiuseppe'),
(17114, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5604";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5053";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:17109', NULL, 1235582588, 'pgiuseppe'),
(17117, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5604";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5037";}}}', 0, '', 'Figure:17109', NULL, 1235582589, 'pgiuseppe'),
(17118, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:62:"er bietet Dir nach 0,02 Sekunden eine UML-Datei von 500 MB an ";}}}', 0, '', 'Activity:17110', NULL, 1235582592, 'pgiuseppe'),
(17119, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5627";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5026";}}}', 0, '', 'Figure:17109', NULL, 1235582639, 'pgiuseppe'),
(17120, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"122";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:17109', NULL, 1235582641, 'pgiuseppe'),
(17121, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5628";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5018";}}}', 0, '', 'Figure:17109', NULL, 1235582642, 'pgiuseppe'),
(17122, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"148";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:17109', NULL, 1235582643, 'pgiuseppe'),
(17123, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5635";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5023";}}}', 0, '', 'Figure:17109', NULL, 1235582643, 'pgiuseppe'),
(17127, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5396";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5275";}}}', 0, '', 'Figure:16893', NULL, 1235582645, 'marco.eilers'),
(17131, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5194";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5075";}}}', 0, '', 'Figure:16893', NULL, 1235582654, 'marco.eilers'),
(17137, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5034";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5029";}}}', 0, '', 'Figure:17030', NULL, 1235582670, 'pgiuseppe'),
(17144, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5771";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5365";}}}', 0, '', 'Figure:17066', NULL, 1235582681, 'pgiuseppe'),
(17148, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5709";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5206";}}}', 0, '', 'Figure:17041', NULL, 1235582682, 'pgiuseppe'),
(17151, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5453";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5211";}}}', 0, '', 'Figure:16972', NULL, 1235582684, 'pgiuseppe'),
(17154, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5312";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5213";}}}', 0, '', 'Figure:16980', NULL, 1235582685, 'pgiuseppe'),
(17157, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5055";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5208";}}}', 0, '', 'Figure:16948', NULL, 1235582686, 'pgiuseppe'),
(17164, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5647";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5083";}}}', 0, '', 'Figure:17109', NULL, 1235582713, 'pgiuseppe'),
(17167, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5309";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5231";}}}', 0, '', 'Figure:16980', NULL, 1235582714, 'pgiuseppe'),
(17169, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5453";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5234";}}}', 0, '', 'Figure:16972', NULL, 1235582715, 'pgiuseppe'),
(17172, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5709";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5217";}}}', 0, '', 'Figure:17041', NULL, 1235582716, 'pgiuseppe'),
(17175, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5771";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5387";}}}', 0, '', 'Figure:17066', NULL, 1235582717, 'pgiuseppe'),
(17179, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:17178', NULL, 1235582791, 'pgiuseppe'),
(17183, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5111";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5390";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:17177', NULL, 1235582792, 'pgiuseppe'),
(17184, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:17180', NULL, 1235582793, 'pgiuseppe'),
(17186, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5110";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5390";}}}', 0, '', 'Figure:17177', NULL, 1235582793, 'pgiuseppe'),
(17188, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:54:"dann brauchst Du 10 Jahre, um das Modell zu verstehen ";}}}', 0, '', 'Activity:17178', NULL, 1235582796, 'pgiuseppe'),
(17189, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"201";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:17177', NULL, 1235582799, 'pgiuseppe'),
(17190, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5088";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5401";}}}', 0, '', 'Figure:17177', NULL, 1235582801, 'pgiuseppe'),
(17191, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5134";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5496";}}}', 0, '', 'Figure:17177', NULL, 1235582989, 'pgiuseppe'),
(17193, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5043";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5310";}}}', 0, '', 'Figure:16948', NULL, 1235582990, 'pgiuseppe'),
(17196, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5299";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5309";}}}', 0, '', 'Figure:16980', NULL, 1235582991, 'pgiuseppe'),
(17200, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5450";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5310";}}}', 0, '', 'Figure:16972', NULL, 1235582992, 'pgiuseppe'),
(17215, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5771";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5388";}}}', 0, '', 'Figure:17066', NULL, 1235583117, 'pgiuseppe'),
(17217, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5760";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5406";}}}', 0, '', 'Figure:17066', NULL, 1235583129, 'pgiuseppe'),
(17218, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:47:"nach grad mal 20 Jahren ist Dein Projekt fertig";}}}', 0, '', 'ActivityFinal:17067', NULL, 1235583132, 'pgiuseppe'),
(17221, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5704";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5283";}}}', 0, '', 'Figure:17041', NULL, 1235583161, 'pgiuseppe'),
(17224, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5024";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5181";}}}', 0, '', 'Figure:17177', NULL, 1235583271, 'pgiuseppe'),
(17229, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5374";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5203";}}}', 0, '', 'Figure:16948', NULL, 1235583287, 'pgiuseppe'),
(17231, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5757";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5477";}}}', 0, '', 'Figure:17066', NULL, 1235583298, 'pgiuseppe'),
(17235, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5702";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5327";}}}', 0, '', 'Figure:17041', NULL, 1235583299, 'pgiuseppe'),
(17238, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5472";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5375";}}}', 0, '', 'Figure:16972', NULL, 1235583301, 'pgiuseppe'),
(17241, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5470";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5202";}}}', 0, '', 'Figure:16948', NULL, 1235583307, 'pgiuseppe'),
(17244, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5647";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5092";}}}', 0, '', 'Figure:17109', NULL, 1235583319, 'pgiuseppe'),
(17343, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Package";}}}', 0, '', 'Package:17342', NULL, 1235666455, 'pgiuseppe'),
(17347, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Package";}}}', 0, '', 'Package:17346', NULL, 1235666479, 'ibm'),
(17349, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:7:"Phase 1";}}}', 0, '', 'Package:17342', NULL, 1235666484, 'pgiuseppe'),
(17350, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Package";}}}', 0, '', 'Package:17348', NULL, 1235666485, 'ibm'),
(17353, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:7:"Phase 3";}}}', 0, '', 'Package:17348', NULL, 1235666518, 'ibm'),
(17355, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Package";}}}', 0, '', 'Package:17354', NULL, 1235666522, 'ibm'),
(17358, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:7:"Phase 7";}}}', 0, '', 'Package:17354', NULL, 1235666537, 'ibm'),
(17361, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:9:"Package 2";}}}', 0, '', 'Package:17346', NULL, 1235666560, 'ibm'),
(17367, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:147:"<ol><li>&nbsp;a</li><li>2</li><li>3</li></ol><ul><li>ddd</li><li>rrr</li><li>ttt</li></ul><b>gruppe a</b><br><u>gruppe b</u><br><i>gruppec </i><br>";}}}', 0, '', 'Package:17342', NULL, 1235666612, 'pgiuseppe'),
(17371, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:30:"&nbsp;Roll-out vorbereiten<br>";}}}', 0, '', 'Package:17354', NULL, 1235666624, 'ibm'),
(17374, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:96:"<ol><li>df</li><li>dsfa</li><li>dsf</li></ol><ul><li>a<b>ddd<i>dd<u>dd</u></i></b><br></li></ul>";}}}', 0, '', 'Package:17346', NULL, 1235666636, 'ibm'),
(17375, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:7:"Phase 2";}}}', 0, '', 'Package:17346', NULL, 1235666636, 'ibm'),
(17394, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:10:"&nbsp;test";}}}', 0, '', 'Package:17348', NULL, 1235666702, 'pgiuseppe'),
(17400, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:104:"<ol><li>df</li><li>dsfa</li><li>dsf</li></ol><ul><li>a<b>ddd<i>dd<u>dd</u></i></b></li></ul>P.J.<br><br>";}}}', 0, '', 'Package:17346', NULL, 1235666723, 'ibm'),
(17407, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:145:"<span id="inlineComboBoxSpanId"></span><ol><li>df</li><li>dsfa</li><li>dsf</li></ol><ul><li>a<b>ddd<i>dd<u>dd</u></i></b></li></ul>P.J.<br><br>";}}}', 0, '', 'Package:17346', NULL, 1235666795, 'ibm'),
(17408, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:60:"&nbsp;Roll-out<span id="inlineComboBoxSpanId"> <br></span>";}}}', 0, '', 'Package:17354', NULL, 1235666828, 'ibm'),
(17411, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:101:"Demo fuer phase 3<br>3.1<br>3.2<br>3.3<br>Gruppe AM<br>field<span id="inlineComboBoxSpanId"></span>";}}}', 0, '', 'Package:17348', NULL, 1235666834, 'ibm'),
(17415, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:246:"&nbsp;test gjfdgldghffdgfgkfdsgjfdgdfg <br> <span class="autocomplete-undefined">Area Manager</span>?<br> <span class="autocomplete-undefined">Field Worker performs Maintenance Call</span>?<br><br><span id="inlineComboBoxSpanId"></span><br>";}}}', 0, '', 'Package:17348', NULL, 1235666902, 'pgiuseppe'),
(17422, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:168:"<br><span id="inlineComboBoxSpanId">&nbsp;</span><span></span><ol><li>df</li><li>dsfa</li><li>dsf</li></ol><ul><li>a<b>ddd<i>dd<u>dd</u></i></b></li></ul>P.J.<br><br>";}}}', 0, '', 'Package:17346', NULL, 1235666942, 'ibm'),
(17429, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:17427', NULL, 1235666971, 'ibm'),
(17431, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:121:"<span></span><span></span>df<ol><li>dsfa</li><li>dsf</li></ol><ul><li>a<b>ddd<i>dd<u>dd</u></i></b></li></ul>P.J.<br><br>";}}}', 0, '', 'Package:17346', NULL, 1235666974, 'ibm'),
(17441, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:121:"<span></span><span></span>df<ol><li>dsfa</li><li>dsf</li></ol><ul><li>a<b>ddd<i>dd<u>dd</u></i></b></li></ul>P.J.<br><br>";}}}', 0, '', 'Package:17346', NULL, 1235667023, 'ibm'),
(17465, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:17464', NULL, 1235667138, 'ibm'),
(17469, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:17466', NULL, 1235667139, 'ibm'),
(17473, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:274:"&nbsp;test gjfdgldghffdgfgkfdsgjfdgdfg <br> <span class="autocomplete&gt;Area Manager&lt;/span&gt;?&lt;br&gt; &lt;span class=" autocomplete="">Field Worker performs Maintenance Call</span>?<br><br><span></span> <span class="autocomplete-undefined">Field Worker</span>?";}}}', 0, '', 'Package:17348', NULL, 1235667155, 'ibm'),
(17475, 'a:1:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"12";}}}', 0, '', 'Diagram:17466', NULL, 1235667220, 'ibm'),
(17476, 'a:1:{i:0;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:1:"2";}}}', 0, '', 'Diagram:17466', NULL, 1235667221, 'ibm'),
(17477, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:7:"Phase 3";}}}', 0, '', 'Diagram:17466', NULL, 1235667237, 'ibm'),
(17479, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:17478', NULL, 1235667261, 'pgiuseppe'),
(17483, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:16:"Phase 1 Overview";}}}', 0, '', 'Diagram:17478', NULL, 1235667303, 'pgiuseppe'),
(17484, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:16:"Phase 3 Overview";}}}', 0, '', 'Diagram:17466', NULL, 1235667314, 'ibm'),
(17485, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:16:"Phase 2 Overview";}}}', 0, '', 'Diagram:17464', NULL, 1235667318, 'ibm'),
(17487, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New Diagram";}}}', 0, '', 'Diagram:17486', NULL, 1235667332, 'ibm'),
(17490, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:16:"Phase 7 overview";}}}', 0, '', 'Package:17354', NULL, 1235667346, 'ibm'),
(17494, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New ChiGoal";}}}', 0, '', 'ChiGoal:17492', NULL, 1235667368, 'pgiuseppe'),
(17495, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:60:"&nbsp;in this diagram are all the object of this package<br>";}}}', 0, '', 'Diagram:17478', NULL, 1235667370, 'pgiuseppe'),
(17498, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5162";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5107";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17491', NULL, 1235667370, 'pgiuseppe'),
(17504, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New ChiGoal";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667379, 'ibm'),
(17505, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5294";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5158";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17501', NULL, 1235667379, 'ibm'),
(17511, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:57:"Beschreibung unendlicher Tatsachen und Halbwahrheiten<br>";}}}', 0, '', 'Diagram:17464', NULL, 1235667387, 'ibm'),
(17514, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New ChiGoal";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667389, 'ibm'),
(17516, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5398";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5174";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17510', NULL, 1235667392, 'ibm'),
(17517, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:27:"all objects in this phase 3";}}}', 0, '', 'Diagram:17466', NULL, 1235667392, 'ibm'),
(17522, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5397";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5173";}}}', 0, '', 'Figure:17510', NULL, 1235667414, 'ibm'),
(17523, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5396";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5172";}}}', 0, '', 'Figure:17510', NULL, 1235667415, 'ibm'),
(17526, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5317";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5130";}}}', 0, '', 'Figure:17510', NULL, 1235667416, 'ibm'),
(17530, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17492', NULL, 1235667429, 'pgiuseppe'),
(17531, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:14:"rule the world";}}}', 0, '', 'ChiGoal:17492', NULL, 1235667435, 'pgiuseppe'),
(17532, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667449, 'ibm'),
(17533, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667452, 'ibm'),
(17534, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:14:"EEnergy Phasen";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667463, 'ibm'),
(17535, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17492', NULL, 1235667469, 'pgiuseppe'),
(17536, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17492', NULL, 1235667476, 'pgiuseppe'),
(17537, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667476, 'ibm'),
(17538, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667478, 'ibm'),
(17539, 'a:1:{i:0;a:1:{s:10:"Value_Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:13:"world surface";}}}', 0, '', 'ChiGoal:17492', NULL, 1235667486, 'pgiuseppe'),
(17540, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17492', NULL, 1235667486, 'pgiuseppe'),
(17541, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667488, 'ibm'),
(17542, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667489, 'ibm'),
(17543, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667494, 'ibm'),
(17546, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"0,0%";}}}', 0, '', 'ChiGoal:17492', NULL, 1235667504, 'pgiuseppe'),
(17547, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17492', NULL, 1235667505, 'pgiuseppe'),
(17548, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667509, 'ibm'),
(17551, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667516, 'ibm'),
(17552, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:1:"0";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667518, 'ibm'),
(17553, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667518, 'ibm'),
(17554, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"90 %";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667524, 'ibm'),
(17555, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667524, 'ibm'),
(17556, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:1:"0";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667524, 'ibm');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES
(17557, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667525, 'ibm'),
(17558, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667525, 'ibm'),
(17559, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"2 %";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667534, 'ibm'),
(17560, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667534, 'ibm'),
(17562, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"0,2";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667535, 'ibm'),
(17563, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667535, 'ibm'),
(17566, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"New ChiGoal";}}}', 0, '', 'ChiGoal:17564', NULL, 1235667545, 'ibm'),
(17568, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5274";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5166";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17561', NULL, 1235667547, 'ibm'),
(17571, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"51%";}}}', 0, '', 'ChiGoal:17492', NULL, 1235667556, 'pgiuseppe'),
(17572, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17492', NULL, 1235667557, 'pgiuseppe'),
(17575, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"0,1";}}}', 0, '', 'ChiGoal:17564', NULL, 1235667559, 'ibm'),
(17576, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235667559, 'pgiuseppe'),
(17577, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5157";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5204";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17573', NULL, 1235667560, 'pgiuseppe'),
(17581, 'a:1:{i:0;a:1:{s:10:"Value_Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:9:"Einsparen";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667562, 'ibm'),
(17582, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667562, 'ibm'),
(17583, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667563, 'ibm'),
(17584, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667564, 'ibm'),
(17586, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667565, 'ibm'),
(17587, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667565, 'ibm'),
(17589, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:17588', NULL, 1235667567, 'ibm'),
(17590, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667567, 'ibm'),
(17592, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17512', NULL, 1235667567, 'ibm'),
(17593, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5411";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5334";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17585', NULL, 1235667568, 'ibm'),
(17595, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:21:"&nbsp;Marktreife <br>";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667568, 'ibm'),
(17598, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"55";}}}', 0, '', 'ChiGoal:17564', NULL, 1235667569, 'ibm'),
(17601, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:17600', NULL, 1235667570, 'ibm'),
(17605, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5350";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5242";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17591', NULL, 1235667572, 'ibm'),
(17607, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17564', NULL, 1235667577, 'ibm'),
(17608, 'a:1:{i:0;a:1:{s:10:"Value_Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"Puzzle them all";}}}', 0, '', 'ChiGoal:17564', NULL, 1235667595, 'ibm'),
(17609, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17564', NULL, 1235667597, 'ibm'),
(17610, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17564', NULL, 1235667600, 'ibm'),
(17611, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5534";}}}', 0, '', 'ChiGoal:17564', NULL, 1235667600, 'ibm'),
(17614, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"rule over germany";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235667602, 'pgiuseppe'),
(17615, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667603, 'ibm'),
(17617, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5286";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5279";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17612', NULL, 1235667604, 'ibm'),
(17625, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:9:"Freigabe ";}}}', 0, '', 'ChiRequirement:17588', NULL, 1235667625, 'ibm'),
(17627, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:35:"&nbsp;Freigabe vom User erteilt<br>";}}}', 0, '', 'ChiRequirement:17588', NULL, 1235667625, 'ibm'),
(17628, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5349";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5243";}}}', 0, '', 'Figure:17591', NULL, 1235667629, 'ibm'),
(17629, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5324";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5241";}}}', 0, '', 'Figure:17591', NULL, 1235667630, 'ibm'),
(17632, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:17631', NULL, 1235667634, 'pgiuseppe'),
(17634, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5230";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5288";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17630', NULL, 1235667634, 'pgiuseppe'),
(17637, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4116";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667640, 'ibm'),
(17638, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:9:"Windkraft";}}}', 0, '', 'ChiRequirement:17600', NULL, 1235667643, 'ibm'),
(17639, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"rule over Italy";}}}', 0, '', 'ChiRequirement:17631', NULL, 1235667646, 'pgiuseppe'),
(17640, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4116";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667646, 'ibm'),
(17642, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:10:"Marktreife";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667650, 'ibm'),
(17646, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:17644', NULL, 1235667654, 'ibm'),
(17647, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5348";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5318";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17641', NULL, 1235667656, 'ibm'),
(17649, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5193";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5285";}}}', 0, '', 'Figure:17612', NULL, 1235667657, 'ibm'),
(17655, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:17654', NULL, 1235667662, 'ibm'),
(17656, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5005";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667662, 'ibm'),
(17658, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5137";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5333";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17652', NULL, 1235667662, 'ibm'),
(17659, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4116";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667662, 'ibm'),
(17662, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"BHKW";}}}', 0, '', 'ChiRequirement:17644', NULL, 1235667677, 'ibm'),
(17663, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5322";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5317";}}}', 0, '', 'Figure:17641', NULL, 1235667681, 'ibm'),
(17664, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:14:"puzzle Germany";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667698, 'ibm'),
(17665, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4116";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667699, 'ibm'),
(17666, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5005";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667699, 'ibm'),
(17667, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5005";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667706, 'ibm'),
(17668, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4116";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667707, 'ibm'),
(17669, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4116";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667709, 'ibm'),
(17670, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5005";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667709, 'ibm'),
(17671, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4116";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667710, 'ibm'),
(17673, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5005";}}}', 0, '', 'ChiRequirement:17613', NULL, 1235667711, 'ibm'),
(17675, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:17674', NULL, 1235667713, 'ibm'),
(17677, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5430";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5349";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17672', NULL, 1235667714, 'ibm'),
(17682, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5160";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5035";}}}', 0, '', 'Figure:17491', NULL, 1235667721, 'pgiuseppe'),
(17683, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4116";}}}', 0, '', 'ChiRequirement:17674', NULL, 1235667722, 'ibm'),
(17686, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5041";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5233";}}}', 0, '', 'Figure:17573', NULL, 1235667731, 'pgiuseppe'),
(17688, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5089";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5282";}}}', 0, '', 'Figure:17591', NULL, 1235667732, 'ibm'),
(17692, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5445";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5297";}}}', 0, '', 'Figure:17641', NULL, 1235667735, 'ibm'),
(17694, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:9:"Puzzle US";}}}', 0, '', 'ChiRequirement:17674', NULL, 1235667737, 'ibm'),
(17695, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4116";}}}', 0, '', 'ChiRequirement:17674', NULL, 1235667737, 'ibm'),
(17697, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New ChiIssue";}}}', 0, '', 'ChiIssue:17696', NULL, 1235667738, 'pgiuseppe'),
(17698, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5187";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5446";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17693', NULL, 1235667739, 'pgiuseppe'),
(17708, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:20:"&nbsp;Marktakzeptanz";}}}', 0, '', 'ChiRequirement:17654', NULL, 1235667775, 'ibm'),
(17709, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"wird geliebt";}}}', 0, '', 'ChiRequirement:17654', NULL, 1235667775, 'ibm'),
(17711, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:40:"I have no money to pay for a second army";}}}', 0, '', 'ChiIssue:17696', NULL, 1235667789, 'pgiuseppe'),
(17714, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New ChiIssue";}}}', 0, '', 'ChiIssue:17713', NULL, 1235667792, 'ibm'),
(17715, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5058";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5202";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17712', NULL, 1235667792, 'ibm'),
(17722, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:14:"New ChiFeature";}}}', 0, '', 'ChiFeature:17720', NULL, 1235667794, 'pgiuseppe'),
(17725, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5059";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5388";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17719', NULL, 1235667796, 'pgiuseppe'),
(17726, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5186";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5296";}}}', 0, '', 'Figure:17612', NULL, 1235667796, 'ibm'),
(17728, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5036";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5388";}}}', 0, '', 'Figure:17719', NULL, 1235667797, 'pgiuseppe'),
(17731, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"Muss von SAP sein";}}}', 0, '', 'ChiIssue:17713', NULL, 1235667807, 'ibm'),
(17732, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:29:"pay an army to conqur germany";}}}', 0, '', 'ChiFeature:17720', NULL, 1235667811, 'pgiuseppe'),
(17737, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5239";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5416";}}}', 0, '', 'Figure:17693', NULL, 1235667822, 'pgiuseppe'),
(17742, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New ChiIssue";}}}', 0, '', 'ChiIssue:17741', NULL, 1235667823, 'ibm'),
(17744, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5608";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5200";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17734', NULL, 1235667824, 'ibm'),
(17748, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5486";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5210";}}}', 0, '', 'Figure:17734', NULL, 1235667828, 'ibm'),
(17761, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:14:"New ChiFeature";}}}', 0, '', 'ChiFeature:17760', NULL, 1235667908, 'ibm'),
(17762, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5115";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5385";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17759', NULL, 1235667908, 'ibm'),
(17766, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:13:"Kaufe Windrad";}}}', 0, '', 'ChiFeature:17760', NULL, 1235667931, 'ibm'),
(17769, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5055";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5406";}}}', 0, '', 'Figure:17759', NULL, 1235667940, 'ibm'),
(17772, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:14:"New ChiFeature";}}}', 0, '', 'ChiFeature:17771', NULL, 1235667947, 'ibm'),
(17777, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5264";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5413";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17770', NULL, 1235667948, 'ibm'),
(17780, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"Marktreife Core";}}}', 0, '', 'ChiGoal:17502', NULL, 1235667956, 'ibm'),
(17781, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"Kaufe Windrad Standort";}}}', 0, '', 'ChiFeature:17771', NULL, 1235667963, 'ibm'),
(17785, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5444";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5298";}}}', 0, '', 'Figure:17641', NULL, 1235668005, 'ibm'),
(17790, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New ChiIssue";}}}', 0, '', 'ChiIssue:17789', NULL, 1235668039, 'ibm'),
(17795, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5554";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5416";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17788', NULL, 1235668043, 'ibm'),
(17796, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:19:"Kein Geld fuer BHKW";}}}', 0, '', 'ChiIssue:17789', NULL, 1235668056, 'ibm'),
(17799, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5132";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5489";}}}', 0, '', 'Figure:17712', NULL, 1235668073, 'ibm'),
(17804, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5135";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5417";}}}', 0, '', 'Figure:17612', NULL, 1235668088, 'ibm'),
(17806, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5545";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5424";}}}', 0, '', 'Figure:17672', NULL, 1235668089, 'ibm'),
(17807, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5546";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5109";}}}', 0, '', 'Figure:17734', NULL, 1235668090, 'ibm'),
(17818, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:14:"New ChiFeature";}}}', 0, '', 'ChiFeature:17816', NULL, 1235668098, 'ibm'),
(17821, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5174";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5529";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17815', NULL, 1235668099, 'ibm'),
(17825, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:10:"Destroy TV";}}}', 0, '', 'ChiFeature:17816', NULL, 1235668114, 'ibm'),
(17841, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668175, 'pgiuseppe'),
(17842, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668179, 'pgiuseppe'),
(17843, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668197, 'pgiuseppe'),
(17848, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668213, 'pgiuseppe'),
(17849, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668225, 'pgiuseppe'),
(17850, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668225, 'pgiuseppe'),
(17851, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668232, 'pgiuseppe'),
(17852, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668233, 'pgiuseppe'),
(17855, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668243, 'pgiuseppe'),
(17856, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668244, 'pgiuseppe'),
(17857, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668252, 'pgiuseppe'),
(17859, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668253, 'pgiuseppe'),
(17860, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"745";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668253, 'pgiuseppe'),
(17861, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"745";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668253, 'pgiuseppe'),
(17863, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668261, 'pgiuseppe'),
(17864, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668261, 'pgiuseppe'),
(17865, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5135";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5416";}}}', 0, '', 'Figure:17612', NULL, 1235668261, 'ibm'),
(17868, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668263, 'pgiuseppe'),
(17869, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668264, 'pgiuseppe'),
(17870, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5007";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668264, 'pgiuseppe'),
(17873, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668276, 'pgiuseppe'),
(17878, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:17877', NULL, 1235668278, 'ibm'),
(17880, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5431";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5501";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17875', NULL, 1235668279, 'ibm'),
(17881, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668279, 'pgiuseppe'),
(17882, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668279, 'pgiuseppe'),
(17885, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668280, 'pgiuseppe'),
(17886, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668280, 'pgiuseppe'),
(17887, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668283, 'pgiuseppe'),
(17888, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668284, 'pgiuseppe'),
(17890, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5546";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5426";}}}', 0, '', 'Figure:17672', NULL, 1235668285, 'ibm'),
(17892, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668290, 'pgiuseppe'),
(17893, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5009";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668290, 'pgiuseppe'),
(17894, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5009";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668291, 'pgiuseppe'),
(17895, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668291, 'pgiuseppe'),
(17896, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5009";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668291, 'pgiuseppe'),
(17897, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5009";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668291, 'pgiuseppe'),
(17898, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5009";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668291, 'pgiuseppe'),
(17899, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668293, 'pgiuseppe'),
(17900, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668293, 'pgiuseppe'),
(17901, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5009";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668294, 'pgiuseppe'),
(17902, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5009";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668294, 'pgiuseppe'),
(17903, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5009";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668294, 'pgiuseppe'),
(17904, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5009";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668294, 'pgiuseppe'),
(17905, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5009";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668295, 'pgiuseppe'),
(17910, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668302, 'pgiuseppe'),
(17911, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668302, 'pgiuseppe'),
(17914, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668309, 'pgiuseppe'),
(17916, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668309, 'pgiuseppe'),
(17917, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668313, 'pgiuseppe'),
(17919, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668313, 'pgiuseppe'),
(17921, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668314, 'pgiuseppe'),
(17922, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668314, 'pgiuseppe'),
(17930, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668317, 'pgiuseppe'),
(17931, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668317, 'pgiuseppe'),
(17932, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668319, 'pgiuseppe'),
(17933, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668319, 'pgiuseppe'),
(17939, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668347, 'pgiuseppe'),
(17940, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668348, 'pgiuseppe'),
(17941, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668348, 'pgiuseppe'),
(17942, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668348, 'pgiuseppe'),
(17943, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668349, 'pgiuseppe'),
(17944, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668349, 'pgiuseppe'),
(17945, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"11238";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668349, 'pgiuseppe'),
(17946, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5652";}}}', 0, '', 'ChiRequirement:17574', NULL, 1235668349, 'pgiuseppe'),
(17949, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:17948', NULL, 1235668352, 'pgiuseppe'),
(17952, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5334";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5147";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17947', NULL, 1235668353, 'pgiuseppe'),
(17955, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5333";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5147";}}}', 0, '', 'Figure:17947', NULL, 1235668354, 'pgiuseppe'),
(17957, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:5:"Money";}}}', 0, '', 'ChiRequirement:17948', NULL, 1235668362, 'pgiuseppe'),
(17963, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:14:"New ChiFeature";}}}', 0, '', 'ChiFeature:17962', NULL, 1235668373, 'ibm'),
(17964, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5445";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5473";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17961', NULL, 1235668374, 'ibm'),
(17970, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5131";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5489";}}}', 0, '', 'Figure:17712', NULL, 1235668377, 'ibm'),
(17973, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:24:"Kunde: Muss von SAP sein";}}}', 0, '', 'ChiIssue:17713', NULL, 1235668390, 'ibm'),
(17975, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:17974', NULL, 1235668392, 'pgiuseppe'),
(17976, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5456";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5270";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17972', NULL, 1235668393, 'pgiuseppe'),
(17981, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5412";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5270";}}}', 0, '', 'Figure:17972', NULL, 1235668395, 'pgiuseppe'),
(17984, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New ChiIssue";}}}', 0, '', 'ChiIssue:17983', NULL, 1235668402, 'ibm'),
(17987, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5102";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5577";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:17982', NULL, 1235668403, 'ibm'),
(17990, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"get money legally";}}}', 0, '', 'ChiRequirement:17974', NULL, 1235668405, 'pgiuseppe'),
(18000, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"IBM: muss von IBM sein";}}}', 0, '', 'ChiIssue:17983', NULL, 1235668417, 'ibm'),
(18003, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, '', 'ChiRequirement:18002', NULL, 1235668420, 'pgiuseppe'),
(18006, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5587";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5275";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:18001', NULL, 1235668420, 'pgiuseppe'),
(18013, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5233";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5502";}}}', 0, '', 'Figure:17712', NULL, 1235668425, 'ibm'),
(18020, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5066";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5498";}}}', 0, '', 'Figure:17982', NULL, 1235668429, 'ibm'),
(18021, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:23:"Get money with violence";}}}', 0, '', 'ChiRequirement:18002', NULL, 1235668432, 'pgiuseppe'),
(18022, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5065";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5505";}}}', 0, '', 'Figure:17982', NULL, 1235668433, 'ibm'),
(18029, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:14:"New ChiFeature";}}}', 0, '', 'ChiFeature:18025', NULL, 1235668445, 'pgiuseppe'),
(18031, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5611";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5421";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:18023', NULL, 1235668445, 'pgiuseppe'),
(18061, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:35:"rush over the counties to get money";}}}', 0, '', 'ChiFeature:18025', NULL, 1235668483, 'pgiuseppe'),
(18062, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"userfriendly";}}}', 0, '', 'ChiFeature:17962', NULL, 1235668490, 'ibm'),
(18068, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, '', 'ChiBusinessUseCase:18067', NULL, 1235668602, 'pgiuseppe'),
(18071, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5059";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5482";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:18066', NULL, 1235668603, 'pgiuseppe'),
(18073, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5057";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5512";}}}', 0, '', 'Figure:18066', NULL, 1235668608, 'pgiuseppe'),
(18076, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, '', 'ChiBusinessUseCase:18075', NULL, 1235668616, 'ibm'),
(18077, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5446";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5528";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:18074', NULL, 1235668617, 'ibm'),
(18082, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"create the army";}}}', 0, '', 'ChiBusinessUseCase:18067', NULL, 1235668618, 'pgiuseppe'),
(18083, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4966";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5511";}}}', 0, '', 'Figure:18066', NULL, 1235668620, 'pgiuseppe'),
(18086, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, '', 'ChiBusinessUseCase:18085', NULL, 1235668624, 'pgiuseppe'),
(18087, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5112";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5527";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:18084', NULL, 1235668625, 'pgiuseppe'),
(18094, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:24:"send the army to germany";}}}', 0, '', 'ChiBusinessUseCase:18085', NULL, 1235668635, 'pgiuseppe'),
(18099, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, '', 'ChiBusinessUseCase:18096', NULL, 1235668636, 'ibm'),
(18101, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5061";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5517";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:18092', NULL, 1235668638, 'ibm'),
(18107, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5579";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5529";}}}', 0, '', 'Figure:18074', NULL, 1235668642, 'ibm'),
(18108, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, '', 'ChiBusinessUseCase:18106', NULL, 1235668643, 'pgiuseppe'),
(18109, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5241";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5554";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:18105', NULL, 1235668643, 'pgiuseppe'),
(18113, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5232";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5526";}}}', 0, '', 'Figure:18105', NULL, 1235668644, 'pgiuseppe'),
(18114, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"manage the army";}}}', 0, '', 'ChiBusinessUseCase:18106', NULL, 1235668651, 'pgiuseppe'),
(18117, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessPartner";}}}', 0, '', 'ChiBusinessPartner:18116', NULL, 1235668687, 'pgiuseppe'),
(18119, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4918";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5368";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"26";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"52";}}}', 0, '', 'Figure:18115', NULL, 1235668688, 'pgiuseppe'),
(18123, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:16:"Vendor Selection";}}}', 0, '', 'ChiBusinessUseCase:18096', NULL, 1235668692, 'ibm'),
(18129, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4914";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5332";}}}', 0, '', 'Figure:18115', NULL, 1235668696, 'pgiuseppe'),
(18132, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:9:"rectruter";}}}', 0, '', 'ChiBusinessPartner:18116', NULL, 1235668706, 'pgiuseppe'),
(18133, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, '', 'ChiBusinessUseCase:18131', NULL, 1235668706, 'ibm'),
(18138, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5183";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5572";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:18130', NULL, 1235668709, 'ibm'),
(18139, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, '', 'ChiBusinessUseCase:18136', NULL, 1235668709, 'ibm'),
(18141, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:10:"&nbsp;User";}}}', 0, '', 'ChiFeature:17962', NULL, 1235668709, 'ibm'),
(18143, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5651";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5594";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:18134', NULL, 1235668710, 'ibm'),
(18150, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, '', 'ChiBusinessUseCase:18149', NULL, 1235668725, 'ibm'),
(18152, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5492";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5656";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:18148', NULL, 1235668726, 'ibm'),
(18156, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:14:"Type Selection";}}}', 0, '', 'ChiBusinessUseCase:18131', NULL, 1235668727, 'ibm'),
(18157, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5158";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5518";}}}', 0, '', 'Figure:18130', NULL, 1235668730, 'ibm'),
(18160, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5011";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5519";}}}', 0, '', 'Figure:18092', NULL, 1235668732, 'ibm'),
(18163, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4961";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5524";}}}', 0, '', 'Figure:18066', NULL, 1235668752, 'pgiuseppe'),
(18165, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5174";}}}', 0, '', 'ChiBusinessUseCase:18136', NULL, 1235668755, 'ibm'),
(18166, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5174";}}}', 0, '', 'ChiBusinessUseCase:18136', NULL, 1235668759, 'ibm'),
(18167, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"give answers";}}}', 0, '', 'ChiBusinessUseCase:18136', NULL, 1235668779, 'ibm'),
(18168, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5174";}}}', 0, '', 'ChiBusinessUseCase:18136', NULL, 1235668780, 'ibm'),
(18174, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessProcess";}}}', 0, '', 'ChiBusinessProcess:18170', NULL, 1235668784, 'pgiuseppe'),
(18178, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5094";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5705";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"50";}}}', 0, '', 'Figure:18169', NULL, 1235668785, 'pgiuseppe'),
(18181, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessPartner";}}}', 0, '', 'ChiBusinessPartner:18177', NULL, 1235668786, 'ibm'),
(18182, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4876";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5459";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"26";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"52";}}}', 0, '', 'Figure:18173', NULL, 1235668787, 'ibm'),
(18183, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5045";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5727";}}}', 0, '', 'Figure:18169', NULL, 1235668788, 'pgiuseppe'),
(18187, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5649";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5593";}}}', 0, '', 'Figure:18134', NULL, 1235668794, 'ibm'),
(18188, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5017";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5715";}}}', 0, '', 'Figure:18169', NULL, 1235668795, 'pgiuseppe'),
(18189, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5305";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5647";}}}', 0, '', 'Figure:18134', NULL, 1235668796, 'ibm'),
(18192, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5618";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5590";}}}', 0, '', 'Figure:18148', NULL, 1235668797, 'ibm'),
(18195, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5434";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5597";}}}', 0, '', 'Figure:18134', NULL, 1235668800, 'ibm'),
(18196, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:11:"manage army";}}}', 0, '', 'ChiBusinessProcess:18170', NULL, 1235668804, 'pgiuseppe'),
(18199, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:18:"Windrad Einkaeufer";}}}', 0, '', 'ChiBusinessPartner:18177', NULL, 1235668806, 'ibm'),
(18200, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4874";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5459";}}}', 0, '', 'Figure:18173', NULL, 1235668806, 'ibm');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES
(18208, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5052";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5745";}}}', 0, '', 'Figure:18169', NULL, 1235668814, 'pgiuseppe'),
(18220, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, '', 'ChiBusinessUseCase:18219', NULL, 1235668830, 'ibm'),
(18221, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5129";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5638";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}}', 0, '', 'Figure:18218', NULL, 1235668831, 'ibm'),
(18226, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:20:"Spezifiziere Windrad";}}}', 0, '', 'ChiBusinessUseCase:18219', NULL, 1235668854, 'ibm'),
(18228, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4894";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5560";}}}', 0, '', 'Figure:18092', NULL, 1235668861, 'ibm'),
(18230, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5272";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5630";}}}', 0, '', 'Figure:18130', NULL, 1235668863, 'ibm'),
(18235, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:21:"New ChiWorkerInternal";}}}', 0, '', 'ChiWorkerInternal:18234', NULL, 1235668896, 'ibm'),
(18239, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5294";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5684";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"48";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"52";}}}', 0, '', 'Figure:18233', NULL, 1235668898, 'ibm'),
(18263, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"4956";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5639";}}}', 0, '', 'Figure:18092', NULL, 1235669011, 'ibm'),
(18266, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5103";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5641";}}}', 0, '', 'Figure:18218', NULL, 1235669013, 'ibm'),
(18269, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:28:"New ChiBusinessPartnerActive";}}}', 0, '', 'ChiBusinessPartnerActive:18268', NULL, 1235669038, 'ibm'),
(18271, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5397";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5524";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"27";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"52";}}}', 0, '', 'Figure:18267', NULL, 1235669040, 'ibm'),
(18275, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:20:"Windrad Spezifiierer";}}}', 0, '', 'ChiBusinessPartnerActive:18268', NULL, 1235669065, 'ibm'),
(18276, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5428";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5564";}}}', 0, '', 'Figure:18267', NULL, 1235669081, 'ibm'),
(18278, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5285";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5772";}}}', 0, '', 'Figure:18267', NULL, 1235669097, 'ibm'),
(18288, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"New ActivitySet";}}}', 0, '', 'ActivitySet:18287', NULL, 1235669255, 'pgiuseppe'),
(18291, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:68:"<ol><li>&nbsp;a</li><li>b</li><li>c</li><li>d</li><li><br></li></ol>";}}}', 0, '', 'ChiBusinessUseCase:18067', NULL, 1235669262, 'pgiuseppe'),
(18294, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"New ActivitySet";}}}', 0, '', 'ActivitySet:18292', NULL, 1235669263, 'ibm'),
(18295, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"New ActivitySet";}}}', 0, '', 'ActivitySet:18292', NULL, 1235669264, 'ibm'),
(18297, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"New ActivitySet";}}}', 0, '', 'ActivitySet:18296', NULL, 1235669277, 'ibm'),
(18311, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, '', 'ActivityInitial:18309', NULL, 1235669308, 'pgiuseppe'),
(18312, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5112";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5101";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:18307', NULL, 1235669309, 'pgiuseppe'),
(18319, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:18317', NULL, 1235669314, 'pgiuseppe'),
(18322, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5100";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5208";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:18316', NULL, 1235669314, 'pgiuseppe'),
(18324, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:18318', NULL, 1235669315, 'pgiuseppe'),
(18328, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, '', 'ActivityFinal:18326', NULL, 1235669323, 'pgiuseppe'),
(18330, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5081";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5356";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:18325', NULL, 1235669323, 'pgiuseppe'),
(18331, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, '', 'ActivityFinal:18327', NULL, 1235669323, 'pgiuseppe'),
(18363, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:20:"New ActivityDecision";}}}', 0, '', 'ActivityDecision:18361', NULL, 1235669381, 'pgiuseppe'),
(18364, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:94:"<ol><li>&nbsp;a</li><li>b</li><li>c</li><li>a)</li><li>b)<br></li><li>d</li><li><br></li></ol>";}}}', 0, '', 'ChiBusinessUseCase:18067', NULL, 1235669381, 'pgiuseppe'),
(18367, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5247";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5226";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:18360', NULL, 1235669381, 'pgiuseppe'),
(18368, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:20:"New ActivityDecision";}}}', 0, '', 'ActivityDecision:18362', NULL, 1235669382, 'pgiuseppe'),
(18372, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5217";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5317";}}}', 0, '', 'Figure:18360', NULL, 1235669383, 'pgiuseppe'),
(18385, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:18383', NULL, 1235669392, 'pgiuseppe'),
(18386, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5124";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5483";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:18382', NULL, 1235669392, 'pgiuseppe'),
(18394, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:18393', NULL, 1235669396, 'pgiuseppe'),
(18397, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5292";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5502";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:18392', NULL, 1235669397, 'pgiuseppe'),
(18405, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5237";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5627";}}}', 0, '', 'Figure:18325', NULL, 1235669404, 'pgiuseppe'),
(18412, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:1:"a";}}}', 0, '', 'Activity:18317', NULL, 1235669482, 'pgiuseppe'),
(18415, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:96:"<ol><li>&nbsp;a</li><li>b</li><li>c</li><li>aa)</li><li>bb)<br></li><li>d</li><li><br></li></ol>";}}}', 0, '', 'ChiBusinessUseCase:18067', NULL, 1235669498, 'pgiuseppe'),
(18418, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"aa";}}}', 0, '', 'Activity:18383', NULL, 1235669503, 'pgiuseppe'),
(18419, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5291";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5502";}}}', 0, '', 'Figure:18392', NULL, 1235669503, 'pgiuseppe'),
(18422, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"bb";}}}', 0, '', 'Activity:18393', NULL, 1235669509, 'pgiuseppe'),
(18425, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5225";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5654";}}}', 0, '', 'Figure:18325', NULL, 1235669513, 'pgiuseppe'),
(18430, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"New ActivitySet";}}}', 0, '', 'ActivitySet:18428', NULL, 1235669602, 'pgiuseppe'),
(18434, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:15:"New ActivitySet";}}}', 0, '', 'ActivitySet:18432', NULL, 1235669606, 'ibm'),
(18435, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:96:"<ol><li>&nbsp;a</li><li>b</li><li>c</li><li>aa)</li><li>bb)<br></li><li>d</li><li><br></li></ol>";}}}', 0, '', 'ChiBusinessUseCase:18067', NULL, 1235669606, 'pgiuseppe'),
(18441, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, '', 'ActivityInitial:18440', NULL, 1235669617, 'ibm'),
(18443, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:59:"<ol><li>&nbsp;a</li><li>b</li><li>c</li><li>d<br></li></ol>";}}}', 0, '', 'ChiBusinessUseCase:18149', NULL, 1235669618, 'ibm'),
(18444, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5197";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5231";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:18439', NULL, 1235669618, 'ibm'),
(18446, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, '', 'ActivityInitial:18442', NULL, 1235669619, 'ibm'),
(18450, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:24:"Manage the army activity";}}}', 0, '', 'ActivitySet:18428', NULL, 1235669623, 'pgiuseppe'),
(18452, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:12:"New Activity";}}}', 0, '', 'Activity:18451', NULL, 1235669623, 'ibm'),
(18454, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5375";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5459";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"60";}}}', 0, '', 'Figure:18449', NULL, 1235669624, 'ibm'),
(18460, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, '', 'ActivityFinal:18457', NULL, 1235669625, 'pgiuseppe'),
(18462, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5203";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5081";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"40";}}}', 0, '', 'Figure:18453', NULL, 1235669626, 'pgiuseppe'),
(18465, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, '', 'ActivityFinal:18461', NULL, 1235669627, 'pgiuseppe'),
(18469, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:19:"New ActivityReceive";}}}', 0, '', 'ActivityReceive:18468', NULL, 1235669631, 'pgiuseppe'),
(18470, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5186";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5229";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"75";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"45";}}}', 0, '', 'Figure:18467', NULL, 1235669631, 'pgiuseppe'),
(18477, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:16:"New ActivitySend";}}}', 0, '', 'ActivitySend:18476', NULL, 1235669635, 'pgiuseppe'),
(18478, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5114";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5329";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"80";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"45";}}}', 0, '', 'Figure:18475', NULL, 1235669635, 'pgiuseppe'),
(18484, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:19:"New ActivityReceive";}}}', 0, '', 'ActivityReceive:18483', NULL, 1235669645, 'ibm'),
(18489, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5557";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5246";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"75";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"45";}}}', 0, '', 'Figure:18482', NULL, 1235669647, 'ibm'),
(18492, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5288";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5101";}}}', 0, '', 'Figure:17561', NULL, 1235669672, 'ibm'),
(18495, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5843";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5457";}}}', 0, '', 'Figure:17672', NULL, 1235669677, 'ibm'),
(18496, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5162";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5463";}}}', 0, '', 'Figure:18482', NULL, 1235669681, 'ibm'),
(18500, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:16:"New ActivitySend";}}}', 0, '', 'ActivitySend:18498', NULL, 1235669698, 'ibm'),
(18505, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:16:"New ActivitySend";}}}', 0, '', 'ActivitySend:18501', NULL, 1235669699, 'ibm'),
(18506, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5647";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:4:"5484";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"80";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:2:"45";}}}', 0, '', 'Figure:18497', NULL, 1235669699, 'ibm'),
(18525, 'a:2:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:7:"Phase 1";}}i:1;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:0:"";s:8:"newValue";s:580:"<ol>\r\n    <li>&nbsp;a</li>\r\n    <li>2</li>\r\n</ol>\r\n<table width="200" cellspacing="1" cellpadding="1" border="1">\r\n    <tbody>\r\n        <tr>\r\n            <td>a</td>\r\n            <td>a</td>\r\n        </tr>\r\n        <tr>\r\n            <td>&nbsp;</td>\r\n            <td>&nbsp;</td>\r\n        </tr>\r\n        <tr>\r\n            <td>a</td>\r\n            <td>a</td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<ol>\r\n    <li>3</li>\r\n</ol>\r\n<ul>\r\n    <li>ddd</li>\r\n    <li>rrr</li>\r\n    <li>ttt</li>\r\n</ul>\r\n<p><b>gruppe a</b><br />\r\n<u>gruppe b</u><br />\r\n<i>gruppec </i></p>";}}}', 0, '', 'Package:17342', NULL, 1235724588, 'admin'),
(18573, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5007";}}}', 0, 'changeProperty', 'ChiRequirement:8502', NULL, 1235731045538556, 'pgiuseppe'),
(18574, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4695";s:8:"newValue";s:4:"4569";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4684";s:8:"newValue";s:4:"4438";}}}', 0, 'changeProperty', 'Figure:8785', NULL, 1235731047748034, 'pgiuseppe'),
(18575, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5007";s:8:"newValue";s:4:"5007";}}}', 0, 'changeProperty', 'ChiRequirement:8502', NULL, 1235731049506022, 'pgiuseppe'),
(18576, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5007";s:8:"newValue";s:4:"5007";}}}', 0, 'changeProperty', 'ChiRequirement:8502', NULL, 1235731055281417, 'pgiuseppe'),
(18577, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5007";s:8:"newValue";s:4:"5007";}}}', 0, 'changeProperty', 'ChiRequirement:8502', NULL, 1235731057279436, 'pgiuseppe'),
(18578, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5007";s:8:"newValue";s:4:"5007";}}}', 0, 'changeProperty', 'ChiRequirement:8502', NULL, 1235731057720022, 'pgiuseppe'),
(18579, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5007";s:8:"newValue";s:4:"5007";}}}', 0, 'changeProperty', 'ChiRequirement:8502', NULL, 1235731058187985, 'pgiuseppe'),
(18580, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5007";s:8:"newValue";s:4:"5007";}}}', 0, 'changeProperty', 'ChiRequirement:8502', NULL, 1235731062012689, 'pgiuseppe'),
(18581, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5007";s:8:"newValue";s:4:"5007";}}}', 0, 'changeProperty', 'ChiRequirement:8502', NULL, 1235731063124672, 'pgiuseppe'),
(18584, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5406";s:8:"newValue";s:4:"5570";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5346";s:8:"newValue";s:4:"5327";}}}', 0, 'changeProperty', 'Figure:9368', NULL, 1235731066326771, 'pgiuseppe'),
(18587, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5171";s:8:"newValue";s:4:"5510";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5313";s:8:"newValue";s:4:"5467";}}}', 0, 'changeProperty', 'Figure:10657', NULL, 1235731073307538, 'pgiuseppe'),
(18590, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5352";s:8:"newValue";s:4:"5249";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4968";s:8:"newValue";s:4:"4921";}}}', 0, 'changeProperty', 'Figure:8818', NULL, 1235731079750358, 'pgiuseppe'),
(18592, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5411";s:8:"newValue";s:4:"5140";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4832";s:8:"newValue";s:4:"5366";}}}', 0, 'changeProperty', 'Figure:9048', NULL, 1235731083016976, 'pgiuseppe'),
(18596, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4970";s:8:"newValue";s:4:"4962";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5230";s:8:"newValue";s:4:"5360";}}}', 0, 'changeProperty', 'Figure:9063', NULL, 1235731090466985, 'pgiuseppe'),
(18606, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Package";}}}', 0, 'changeProperty', 'Package:18605', NULL, 1235735389000960, 'ibm'),
(18655, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Diagram";}}}', 0, 'changeProperty', 'Diagram:18654', NULL, 1235740411980724, 'marco.eilers'),
(18659, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:15:"New ActivitySet";}}}', 0, 'changeProperty', 'ActivitySet:18658', NULL, 1235740554050400, 'marco.eilers'),
(18664, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, 'changeProperty', 'ActivityInitial:18663', NULL, 1235740585269731, 'marco.eilers'),
(18666, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5106";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5088";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}}', 0, 'changeProperty', 'Figure:18662', NULL, 1235740586079445, 'marco.eilers'),
(18669, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, 'changeProperty', 'ActivityInitial:18665', NULL, 1235740586634096, 'marco.eilers'),
(18682, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:18681', NULL, 1235740999135403, 'marco.eilers'),
(18687, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:18683', NULL, 1235741000976062, 'marco.eilers'),
(18688, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5470";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5139";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"60";}}}', 0, 'changeProperty', 'Figure:18680', NULL, 1235741001145064, 'marco.eilers'),
(18691, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:18690', NULL, 1235741129562087, 'marco.eilers'),
(18696, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5470";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5290";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"60";}}}', 0, 'changeProperty', 'Figure:18689', NULL, 1235741133743117, 'marco.eilers'),
(18698, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:18692', NULL, 1235741134658763, 'marco.eilers'),
(18701, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:19:"New ActivityReceive";}}}', 0, 'changeProperty', 'ActivityReceive:18700', NULL, 1235741290768792, 'marco.eilers'),
(18705, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5172";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5224";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"75";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"45";}}}', 0, 'changeProperty', 'Figure:18699', NULL, 1235741292962069, 'marco.eilers'),
(18708, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:16:"New ActivitySend";}}}', 0, 'changeProperty', 'ActivitySend:18707', NULL, 1235741307410150, 'marco.eilers'),
(18711, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5204";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5336";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"45";}}}', 0, 'changeProperty', 'Figure:18706', NULL, 1235741309033433, 'marco.eilers'),
(18715, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:18714', NULL, 1235741323080767, 'marco.eilers'),
(18720, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5688";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5108";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"60";}}}', 0, 'changeProperty', 'Figure:18713', NULL, 1235741324183403, 'marco.eilers'),
(18723, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:18722', NULL, 1235741338638515, 'marco.eilers'),
(18728, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5639";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5235";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}}', 0, 'changeProperty', 'Figure:18721', NULL, 1235741340631732, 'marco.eilers'),
(18729, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:18724', NULL, 1235741342701815, 'marco.eilers'),
(18732, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:18731', NULL, 1235741523692377, 'marco.eilers'),
(18736, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5295";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5063";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"60";}}}', 0, 'changeProperty', 'Figure:18730', NULL, 1235741526100447, 'marco.eilers'),
(18739, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:18738', NULL, 1235741543070593, 'marco.eilers'),
(18741, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:18740', NULL, 1235741551014891, 'marco.eilers'),
(18743, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:18742', NULL, 1235741554672807, 'marco.eilers'),
(18745, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:18744', NULL, 1235741561534617, 'marco.eilers'),
(18747, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:18746', NULL, 1235741652269598, 'marco.eilers'),
(18749, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:18748', NULL, 1235741656944159, 'marco.eilers'),
(18751, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:18750', NULL, 1235741672015804, 'marco.eilers'),
(18767, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4898";s:8:"newValue";s:4:"4975";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4944";s:8:"newValue";s:4:"4856";}}}', 0, 'changeProperty', 'Figure:10263', NULL, 1235749139872385, 'pgiuseppe'),
(18770, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4910";s:8:"newValue";s:4:"4995";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5187";s:8:"newValue";s:4:"4991";}}}', 0, 'changeProperty', 'Figure:10268', NULL, 1235749141041118, 'pgiuseppe'),
(18771, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:2:"96";s:8:"newValue";s:3:"204";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"95";s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:10268', NULL, 1235749146779435, 'pgiuseppe'),
(18772, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4995";s:8:"newValue";s:4:"4890";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4991";s:8:"newValue";s:4:"4990";}}}', 0, 'changeProperty', 'Figure:10268', NULL, 1235749147798887, 'pgiuseppe'),
(18775, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:2:"96";s:8:"newValue";s:3:"170";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"95";s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:10263', NULL, 1235749149462667, 'pgiuseppe'),
(18776, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4975";s:8:"newValue";s:4:"4902";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4856";s:8:"newValue";s:4:"4850";}}}', 0, 'changeProperty', 'Figure:10263', NULL, 1235749151423390, 'pgiuseppe'),
(18781, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:15:"New ActivitySet";}}}', 0, 'changeProperty', 'ActivitySet:18779', NULL, 1235749179176716, 'pgiuseppe'),
(18788, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:27:"Field Worker organizes Week";}}}', 0, 'changeProperty', 'ActivitySet:18779', NULL, 1235749220202848, 'pgiuseppe'),
(18791, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, 'changeProperty', 'ActivityInitial:18790', NULL, 1235749229467760, 'pgiuseppe'),
(18795, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5279";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5141";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}}', 0, 'changeProperty', 'Figure:18789', NULL, 1235749232425727, 'pgiuseppe'),
(18799, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:18798', NULL, 1235749256037160, 'pgiuseppe'),
(18803, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:18800', NULL, 1235749257178717, 'pgiuseppe'),
(18804, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5272";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5253";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"60";}}}', 0, 'changeProperty', 'Figure:18797', NULL, 1235749257581284, 'pgiuseppe'),
(18807, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5272";s:8:"newValue";s:4:"5260";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5253";s:8:"newValue";s:4:"5243";}}}', 0, 'changeProperty', 'Figure:18797', NULL, 1235749258895868, 'pgiuseppe'),
(18810, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5279";s:8:"newValue";s:4:"5277";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5141";s:8:"newValue";s:4:"5125";}}}', 0, 'changeProperty', 'Figure:18789', NULL, 1235749297999843, 'pgiuseppe'),
(18821, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5528";s:8:"newValue";s:4:"5222";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5489";s:8:"newValue";s:4:"5290";}}}', 0, 'changeProperty', 'Figure:9678', NULL, 1235749344145855, 'pgiuseppe'),
(18824, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5449";s:8:"newValue";s:4:"5426";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5072";s:8:"newValue";s:4:"5285";}}}', 0, 'changeProperty', 'Figure:9473', NULL, 1235749346261285, 'pgiuseppe'),
(18872, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:21:"New ChiWorkerInternal";}}}', 0, 'changeProperty', 'ChiWorkerInternal:18871', NULL, 1235749577007032, 'marco.eilers'),
(18873, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5138";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5172";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"48";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"52";}}}', 0, 'changeProperty', 'Figure:18870', NULL, 1235749577823154, 'marco.eilers'),
(18900, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5188";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5446";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:18899', NULL, 1235749771472062, 'marco.eilers'),
(18902, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5757";s:8:"newValue";s:4:"5758";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5477";s:8:"newValue";s:4:"5477";}}}', 0, 'changeProperty', 'Figure:17066', NULL, 1235749779557053, 'pgiuseppe'),
(18906, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5434";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5338";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:18903', NULL, 1235749785220087, 'marco.eilers'),
(18909, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:3:"201";s:8:"newValue";s:3:"215";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"60";s:8:"newValue";s:2:"60";}}}', 0, 'changeProperty', 'Figure:17177', NULL, 1235749786212002, 'pgiuseppe'),
(18910, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:3:"215";s:8:"newValue";s:3:"215";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"60";s:8:"newValue";s:2:"75";}}}', 0, 'changeProperty', 'Figure:17177', NULL, 1235749791000277, 'pgiuseppe'),
(18934, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5024";s:8:"newValue";s:4:"5040";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5181";s:8:"newValue";s:4:"5186";}}}', 0, 'changeProperty', 'Figure:17177', NULL, 1235749913252495, 'pgiuseppe'),
(18956, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New ChiNode";s:8:"newValue";s:6:"Alcool";}}}', 0, 'changeProperty', 'ChiNode:16713', NULL, 1235749992650299, 'pgiuseppe'),
(18957, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5415";s:8:"newValue";s:4:"5433";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5748";s:8:"newValue";s:4:"5785";}}}', 0, 'changeProperty', 'Figure:16712', NULL, 1235749995216941, 'pgiuseppe'),
(18958, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:1:" ";}}}', 0, 'changeProperty', 'ChiNode:16713', NULL, 1235750003687254, 'pgiuseppe'),
(18961, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:17:"New ChiController";s:8:"newValue";s:20:"drivedrinkController";}}}', 0, 'changeProperty', 'ChiController:16720', NULL, 1235750027901034, 'pgiuseppe'),
(18962, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:1:" ";}}}', 0, 'changeProperty', 'ChiController:16720', NULL, 1235750030036240, 'pgiuseppe'),
(18965, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:17:"New ChiController";s:8:"newValue";s:15:"CrashController";}}}', 0, 'changeProperty', 'ChiController:16754', NULL, 1235750048423876, 'pgiuseppe'),
(18966, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:1:" ";}}}', 0, 'changeProperty', 'ChiController:16754', NULL, 1235750052440461, 'pgiuseppe'),
(18969, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5020";s:8:"newValue";s:4:"5452";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5606";s:8:"newValue";s:4:"5929";}}}', 0, 'changeProperty', 'Figure:16705', NULL, 1235750053618110, 'pgiuseppe'),
(18972, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:8:"New Goal";s:8:"newValue";s:7:"Msssion";}}}', 0, 'changeProperty', 'ChiGoal:3474', NULL, 1235750108584747, 'pgiuseppe'),
(18973, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:7:"Msssion";s:8:"newValue";s:7:"Mission";}}}', 0, 'changeProperty', 'ChiGoal:3474', NULL, 1235750112386360, 'pgiuseppe'),
(18976, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:14:"New ChiFeature";}}}', 0, 'changeProperty', 'ChiFeature:18975', NULL, 1235750231029379, 'pgiuseppe'),
(18977, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4900";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5131";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:18974', NULL, 1235750233094930, 'pgiuseppe'),
(18981, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4900";s:8:"newValue";s:4:"5143";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5131";s:8:"newValue";s:4:"4945";}}}', 0, 'changeProperty', 'Figure:18974', NULL, 1235750235246380, 'pgiuseppe'),
(18984, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New ChiIssue";}}}', 0, 'changeProperty', 'ChiIssue:18983', NULL, 1235750243405023, 'pgiuseppe'),
(18987, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5550";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4946";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:18982', NULL, 1235750244083598, 'pgiuseppe'),
(18998, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5188";s:8:"newValue";s:4:"5196";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5446";s:8:"newValue";s:4:"5241";}}}', 0, 'changeProperty', 'Figure:18899', NULL, 1235751051867964, 'marco.eilers'),
(19000, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5434";s:8:"newValue";s:4:"5246";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5338";s:8:"newValue";s:4:"5513";}}}', 0, 'changeProperty', 'Figure:18903', NULL, 1235751054296143, 'marco.eilers'),
(19002, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5196";s:8:"newValue";s:4:"5496";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5241";s:8:"newValue";s:4:"5213";}}}', 0, 'changeProperty', 'Figure:18899', NULL, 1235751057042929, 'marco.eilers'),
(19048, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5510";s:8:"newValue";s:4:"5473";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5467";s:8:"newValue";s:4:"5513";}}}', 0, 'changeProperty', 'Figure:10657', NULL, 1235751172942692, 'marco.eilers'),
(19051, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5896";s:8:"newValue";s:4:"5859";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4335";s:8:"newValue";s:4:"4336";}}}', 0, 'changeProperty', 'Figure:8996', NULL, 1235751201688168, 'marco.eilers'),
(19053, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5468";s:8:"newValue";s:4:"5468";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4163";s:8:"newValue";s:4:"4162";}}}', 0, 'changeProperty', 'Figure:9290', NULL, 1235751244371212, 'marco.eilers'),
(19056, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5583";s:8:"newValue";s:4:"5583";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4344";s:8:"newValue";s:4:"4343";}}}', 0, 'changeProperty', 'Figure:9027', NULL, 1235751246099691, 'marco.eilers'),
(19061, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5859";s:8:"newValue";s:4:"5859";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4336";s:8:"newValue";s:4:"4334";}}}', 0, 'changeProperty', 'Figure:8996', NULL, 1235751255526678, 'marco.eilers'),
(19064, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5583";s:8:"newValue";s:4:"5611";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4343";s:8:"newValue";s:4:"4327";}}}', 0, 'changeProperty', 'Figure:9027', NULL, 1235751257287006, 'marco.eilers'),
(19131, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5262";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5387";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:19128', NULL, 1235751959039989, 'marco.eilers'),
(19154, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5151";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5108";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"52";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19150', NULL, 1235752625317798, 'pgiuseppe'),
(19161, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5316";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5166";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"52";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19156', NULL, 1235752641226141, 'pgiuseppe'),
(19162, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5316";s:8:"newValue";s:4:"5579";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5166";s:8:"newValue";s:4:"5212";}}}', 0, 'changeProperty', 'Figure:19156', NULL, 1235752649541696, 'pgiuseppe'),
(19164, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Package";}}}', 0, 'changeProperty', 'Package:19163', NULL, 1235753968787373, 'pgiuseppe'),
(19168, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Diagram";}}}', 0, 'changeProperty', 'Diagram:19167', NULL, 1235753974407150, 'pgiuseppe'),
(19174, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, 'changeProperty', 'ChiRequirement:19173', NULL, 1235753988693196, 'pgiuseppe'),
(19177, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5244";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5130";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19172', NULL, 1235753990561831, 'pgiuseppe'),
(19179, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:18:"New ChiRequirement";s:8:"newValue";s:54:"das System musst die Strommesswerte permanet speichern";}}}', 0, 'changeProperty', 'ChiRequirement:19173', NULL, 1235754007595207, 'pgiuseppe'),
(19180, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:3:"150";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"50";s:8:"newValue";s:2:"68";}}}', 0, 'changeProperty', 'Figure:19172', NULL, 1235754011359524, 'pgiuseppe'),
(19183, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:14:"New ChiFeature";}}}', 0, 'changeProperty', 'ChiFeature:19182', NULL, 1235754035531355, 'pgiuseppe'),
(19187, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5324";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5290";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19181', NULL, 1235754036667343, 'pgiuseppe'),
(19189, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5324";s:8:"newValue";s:4:"5250";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5290";s:8:"newValue";s:4:"5268";}}}', 0, 'changeProperty', 'Figure:19181', NULL, 1235754037530904, 'pgiuseppe'),
(19192, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, 'changeProperty', 'ChiBusinessUseCase:19191', NULL, 1235754046027878, 'pgiuseppe'),
(19196, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5328";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5427";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:19190', NULL, 1235754047534041, 'pgiuseppe'),
(19197, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5328";s:8:"newValue";s:4:"5272";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5427";s:8:"newValue";s:4:"5383";}}}', 0, 'changeProperty', 'Figure:19190', NULL, 1235754048572085, 'pgiuseppe'),
(19198, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:2:"96";s:8:"newValue";s:3:"167";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"95";s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:19190', NULL, 1235754051349266, 'pgiuseppe'),
(19199, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5272";s:8:"newValue";s:4:"5260";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5383";s:8:"newValue";s:4:"5381";}}}', 0, 'changeProperty', 'Figure:19190', NULL, 1235754052541591, 'pgiuseppe'),
(19200, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:22:"New ChiBusinessUseCase";s:8:"newValue";s:39:"Strommesswerte in Datenbank abspeichern";}}}', 0, 'changeProperty', 'ChiBusinessUseCase:19191', NULL, 1235754057652350, 'pgiuseppe'),
(19204, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:14:"New ChiFeature";s:8:"newValue";s:56:"das system wird (alle)  Daten in eine Datebenk speichern";}}}', 0, 'changeProperty', 'ChiFeature:19182', NULL, 1235754111401450, 'pgiuseppe'),
(19207, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, 'changeProperty', 'ChiRequirement:19206', NULL, 1235754119998554, 'pgiuseppe'),
(19212, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5515";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5127";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19205', NULL, 1235754121881548, 'pgiuseppe'),
(19213, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5515";s:8:"newValue";s:4:"5456";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5127";s:8:"newValue";s:4:"5137";}}}', 0, 'changeProperty', 'Figure:19205', NULL, 1235754122767948, 'pgiuseppe'),
(19215, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5456";s:8:"newValue";s:4:"5456";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5137";s:8:"newValue";s:4:"5138";}}}', 0, 'changeProperty', 'Figure:19205', NULL, 1235754126257445, 'pgiuseppe'),
(19218, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:54:"das System musst die Strommesswerte permanet speichern";s:8:"newValue";s:55:"das System musst die Strommesswerte permanent speichern";}}}', 0, 'changeProperty', 'ChiRequirement:19173', NULL, 1235754138563264, 'pgiuseppe'),
(19221, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:18:"New ChiRequirement";s:8:"newValue";s:35:"Das system soll Kudendaten behalten";}}}', 0, 'changeProperty', 'ChiRequirement:19206', NULL, 1235754166975624, 'pgiuseppe'),
(19224, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5250";s:8:"newValue";s:4:"5362";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5268";s:8:"newValue";s:4:"5270";}}}', 0, 'changeProperty', 'Figure:19181', NULL, 1235754169656927, 'pgiuseppe'),
(19227, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5260";s:8:"newValue";s:4:"5227";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5381";s:8:"newValue";s:4:"5375";}}}', 0, 'changeProperty', 'Figure:19190', NULL, 1235754171690180, 'pgiuseppe'),
(19235, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5415";s:8:"newValue";s:4:"5601";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5218";s:8:"newValue";s:4:"5312";}}}', 0, 'changeProperty', 'Figure:3021', NULL, 1236001605131200, 'pgiuseppe'),
(19238, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5631";s:8:"newValue";s:4:"5303";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5166";s:8:"newValue";s:4:"5145";}}}', 0, 'changeProperty', 'Figure:2987', NULL, 1236001609007108, 'pgiuseppe'),
(19281, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Package";}}}', 0, 'changeProperty', 'Package:19280', NULL, 1236004388596809, 'marco.eilers'),
(19284, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New Package";s:8:"newValue";s:10:"Test Marco";}}}', 0, 'changeProperty', 'Package:19280', NULL, 1236004398759877, 'marco.eilers'),
(19286, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Diagram";}}}', 0, 'changeProperty', 'Diagram:19285', NULL, 1236004401716541, 'marco.eilers'),
(19295, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5302";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5232";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19292', NULL, 1236004414504453, 'marco.eilers'),
(19296, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:14:"New ChiFeature";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004415384718, 'marco.eilers'),
(19299, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiGoal";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004443726209, 'marco.eilers'),
(19300, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5223";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5090";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19298', NULL, 1236004443882278, 'marco.eilers'),
(19303, 'a:1:{i:0;a:1:{s:8:"Priority";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004449123312, 'marco.eilers'),
(19308, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004467195839, 'marco.eilers'),
(19309, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004468026788, 'marco.eilers'),
(19310, 'a:1:{i:0;a:1:{s:10:"Value_Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004468902070, 'marco.eilers'),
(19311, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5530";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004470960528, 'marco.eilers'),
(19312, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:4:"5530";s:8:"newValue";s:4:"5530";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004471665351, 'marco.eilers');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES
(19313, 'a:1:{i:0;a:1:{s:7:"Version";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004472493092, 'marco.eilers'),
(19314, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:4:"5530";s:8:"newValue";s:4:"5530";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004472640642, 'marco.eilers'),
(19315, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:4:"5530";s:8:"newValue";s:4:"5530";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004472999937, 'marco.eilers'),
(19316, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New ChiGoal";s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004474277208, 'marco.eilers'),
(19317, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:4:"5530";s:8:"newValue";s:4:"5530";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004475406018, 'marco.eilers'),
(19318, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:4:"5530";s:8:"newValue";s:4:"5530";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004476094483, 'marco.eilers'),
(19319, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:4:"5530";s:8:"newValue";s:4:"5530";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004476852426, 'marco.eilers'),
(19322, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:8:"&nbsp;80";}}}', 0, 'changeProperty', 'ChiGoal:19297', NULL, 1236004477929060, 'marco.eilers'),
(19324, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:14:"New ChiAuthors";}}}', 0, 'changeProperty', 'ChiAuthors:19323', NULL, 1236004497547709, 'marco.eilers'),
(19327, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:14:"New ChiAuthors";s:8:"newValue";s:12:"Marco Eilers";}}}', 0, 'changeProperty', 'ChiAuthors:19323', NULL, 1236004506391513, 'marco.eilers'),
(19328, 'a:1:{i:0;a:1:{s:4:"Role";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"BA ";}}}', 0, 'changeProperty', 'ChiAuthors:19323', NULL, 1236004507907424, 'marco.eilers'),
(19329, 'a:1:{i:0;a:1:{s:4:"Role";a:2:{s:8:"oldValue";s:3:"BA ";s:8:"newValue";s:10:"BA Student";}}}', 0, 'changeProperty', 'ChiAuthors:19323', NULL, 1236004513623804, 'marco.eilers'),
(19340, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:15:"myName, Analyst";s:8:"newValue";s:5:"19323";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004543676754, 'marco.eilers'),
(19341, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:5:"19323";s:8:"newValue";s:5:"19323";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004545167899, 'marco.eilers'),
(19342, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:5:"19323";s:8:"newValue";s:5:"19323";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004546086665, 'marco.eilers'),
(19343, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:13:"aName, Client";s:8:"newValue";s:5:"13431";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004546627448, 'marco.eilers'),
(19344, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:5:"13431";s:8:"newValue";s:5:"13431";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004547687452, 'marco.eilers'),
(19345, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:5:"19323";s:8:"newValue";s:5:"19323";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004548113686, 'marco.eilers'),
(19346, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"70";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004549880736, 'marco.eilers'),
(19347, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:5:"13431";s:8:"newValue";s:5:"13431";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004550313918, 'marco.eilers'),
(19348, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:5:"19323";s:8:"newValue";s:5:"19323";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004550735394, 'marco.eilers'),
(19349, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:5:"19323";s:8:"newValue";s:5:"19323";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004552907144, 'marco.eilers'),
(19350, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:2:"70";s:8:"newValue";s:2:"70";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004553332038, 'marco.eilers'),
(19351, 'a:1:{i:0;a:1:{s:7:"Version";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004553709392, 'marco.eilers'),
(19352, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:5:"13431";s:8:"newValue";s:5:"13431";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004553867819, 'marco.eilers'),
(19353, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:14:"New ChiFeature";s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004554289740, 'marco.eilers'),
(19354, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:5:"13431";s:8:"newValue";s:5:"13431";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004555540124, 'marco.eilers'),
(19355, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:5:"19323";s:8:"newValue";s:5:"19323";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004555778136, 'marco.eilers'),
(19356, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:2:"70";s:8:"newValue";s:2:"70";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004556014447, 'marco.eilers'),
(19357, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:2:"70";s:8:"newValue";s:2:"70";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004556829852, 'marco.eilers'),
(19358, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:5:"19323";s:8:"newValue";s:5:"19323";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004557141767, 'marco.eilers'),
(19359, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:5:"13431";s:8:"newValue";s:5:"13431";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004557382357, 'marco.eilers'),
(19360, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:5:"19323";s:8:"newValue";s:5:"19323";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004557618298, 'marco.eilers'),
(19361, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:5:"13431";s:8:"newValue";s:5:"13431";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004557854652, 'marco.eilers'),
(19362, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:2:"70";s:8:"newValue";s:2:"70";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004558090900, 'marco.eilers'),
(19363, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:5:"13431";s:8:"newValue";s:5:"13431";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004560559618, 'marco.eilers'),
(19364, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:5:"19323";s:8:"newValue";s:5:"19323";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004560983307, 'marco.eilers'),
(19365, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:2:"70";s:8:"newValue";s:2:"70";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004561412294, 'marco.eilers'),
(19366, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:5:"19323";s:8:"newValue";s:5:"19323";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004561835446, 'marco.eilers'),
(19367, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:5:"13431";s:8:"newValue";s:5:"13431";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004562259137, 'marco.eilers'),
(19370, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:2:"70";s:8:"newValue";s:2:"70";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004564111832, 'marco.eilers'),
(19373, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5472";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5132";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19369', NULL, 1236004565002509, 'marco.eilers'),
(19374, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:8:"&nbsp;80";}}}', 0, 'changeProperty', 'ChiFeature:19291', NULL, 1236004565321510, 'marco.eilers'),
(19375, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004565475896, 'marco.eilers'),
(19376, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004568693177, 'marco.eilers'),
(19377, 'a:1:{i:0;a:1:{s:8:"Priority";a:2:{s:8:"oldValue";s:2:"50";s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004572442116, 'marco.eilers'),
(19378, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004572861778, 'marco.eilers'),
(19379, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004574284179, 'marco.eilers'),
(19380, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004575005500, 'marco.eilers'),
(19381, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:15:"myName, Analyst";s:8:"newValue";s:2:"58";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004575413191, 'marco.eilers'),
(19382, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:2:"58";s:8:"newValue";s:2:"58";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004576956126, 'marco.eilers'),
(19383, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004577365044, 'marco.eilers'),
(19384, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:13:"aName, Client";s:8:"newValue";s:4:"5652";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004578183948, 'marco.eilers'),
(19385, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004578529427, 'marco.eilers'),
(19386, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:2:"58";s:8:"newValue";s:2:"58";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004578678478, 'marco.eilers'),
(19387, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:2:"58";s:8:"newValue";s:2:"58";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004580189499, 'marco.eilers'),
(19388, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:4:"5652";s:8:"newValue";s:4:"5652";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004580598080, 'marco.eilers'),
(19389, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004580980227, 'marco.eilers'),
(19390, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:4:"5652";s:8:"newValue";s:4:"5652";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004581286297, 'marco.eilers'),
(19391, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5009";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004581435547, 'marco.eilers'),
(19392, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:2:"58";s:8:"newValue";s:2:"58";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004581588507, 'marco.eilers'),
(19393, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004581737492, 'marco.eilers'),
(19394, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:4:"5652";s:8:"newValue";s:4:"5652";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004582460860, 'marco.eilers'),
(19395, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5009";s:8:"newValue";s:4:"5009";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004582647776, 'marco.eilers'),
(19396, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:2:"58";s:8:"newValue";s:2:"58";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004582835747, 'marco.eilers'),
(19397, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004583023837, 'marco.eilers'),
(19398, 'a:1:{i:0;a:1:{s:7:"Version";a:2:{s:8:"oldValue";s:3:"1.0";s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004583211164, 'marco.eilers'),
(19399, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:18:"New ChiRequirement";s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004584093342, 'marco.eilers'),
(19400, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5009";s:8:"newValue";s:4:"5009";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004585583381, 'marco.eilers'),
(19401, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:2:"58";s:8:"newValue";s:2:"58";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004585992353, 'marco.eilers'),
(19402, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004586400606, 'marco.eilers'),
(19403, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:4:"5652";s:8:"newValue";s:4:"5652";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004586808950, 'marco.eilers'),
(19404, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:2:"58";s:8:"newValue";s:2:"58";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004614664634, 'marco.eilers'),
(19405, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5009";s:8:"newValue";s:4:"5009";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004615071432, 'marco.eilers'),
(19406, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:4:"5652";s:8:"newValue";s:4:"5652";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004615480974, 'marco.eilers'),
(19407, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004615888674, 'marco.eilers'),
(19408, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5009";s:8:"newValue";s:4:"5009";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004618066538, 'marco.eilers'),
(19409, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:2:"58";s:8:"newValue";s:2:"58";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004618475073, 'marco.eilers'),
(19410, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004618880397, 'marco.eilers'),
(19411, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:4:"5652";s:8:"newValue";s:4:"5652";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004619472599, 'marco.eilers'),
(19412, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5009";s:8:"newValue";s:4:"5009";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004619631199, 'marco.eilers'),
(19413, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:4:"5652";s:8:"newValue";s:4:"5652";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004619793780, 'marco.eilers'),
(19414, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004619945061, 'marco.eilers'),
(19415, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:2:"58";s:8:"newValue";s:2:"58";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004620101629, 'marco.eilers'),
(19416, 'a:1:{i:0;a:1:{s:11:"Proofreader";a:2:{s:8:"oldValue";s:4:"5652";s:8:"newValue";s:4:"5652";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004620257147, 'marco.eilers'),
(19417, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5009";s:8:"newValue";s:4:"5009";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004620406258, 'marco.eilers'),
(19418, 'a:1:{i:0;a:1:{s:7:"reqType";a:2:{s:8:"oldValue";s:4:"5013";s:8:"newValue";s:4:"5013";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004620554777, 'marco.eilers'),
(19419, 'a:1:{i:0;a:1:{s:6:"Author";a:2:{s:8:"oldValue";s:2:"58";s:8:"newValue";s:2:"58";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004620703230, 'marco.eilers'),
(19420, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:54:""&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; fgfgdsfgsgf<br>";}}}', 0, 'changeProperty', 'ChiRequirement:19368', NULL, 1236004622432997, 'marco.eilers'),
(19427, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New ChiIssue";}}}', 0, 'changeProperty', 'ChiIssue:19425', NULL, 1236004635958688, 'marco.eilers'),
(19430, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5177";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5227";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19426', NULL, 1236004636895264, 'marco.eilers'),
(19431, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5177";s:8:"newValue";s:4:"5097";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5227";s:8:"newValue";s:4:"5193";}}}', 0, 'changeProperty', 'Figure:19426', NULL, 1236004640451987, 'marco.eilers'),
(19435, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, 'changeProperty', 'ChiRequirement:19433', NULL, 1236004650901474, 'marco.eilers'),
(19438, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5717";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5262";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19434', NULL, 1236004651235864, 'marco.eilers'),
(19441, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiGoal";}}}', 0, 'changeProperty', 'ChiGoal:19439', NULL, 1236004656644053, 'marco.eilers'),
(19444, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5699";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5071";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19440', NULL, 1236004656983164, 'marco.eilers'),
(19447, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5223";s:8:"newValue";s:4:"5190";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5090";s:8:"newValue";s:4:"5033";}}}', 0, 'changeProperty', 'Figure:19298', NULL, 1236004657695985, 'marco.eilers'),
(19450, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5302";s:8:"newValue";s:4:"5303";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5232";s:8:"newValue";s:4:"5313";}}}', 0, 'changeProperty', 'Figure:19292', NULL, 1236004675456826, 'marco.eilers'),
(19453, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:14:"New ChiFeature";}}}', 0, 'changeProperty', 'ChiFeature:19451', NULL, 1236004679336052, 'marco.eilers'),
(19456, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5638";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5365";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19452', NULL, 1236004679681659, 'marco.eilers'),
(19458, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5638";s:8:"newValue";s:4:"5464";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5365";s:8:"newValue";s:4:"5469";}}}', 0, 'changeProperty', 'Figure:19452', NULL, 1236004687921925, 'marco.eilers'),
(19459, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:14:"New ChiFeature";s:8:"newValue";s:20:"ich bin illegal hier";}}}', 0, 'changeProperty', 'ChiFeature:19451', NULL, 1236004694951280, 'marco.eilers'),
(19462, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiNode";}}}', 0, 'changeProperty', 'ChiNode:19460', NULL, 1236004724061239, 'marco.eilers'),
(19465, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5116";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5373";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:19461', NULL, 1236004724400396, 'marco.eilers'),
(19468, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiView";}}}', 0, 'changeProperty', 'ChiView:19466', NULL, 1236004728603275, 'marco.eilers'),
(19471, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5086";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5507";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:19467', NULL, 1236004728923959, 'marco.eilers'),
(19474, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5307";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5533";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:19473', NULL, 1236004733551534, 'marco.eilers'),
(19477, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ChiController";}}}', 0, 'changeProperty', 'ChiController:19472', NULL, 1236004734059843, 'marco.eilers'),
(19480, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ChiController";}}}', 0, 'changeProperty', 'ChiController:19478', NULL, 1236004769993181, 'marco.eilers'),
(19483, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5679";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5394";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:19479', NULL, 1236004770320590, 'marco.eilers'),
(19484, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5679";s:8:"newValue";s:4:"5676";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5394";s:8:"newValue";s:4:"5420";}}}', 0, 'changeProperty', 'Figure:19479', NULL, 1236004772060612, 'marco.eilers'),
(19487, 'a:1:{i:0;a:1:{s:13:"display_value";a:2:{s:8:"oldValue";s:4:"name";s:8:"newValue";s:5:"45645";}}}', 0, 'changeProperty', 'ChiNode:19460', NULL, 1236004871652807, 'marco.eilers'),
(19488, 'a:1:{i:0;a:1:{s:12:"parent_order";a:2:{s:8:"oldValue";N;s:8:"newValue";s:6:"456456";}}}', 0, 'changeProperty', 'ChiNode:19460', NULL, 1236004872585942, 'marco.eilers'),
(19489, 'a:1:{i:0;a:1:{s:11:"child_order";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4545";}}}', 0, 'changeProperty', 'ChiNode:19460', NULL, 1236004873853880, 'marco.eilers'),
(19490, 'a:1:{i:0;a:1:{s:7:"pk_name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:6:"456456";}}}', 0, 'changeProperty', 'ChiNode:19460', NULL, 1236004875363583, 'marco.eilers'),
(19491, 'a:1:{i:0;a:1:{s:7:"orderby";a:2:{s:8:"oldValue";s:4:"none";s:8:"newValue";s:6:"456456";}}}', 0, 'changeProperty', 'ChiNode:19460', NULL, 1236004879272796, 'marco.eilers'),
(19492, 'a:1:{i:0;a:1:{s:10:"initparams";a:2:{s:8:"oldValue";s:8:"database";s:8:"newValue";s:5:"45645";}}}', 0, 'changeProperty', 'ChiNode:19460', NULL, 1236004891540484, 'marco.eilers'),
(19493, 'a:1:{i:0;a:1:{s:10:"table_name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4545";}}}', 0, 'changeProperty', 'ChiNode:19460', NULL, 1236004893372154, 'marco.eilers'),
(19496, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5086";s:8:"newValue";s:4:"5087";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5507";s:8:"newValue";s:4:"5507";}}}', 0, 'changeProperty', 'Figure:19467', NULL, 1236004901557589, 'marco.eilers'),
(19501, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:22:"New ChiBusinessPartner";}}}', 0, 'changeProperty', 'ChiBusinessPartner:19499', NULL, 1236004985752389, 'marco.eilers'),
(19502, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5257";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5706";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"26";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"52";}}}', 0, 'changeProperty', 'Figure:19500', NULL, 1236004985896409, 'marco.eilers'),
(19507, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:26:"New ChiBusinessUseCaseCore";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:19505', NULL, 1236004990756357, 'marco.eilers'),
(19508, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5525";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5713";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:19506', NULL, 1236004990911247, 'marco.eilers'),
(19530, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:15:"New ActivitySet";}}}', 0, 'changeProperty', 'ActivitySet:19528', NULL, 1236010518282916, 'marco.eilers'),
(19533, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5186";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5166";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}}', 0, 'changeProperty', 'Figure:19532', NULL, 1236010525124213, 'marco.eilers'),
(19536, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:19531', NULL, 1236010525596451, 'marco.eilers'),
(19541, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:19539', NULL, 1236010539849556, 'marco.eilers'),
(19542, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5509";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5155";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"60";}}}', 0, 'changeProperty', 'Figure:19540', NULL, 1236010540259583, 'marco.eilers'),
(19547, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, 'changeProperty', 'ActivityInitial:19545', NULL, 1236010541912181, 'marco.eilers'),
(19550, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5611";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5377";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}}', 0, 'changeProperty', 'Figure:19546', NULL, 1236010542254759, 'marco.eilers'),
(19553, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:19551', NULL, 1236010582323738, 'marco.eilers'),
(19556, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5109";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5294";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}}', 0, 'changeProperty', 'Figure:19552', NULL, 1236010583198465, 'marco.eilers'),
(19561, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5465";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5409";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}}', 0, 'changeProperty', 'Figure:19558', NULL, 1236010585087467, 'marco.eilers'),
(19562, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, 'changeProperty', 'ActivityInitial:19557', NULL, 1236010585391740, 'marco.eilers'),
(19569, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:16:"New ActivitySend";}}}', 0, 'changeProperty', 'ActivitySend:19567', NULL, 1236010709499673, 'marco.eilers'),
(19570, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5246";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5484";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"45";}}}', 0, 'changeProperty', 'Figure:19568', NULL, 1236010709648863, 'marco.eilers'),
(19575, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:19:"New ActivityReceive";}}}', 0, 'changeProperty', 'ActivityReceive:19573', NULL, 1236010713326484, 'marco.eilers'),
(19576, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5342";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5053";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"75";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"45";}}}', 0, 'changeProperty', 'Figure:19574', NULL, 1236010713471867, 'marco.eilers'),
(19579, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5109";s:8:"newValue";s:4:"5117";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5294";s:8:"newValue";s:4:"5284";}}}', 0, 'changeProperty', 'Figure:19552', NULL, 1236010783011012, 'marco.eilers'),
(19580, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5465";s:8:"newValue";s:4:"5503";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5409";s:8:"newValue";s:4:"5424";}}}', 0, 'changeProperty', 'Figure:19558', NULL, 1236010783687437, 'marco.eilers'),
(19581, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5509";s:8:"newValue";s:4:"5379";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5155";s:8:"newValue";s:4:"5274";}}}', 0, 'changeProperty', 'Figure:19540', NULL, 1236010784083186, 'marco.eilers'),
(19582, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5186";s:8:"newValue";s:4:"5410";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5166";s:8:"newValue";s:4:"5087";}}}', 0, 'changeProperty', 'Figure:19532', NULL, 1236010784330084, 'marco.eilers'),
(19583, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5246";s:8:"newValue";s:4:"5251";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5484";s:8:"newValue";s:4:"5409";}}}', 0, 'changeProperty', 'Figure:19568', NULL, 1236010784577119, 'marco.eilers'),
(19584, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5342";s:8:"newValue";s:4:"5227";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5053";s:8:"newValue";s:4:"5239";}}}', 0, 'changeProperty', 'Figure:19574', NULL, 1236010784824088, 'marco.eilers'),
(19585, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5611";s:8:"newValue";s:4:"5578";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5377";s:8:"newValue";s:4:"5217";}}}', 0, 'changeProperty', 'Figure:19546', NULL, 1236010785071785, 'marco.eilers'),
(19611, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5385";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5323";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19610', NULL, 1236010951424415, 'marco.eilers'),
(19615, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5385";s:8:"newValue";s:4:"5264";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5323";s:8:"newValue";s:4:"5286";}}}', 0, 'changeProperty', 'Figure:19610', NULL, 1236010954827764, 'marco.eilers'),
(19617, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5264";s:8:"newValue";s:4:"5250";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5286";s:8:"newValue";s:4:"5300";}}}', 0, 'changeProperty', 'Figure:19610', NULL, 1236010962441018, 'marco.eilers'),
(19621, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5716";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5305";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19620', NULL, 1236010979295634, 'marco.eilers'),
(19647, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5250";s:8:"newValue";s:4:"5253";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5300";s:8:"newValue";s:4:"5278";}}}', 0, 'changeProperty', 'Figure:19610', NULL, 1236011205944138, 'marco.eilers'),
(19648, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5253";s:8:"newValue";s:4:"5198";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5278";s:8:"newValue";s:4:"5278";}}}', 0, 'changeProperty', 'Figure:19610', NULL, 1236011208987045, 'marco.eilers'),
(19649, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5198";s:8:"newValue";s:4:"5230";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5278";s:8:"newValue";s:4:"5278";}}}', 0, 'changeProperty', 'Figure:19610', NULL, 1236011210375078, 'marco.eilers'),
(19675, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5107";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5117";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:19674', NULL, 1236012099761431, 'marco.eilers'),
(19678, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:26:"New ChiBusinessUseCaseCore";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:19673', NULL, 1236012100272838, 'marco.eilers'),
(19679, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5107";s:8:"newValue";s:4:"5061";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5117";s:8:"newValue";s:4:"5140";}}}', 0, 'changeProperty', 'Figure:19674', NULL, 1236012105974849, 'marco.eilers'),
(19680, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5061";s:8:"newValue";s:4:"4989";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5140";s:8:"newValue";s:4:"5129";}}}', 0, 'changeProperty', 'Figure:19674', NULL, 1236012108927401, 'marco.eilers'),
(19681, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4989";s:8:"newValue";s:4:"4989";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5129";s:8:"newValue";s:4:"5136";}}}', 0, 'changeProperty', 'Figure:19674', NULL, 1236012110085698, 'marco.eilers'),
(19682, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4989";s:8:"newValue";s:4:"5017";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5136";s:8:"newValue";s:4:"5136";}}}', 0, 'changeProperty', 'Figure:19674', NULL, 1236012111326746, 'marco.eilers'),
(19685, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:22:"New ChiBusinessPartner";}}}', 0, 'changeProperty', 'ChiBusinessPartner:19683', NULL, 1236012116087954, 'marco.eilers'),
(19688, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5178";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5148";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"26";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"52";}}}', 0, 'changeProperty', 'Figure:19684', NULL, 1236012116431297, 'marco.eilers'),
(19689, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5178";s:8:"newValue";s:4:"5212";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5148";s:8:"newValue";s:4:"5172";}}}', 0, 'changeProperty', 'Figure:19684', NULL, 1236012118820628, 'marco.eilers'),
(19690, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5212";s:8:"newValue";s:4:"5213";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5172";s:8:"newValue";s:4:"5121";}}}', 0, 'changeProperty', 'Figure:19684', NULL, 1236012120739441, 'marco.eilers'),
(19691, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5213";s:8:"newValue";s:4:"5247";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5121";s:8:"newValue";s:4:"5078";}}}', 0, 'changeProperty', 'Figure:19684', NULL, 1236012122937268, 'marco.eilers'),
(19694, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5017";s:8:"newValue";s:4:"5055";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5136";s:8:"newValue";s:4:"5085";}}}', 0, 'changeProperty', 'Figure:19674', NULL, 1236012124572191, 'marco.eilers'),
(19697, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:22:"New ChiBusinessUseCase";}}}', 0, 'changeProperty', 'ChiBusinessUseCase:19695', NULL, 1236012131156566, 'marco.eilers'),
(19698, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5129";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5271";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"117";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"78";}}}', 0, 'changeProperty', 'Figure:19696', NULL, 1236012131313270, 'marco.eilers'),
(19701, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5129";s:8:"newValue";s:4:"5130";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5271";s:8:"newValue";s:4:"5225";}}}', 0, 'changeProperty', 'Figure:19696', NULL, 1236012132714555, 'marco.eilers'),
(19702, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5130";s:8:"newValue";s:4:"5110";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5225";s:8:"newValue";s:4:"5225";}}}', 0, 'changeProperty', 'Figure:19696', NULL, 1236012174060385, 'marco.eilers'),
(19703, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5110";s:8:"newValue";s:4:"5078";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5225";s:8:"newValue";s:4:"5287";}}}', 0, 'changeProperty', 'Figure:19696', NULL, 1236012175368193, 'marco.eilers'),
(19704, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5078";s:8:"newValue";s:4:"5064";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5287";s:8:"newValue";s:4:"5308";}}}', 0, 'changeProperty', 'Figure:19696', NULL, 1236012176278354, 'marco.eilers'),
(19711, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5116";s:8:"newValue";s:4:"4908";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5373";s:8:"newValue";s:4:"5430";}}}', 0, 'changeProperty', 'Figure:19461', NULL, 1236012656927284, 'marco.eilers'),
(19714, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5064";s:8:"newValue";s:4:"4827";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5308";s:8:"newValue";s:4:"5263";}}}', 0, 'changeProperty', 'Figure:19696', NULL, 1236012672791765, 'marco.eilers'),
(19715, 'a:1:{i:0;a:1:{s:12:"Stakeholders";a:2:{s:8:"oldValue";N;s:8:"newValue";s:1:" ";}}}', 0, 'changeProperty', 'ChiBusinessUseCase:19695', NULL, 1236012685382341, 'marco.eilers'),
(19716, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:105:" <span class="autocomplete-undefined">essen</span> <span class="autocomplete-undefined">essen</span>?";}}}', 0, 'changeProperty', 'ChiBusinessUseCase:19695', NULL, 1236013214697260, 'marco.eilers'),
(19718, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:15:"New ActivitySet";}}}', 0, 'changeProperty', 'ActivitySet:19717', NULL, 1236014452194426, 'marco.eilers'),
(19743, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5230";s:8:"newValue";s:4:"4821";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5278";s:8:"newValue";s:4:"5194";}}}', 0, 'changeProperty', 'Figure:19610', NULL, 1236014557838944, 'marco.eilers'),
(19744, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5472";s:8:"newValue";s:4:"5150";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5132";s:8:"newValue";s:4:"5174";}}}', 0, 'changeProperty', 'Figure:19369', NULL, 1236014558588724, 'marco.eilers'),
(19745, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5190";s:8:"newValue";s:4:"5173";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5033";s:8:"newValue";s:4:"4968";}}}', 0, 'changeProperty', 'Figure:19298', NULL, 1236014558908055, 'marco.eilers'),
(19746, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5716";s:8:"newValue";s:4:"5894";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5305";s:8:"newValue";s:4:"5080";}}}', 0, 'changeProperty', 'Figure:19620', NULL, 1236014559161336, 'marco.eilers'),
(19747, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5097";s:8:"newValue";s:4:"4920";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5193";s:8:"newValue";s:4:"5023";}}}', 0, 'changeProperty', 'Figure:19426', NULL, 1236014559416559, 'marco.eilers'),
(19748, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5699";s:8:"newValue";s:4:"6222";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5071";s:8:"newValue";s:4:"4988";}}}', 0, 'changeProperty', 'Figure:19440', NULL, 1236014559665772, 'marco.eilers'),
(19749, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5464";s:8:"newValue";s:4:"5549";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5469";s:8:"newValue";s:4:"5167";}}}', 0, 'changeProperty', 'Figure:19452', NULL, 1236014559915495, 'marco.eilers'),
(19750, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4908";s:8:"newValue";s:4:"5075";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5430";s:8:"newValue";s:4:"5502";}}}', 0, 'changeProperty', 'Figure:19461', NULL, 1236014560165531, 'marco.eilers'),
(19751, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5087";s:8:"newValue";s:4:"5138";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5507";s:8:"newValue";s:4:"5783";}}}', 0, 'changeProperty', 'Figure:19467', NULL, 1236014560414856, 'marco.eilers'),
(19752, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5307";s:8:"newValue";s:4:"5259";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5533";s:8:"newValue";s:4:"6016";}}}', 0, 'changeProperty', 'Figure:19473', NULL, 1236014560664496, 'marco.eilers'),
(19753, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5055";s:8:"newValue";s:4:"5345";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5085";s:8:"newValue";s:4:"5259";}}}', 0, 'changeProperty', 'Figure:19674', NULL, 1236014560928071, 'marco.eilers'),
(19754, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5676";s:8:"newValue";s:4:"5410";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5420";s:8:"newValue";s:4:"5806";}}}', 0, 'changeProperty', 'Figure:19479', NULL, 1236014561173154, 'marco.eilers'),
(19755, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5525";s:8:"newValue";s:4:"5401";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5713";s:8:"newValue";s:4:"5415";}}}', 0, 'changeProperty', 'Figure:19506', NULL, 1236014561428317, 'marco.eilers'),
(19756, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4827";s:8:"newValue";s:4:"4511";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5263";s:8:"newValue";s:4:"5159";}}}', 0, 'changeProperty', 'Figure:19696', NULL, 1236014561672984, 'marco.eilers'),
(19757, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5257";s:8:"newValue";s:4:"5483";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5706";s:8:"newValue";s:4:"5592";}}}', 0, 'changeProperty', 'Figure:19500', NULL, 1236014561924222, 'marco.eilers'),
(19758, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5247";s:8:"newValue";s:4:"5399";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5078";s:8:"newValue";s:4:"5083";}}}', 0, 'changeProperty', 'Figure:19684', NULL, 1236014562173137, 'marco.eilers'),
(19760, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Diagram";}}}', 0, 'changeProperty', 'Diagram:19759', NULL, 1236014569896791, 'marco.eilers'),
(19765, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New ChiIssue";}}}', 0, 'changeProperty', 'ChiIssue:19763', NULL, 1236014578493146, 'marco.eilers'),
(19766, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5412";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5204";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:19764', NULL, 1236014578668880, 'marco.eilers'),
(19769, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5412";s:8:"newValue";s:4:"4840";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5204";s:8:"newValue";s:4:"4965";}}}', 0, 'changeProperty', 'Figure:19764', NULL, 1236014583656542, 'marco.eilers'),
(19774, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:4:"5530";s:8:"newValue";N;}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014636274385, 'marco.eilers'),
(19775, 'a:1:{i:0;a:1:{s:10:"Value_Name";a:2:{s:8:"oldValue";s:2:"80";s:8:"newValue";N;}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014636274385, 'marco.eilers'),
(19776, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";s:2:"80";s:8:"newValue";N;}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014636274385, 'marco.eilers'),
(19777, 'a:1:{i:0;a:1:{s:8:"Priority";a:2:{s:8:"oldValue";s:2:"80";s:8:"newValue";N;}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014636274385, 'marco.eilers'),
(19778, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";s:2:"80";s:8:"newValue";N;}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014636274385, 'marco.eilers'),
(19779, 'a:1:{i:0;a:1:{s:7:"Version";a:2:{s:8:"oldValue";s:2:"80";s:8:"newValue";N;}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014636274385, 'marco.eilers'),
(19780, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:2:"80";s:8:"newValue";N;}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014636274385, 'marco.eilers'),
(19781, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:8:"&#160;80";s:8:"newValue";s:0:"";}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014636274385, 'marco.eilers'),
(19782, 'a:1:{i:0;a:1:{s:8:"modified";a:2:{s:8:"oldValue";s:19:"2009-03-02 15:34:38";s:8:"newValue";s:19:"2009-03-02 18:23:56";}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014636274385, 'marco.eilers'),
(19787, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5530";}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014677827901, 'marco.eilers'),
(19788, 'a:1:{i:0;a:1:{s:10:"Value_Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014677827901, 'marco.eilers'),
(19789, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014677827901, 'marco.eilers'),
(19790, 'a:1:{i:0;a:1:{s:8:"Priority";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014677827901, 'marco.eilers'),
(19791, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014677827901, 'marco.eilers'),
(19792, 'a:1:{i:0;a:1:{s:7:"Version";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014677827901, 'marco.eilers'),
(19793, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"80";}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014677827901, 'marco.eilers'),
(19794, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:0:"";}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014677827901, 'marco.eilers'),
(19795, 'a:1:{i:0;a:1:{s:8:"modified";a:2:{s:8:"oldValue";s:19:"2009-03-02 18:23:56";s:8:"newValue";s:19:"2009-03-02 18:24:38";}}}', 0, 'changeProperty', 'ChiGoal:19297', 'tbd', 1236014677827901, 'marco.eilers'),
(19918, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Diagram";}}}', 0, 'changeProperty', 'Diagram:19917', NULL, 1236075012688660, 'andreas.herdt'),
(19922, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiNode";}}}', 0, 'changeProperty', 'ChiNode:19920', NULL, 1236075028750686, 'andreas.herdt'),
(19925, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5184";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5219";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:19921', NULL, 1236075029601267, 'andreas.herdt'),
(19928, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiNode";}}}', 0, 'changeProperty', 'ChiNode:19926', NULL, 1236075051441523, 'andreas.herdt'),
(19929, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5533";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5346";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:19927', NULL, 1236075051579664, 'andreas.herdt'),
(19948, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ChiController";}}}', 0, 'changeProperty', 'ChiController:19946', NULL, 1236077392869202, 'andreas.herdt'),
(19949, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5331";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5470";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:19947', NULL, 1236077393229783, 'andreas.herdt'),
(19952, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5331";s:8:"newValue";s:4:"5243";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5470";s:8:"newValue";s:4:"5446";}}}', 0, 'changeProperty', 'Figure:19947', NULL, 1236077399527296, 'andreas.herdt'),
(19957, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiView";}}}', 0, 'changeProperty', 'ChiView:19955', NULL, 1236077516575440, 'andreas.herdt');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES
(19960, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5612";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5581";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:19956', NULL, 1236077516921728, 'andreas.herdt'),
(19961, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5612";s:8:"newValue";s:4:"5476";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5581";s:8:"newValue";s:4:"5034";}}}', 0, 'changeProperty', 'Figure:19956', NULL, 1236077521821522, 'andreas.herdt'),
(19962, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5476";s:8:"newValue";s:4:"5566";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5034";s:8:"newValue";s:4:"5583";}}}', 0, 'changeProperty', 'Figure:19956', NULL, 1236077546019189, 'andreas.herdt'),
(20402, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiNode";}}}', 0, 'changeProperty', 'ChiNode:20400', NULL, 1236083795607624, 'andreas.herdt'),
(20405, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5093";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5500";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:20401', NULL, 1236083795934101, 'andreas.herdt'),
(20407, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New ChiValue";}}}', 0, 'changeProperty', 'ChiValue:20406', NULL, 1236083818652691, 'andreas.herdt'),
(20408, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:2:"96";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"95";s:8:"newValue";s:2:"81";}}}', 0, 'changeProperty', 'Figure:20401', NULL, 1236083818879845, 'andreas.herdt'),
(20412, 'a:1:{i:0;a:1:{s:11:"column_name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"t1";}}}', 0, 'changeProperty', 'ChiValue:20406', NULL, 1236083858030566, 'andreas.herdt'),
(20413, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:12:"New ChiValue";s:8:"newValue";s:6:"test 1";}}}', 0, 'changeProperty', 'ChiValue:20406', NULL, 1236083872789251, 'andreas.herdt'),
(20415, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New ChiValue";}}}', 0, 'changeProperty', 'ChiValue:20414', NULL, 1236083874976684, 'andreas.herdt'),
(20419, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:3:"150";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"81";s:8:"newValue";s:2:"97";}}}', 0, 'changeProperty', 'Figure:20401', NULL, 1236083876220343, 'andreas.herdt'),
(20420, 'a:1:{i:0;a:1:{s:12:"db_data_type";a:2:{s:8:"oldValue";s:12:"VARCHAR(255)";s:8:"newValue";s:3:"INT";}}}', 0, 'changeProperty', 'ChiValue:20414', NULL, 1236083892199342, 'andreas.herdt'),
(20421, 'a:1:{i:0;a:1:{s:11:"column_name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"t2";}}}', 0, 'changeProperty', 'ChiValue:20414', NULL, 1236083906921023, 'andreas.herdt'),
(20422, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:12:"New ChiValue";s:8:"newValue";s:6:"test 2";}}}', 0, 'changeProperty', 'ChiValue:20414', NULL, 1236083912911361, 'andreas.herdt'),
(20425, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5093";s:8:"newValue";s:4:"5057";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5500";s:8:"newValue";s:4:"5410";}}}', 0, 'changeProperty', 'Figure:20401', NULL, 1236083916210944, 'andreas.herdt'),
(20488, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5496";s:8:"newValue";s:4:"5298";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5213";s:8:"newValue";s:4:"5157";}}}', 0, 'changeProperty', 'Figure:18899', NULL, 1236179085621611, 'pgiuseppe'),
(20495, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5326";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5303";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"117";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"78";}}}', 0, 'changeProperty', 'Figure:20492', NULL, 1236179103991030, 'pgiuseppe'),
(20496, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5326";s:8:"newValue";s:4:"5254";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5303";s:8:"newValue";s:4:"5265";}}}', 0, 'changeProperty', 'Figure:20492', NULL, 1236179106717636, 'pgiuseppe'),
(20501, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5536";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5166";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:20498', NULL, 1236179118479922, 'pgiuseppe'),
(20506, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5678";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5368";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:20503', NULL, 1236179128265927, 'pgiuseppe'),
(20511, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5614";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5480";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:20508', NULL, 1236179131914311, 'pgiuseppe'),
(20516, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5841";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5487";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:20513', NULL, 1236179135579028, 'pgiuseppe'),
(20519, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5678";s:8:"newValue";s:4:"5491";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5368";s:8:"newValue";s:4:"5273";}}}', 0, 'changeProperty', 'Figure:20503', NULL, 1236179137771451, 'pgiuseppe'),
(20522, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5614";s:8:"newValue";s:4:"5503";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5480";s:8:"newValue";s:4:"5395";}}}', 0, 'changeProperty', 'Figure:20508', NULL, 1236179139042050, 'pgiuseppe'),
(20525, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5841";s:8:"newValue";s:4:"5520";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5487";s:8:"newValue";s:4:"5512";}}}', 0, 'changeProperty', 'Figure:20513', NULL, 1236179140473642, 'pgiuseppe'),
(20530, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5741";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5163";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:20527', NULL, 1236179145196959, 'pgiuseppe'),
(20535, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5756";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5280";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:20532', NULL, 1236179147405871, 'pgiuseppe'),
(20540, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5748";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5395";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:20537', NULL, 1236179150195167, 'pgiuseppe'),
(20545, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5784";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5523";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:20542', NULL, 1236179152360823, 'pgiuseppe'),
(20548, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5262";s:8:"newValue";s:4:"5246";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5387";s:8:"newValue";s:4:"5387";}}}', 0, 'changeProperty', 'Figure:19128', NULL, 1236179157410954, 'pgiuseppe'),
(20551, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5254";s:8:"newValue";s:4:"5246";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5265";s:8:"newValue";s:4:"5265";}}}', 0, 'changeProperty', 'Figure:20492', NULL, 1236179158468367, 'pgiuseppe'),
(20554, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5298";s:8:"newValue";s:4:"5246";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5157";s:8:"newValue";s:4:"5135";}}}', 0, 'changeProperty', 'Figure:18899', NULL, 1236179160844051, 'pgiuseppe'),
(20557, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5536";s:8:"newValue";s:4:"5482";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5166";s:8:"newValue";s:4:"5135";}}}', 0, 'changeProperty', 'Figure:20498', NULL, 1236179166079131, 'pgiuseppe'),
(20560, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5491";s:8:"newValue";s:4:"5482";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5273";s:8:"newValue";s:4:"5273";}}}', 0, 'changeProperty', 'Figure:20503', NULL, 1236179167167834, 'pgiuseppe'),
(20563, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5503";s:8:"newValue";s:4:"5482";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5395";s:8:"newValue";s:4:"5395";}}}', 0, 'changeProperty', 'Figure:20508', NULL, 1236179167780540, 'pgiuseppe'),
(20566, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5520";s:8:"newValue";s:4:"5482";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5512";s:8:"newValue";s:4:"5505";}}}', 0, 'changeProperty', 'Figure:20513', NULL, 1236179170998133, 'pgiuseppe'),
(20569, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5784";s:8:"newValue";s:4:"5756";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5523";s:8:"newValue";s:4:"5513";}}}', 0, 'changeProperty', 'Figure:20542', NULL, 1236179173405026, 'pgiuseppe'),
(20572, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5748";s:8:"newValue";s:4:"5741";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5395";s:8:"newValue";s:4:"5395";}}}', 0, 'changeProperty', 'Figure:20537', NULL, 1236179175336766, 'pgiuseppe'),
(20575, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5756";s:8:"newValue";s:4:"5741";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5280";s:8:"newValue";s:4:"5273";}}}', 0, 'changeProperty', 'Figure:20532', NULL, 1236179178806039, 'pgiuseppe'),
(20578, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5741";s:8:"newValue";s:4:"5741";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5163";s:8:"newValue";s:4:"5140";}}}', 0, 'changeProperty', 'Figure:20527', NULL, 1236179180820201, 'pgiuseppe'),
(20601, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5119";s:8:"newValue";s:4:"5056";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5186";s:8:"newValue";s:4:"5314";}}}', 0, 'changeProperty', 'Figure:9733', NULL, 1236179204747535, 'pgiuseppe'),
(20616, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5680";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"6101";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"52";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:20615', NULL, 1236179264239959, 'pgiuseppe'),
(20630, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New Diagram";s:8:"newValue";s:20:"Use cases candidates";}}}', 0, 'changeProperty', 'Diagram:18654', NULL, 1236179407512672, 'pgiuseppe'),
(20633, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5246";s:8:"newValue";s:4:"5239";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5135";s:8:"newValue";s:4:"5046";}}}', 0, 'changeProperty', 'Figure:18899', NULL, 1236179421254073, 'pgiuseppe'),
(20636, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5482";s:8:"newValue";s:4:"5451";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5135";s:8:"newValue";s:4:"5046";}}}', 0, 'changeProperty', 'Figure:20498', NULL, 1236179422838206, 'pgiuseppe'),
(20639, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5246";s:8:"newValue";s:4:"5246";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5265";s:8:"newValue";s:4:"5191";}}}', 0, 'changeProperty', 'Figure:20492', NULL, 1236179423932752, 'pgiuseppe'),
(20642, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5482";s:8:"newValue";s:4:"5445";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5273";s:8:"newValue";s:4:"5191";}}}', 0, 'changeProperty', 'Figure:20503', NULL, 1236179426013110, 'pgiuseppe'),
(20650, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5525";s:8:"newValue";s:4:"5378";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5296";s:8:"newValue";s:4:"5064";}}}', 0, 'changeProperty', 'Figure:9672', NULL, 1236179463449977, 'pgiuseppe'),
(20653, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5426";s:8:"newValue";s:4:"5506";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5285";s:8:"newValue";s:4:"5064";}}}', 0, 'changeProperty', 'Figure:9473', NULL, 1236179464447753, 'pgiuseppe'),
(20661, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4890";s:8:"newValue";s:4:"4890";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4990";s:8:"newValue";s:4:"4989";}}}', 0, 'changeProperty', 'Figure:10268', NULL, 1236179519737286, 'pgiuseppe'),
(20668, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4794";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4892";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:20665', NULL, 1236179553830371, 'pgiuseppe'),
(20669, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4794";s:8:"newValue";s:4:"4750";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4892";s:8:"newValue";s:4:"4913";}}}', 0, 'changeProperty', 'Figure:20665', NULL, 1236179554718852, 'pgiuseppe'),
(20670, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4750";s:8:"newValue";s:4:"4672";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4913";s:8:"newValue";s:4:"5012";}}}', 0, 'changeProperty', 'Figure:20665', NULL, 1236179562802018, 'pgiuseppe'),
(20673, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4890";s:8:"newValue";s:4:"4903";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4989";s:8:"newValue";s:4:"5054";}}}', 0, 'changeProperty', 'Figure:10268', NULL, 1236179566108862, 'pgiuseppe'),
(20676, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4672";s:8:"newValue";s:4:"4691";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5012";s:8:"newValue";s:4:"5065";}}}', 0, 'changeProperty', 'Figure:20665', NULL, 1236179567482249, 'pgiuseppe'),
(20679, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5217";s:8:"newValue";s:4:"5220";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5099";s:8:"newValue";s:4:"5095";}}}', 0, 'changeProperty', 'Figure:10182', NULL, 1236179574892701, 'pgiuseppe'),
(20692, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5218";s:8:"newValue";s:4:"5252";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4962";s:8:"newValue";s:4:"4909";}}}', 0, 'changeProperty', 'Figure:10192', NULL, 1236179648191136, 'pgiuseppe'),
(20695, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236179946934996, 'pgiuseppe'),
(20696, 'a:1:{i:0;a:1:{s:5:"Scope";a:2:{s:8:"oldValue";N;s:8:"newValue";s:6:"SVNCRM";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236179955476335, 'pgiuseppe'),
(20697, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236179956001028, 'pgiuseppe'),
(20698, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236179961701280, 'pgiuseppe'),
(20699, 'a:1:{i:0;a:1:{s:12:"Stakeholders";a:2:{s:8:"oldValue";N;s:8:"newValue";s:10:"Management";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236179969720640, 'pgiuseppe'),
(20700, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236180270432581, 'pgiuseppe'),
(20701, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236180274126410, 'pgiuseppe'),
(20702, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236180278364588, 'pgiuseppe'),
(20703, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236180280512115, 'pgiuseppe'),
(20704, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236180285306133, 'pgiuseppe'),
(20705, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236180285822217, 'pgiuseppe'),
(20708, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3280:"<ul><li>&nbsp;<link rel="File-List" href="file:///C:%5CDOCUME%7E1%5CADMINI%7E1%5CLOCALS%7E1%5CTemp%5Cmsohtml1%5C01%5Cclip_filelist.xml"><span lang="EN-CA">Field Worker plans ?Silver?\nTrouble Calls to be processed at least 2 days before expiration of reaction\ntime.</span></li><li><span lang="EN-CA">He checks if it is meaningful to\ncheck up all Transmitters in the faulty Transmitter?s Subdomain. If so, plan\nmaintenance of whole Subdomain on that day.</span></li><li><span lang="EN-CA">Check if there are still any\nsingle postponed or open tasks to be planned and organize them in a meaningful\nway.</span></li><li><span style="font-size: 12pt; line-height: 150%; font-family: Arial;">For the remaining days\nplan maintenance of Transmitters of a whole Subdomain.</span></li></ul><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><meta name="ProgId" content="Word.Document"><meta name="Generator" content="Microsoft Word 11"><meta name="Originator" content="Microsoft Word 11"><!--[if gte mso 9]><xml>\n <w:WordDocument>\n  <w:View>Normal</w:View>\n  <w:Zoom>0</w:Zoom>\n  <w:HyphenationZone>21</w:HyphenationZone>\n  <w:PunctuationKerning/>\n  <w:ValidateAgainstSchemas/>\n  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>\n  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>\n  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>\n  <w:Compatibility>\n   <w:BreakWrappedTables/>\n   <w:SnapToGridInCell/>\n   <w:WrapTextWithPunct/>\n   <w:UseAsianBreakRules/>\n   <w:DontGrowAutofit/>\n  </w:Compatibility>\n  <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>\n </w:WordDocument>\n</xml><![endif]--><!--[if gte mso 9]><xml>\n <w:LatentStyles DefLockedState="false" LatentStyleCount="156">\n </w:LatentStyles>\n</xml><![endif]--><style>\n<!--\n /* Style Definitions */\n p.MsoNormal, li.MsoNormal, div.MsoNormal\n	{mso-style-parent:"";\n	margin:0cm;\n	margin-bottom:.0001pt;\n	line-height:150%;\n	mso-pagination:widow-orphan;\n	font-size:12.0pt;\n	font-family:Arial;\n	mso-fareast-font-family:"Times New Roman";\n	mso-bidi-font-family:"Times New Roman";\n	mso-fareast-language:AR-SA;}\np.FCZUseCaseParagraph, li.FCZUseCaseParagraph, div.FCZUseCaseParagraph\n	{mso-style-name:"FCZ UseCaseParagraph";\n	margin-top:4.0pt;\n	margin-right:0cm;\n	margin-bottom:3.0pt;\n	margin-left:2.85pt;\n	mso-pagination:widow-orphan;\n	mso-layout-grid-align:none;\n	punctuation-wrap:simple;\n	text-autospace:none;\n	font-size:8.0pt;\n	font-family:Arial;\n	mso-fareast-font-family:"Times New Roman";\n	mso-bidi-font-family:"Times New Roman";\n	mso-ansi-language:EN-CA;}\n@page Section1\n	{size:612.0pt 792.0pt;\n	margin:70.85pt 70.85pt 2.0cm 70.85pt;\n	mso-header-margin:36.0pt;\n	mso-footer-margin:36.0pt;\n	mso-paper-source:0;}\ndiv.Section1\n	{page:Section1;}\n-->\n</style><!--[if gte mso 10]>\n<style>\n /* Style Definitions */\n table.MsoNormalTable\n	{mso-style-name:"Table Normal";\n	mso-tstyle-rowband-size:0;\n	mso-tstyle-colband-size:0;\n	mso-style-noshow:yes;\n	mso-style-parent:"";\n	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;\n	mso-para-margin:0cm;\n	mso-para-margin-bottom:.0001pt;\n	mso-pagination:widow-orphan;\n	font-size:10.0pt;\n	font-family:"Times New Roman";\n	mso-ansi-language:#0400;\n	mso-fareast-language:#0400;\n	mso-bidi-language:#0400;}\n</style>\n<![endif]-->\n\n\n\n\n\n";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236180287075641, 'pgiuseppe'),
(20717, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:22:"New ChiBusinessProcess";}}}', 0, 'changeProperty', 'ChiBusinessProcess:20715', NULL, 1236181038961583, 'pgiuseppe'),
(20720, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4626";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4803";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:20716', NULL, 1236181039284644, 'pgiuseppe'),
(20721, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4626";s:8:"newValue";s:4:"4626";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4803";s:8:"newValue";s:4:"4809";}}}', 0, 'changeProperty', 'Figure:20716', NULL, 1236181040408073, 'pgiuseppe'),
(20722, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:22:"New ChiBusinessProcess";s:8:"newValue";s:11:"manage time";}}}', 0, 'changeProperty', 'ChiBusinessProcess:20715', NULL, 1236181055008535, 'pgiuseppe'),
(20725, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:22:"New ChiBusinessProcess";}}}', 0, 'changeProperty', 'ChiBusinessProcess:20723', NULL, 1236181114443617, 'pgiuseppe'),
(20728, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4810";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4754";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:20724', NULL, 1236181114820606, 'pgiuseppe'),
(20729, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4810";s:8:"newValue";s:4:"4811";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4754";s:8:"newValue";s:4:"4754";}}}', 0, 'changeProperty', 'Figure:20724', NULL, 1236181115836536, 'pgiuseppe'),
(20730, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:22:"New ChiBusinessProcess";s:8:"newValue";s:16:"Order Management";}}}', 0, 'changeProperty', 'ChiBusinessProcess:20723', NULL, 1236181132201452, 'pgiuseppe'),
(20731, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4811";s:8:"newValue";s:4:"4647";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4754";s:8:"newValue";s:4:"4706";}}}', 0, 'changeProperty', 'Figure:20724', NULL, 1236181137361374, 'pgiuseppe'),
(20736, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4917";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4702";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:20733', NULL, 1236181142137435, 'pgiuseppe'),
(20742, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4907";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4592";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:20739', NULL, 1236181153784901, 'pgiuseppe'),
(20743, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4907";s:8:"newValue";s:4:"4935";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4592";s:8:"newValue";s:4:"4549";}}}', 0, 'changeProperty', 'Figure:20739', NULL, 1236181159149969, 'pgiuseppe'),
(20746, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4917";s:8:"newValue";s:4:"4943";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4702";s:8:"newValue";s:4:"4666";}}}', 0, 'changeProperty', 'Figure:20733', NULL, 1236181160573418, 'pgiuseppe'),
(20749, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4647";s:8:"newValue";s:4:"4644";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"4706";s:8:"newValue";s:4:"4624";}}}', 0, 'changeProperty', 'Figure:20724', NULL, 1236181162517085, 'pgiuseppe'),
(20755, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:36:"Field Worker organizes Week activity";}}}', 0, 'changeProperty', 'ActivitySet:18779', NULL, 1236181348093027, 'pgiuseppe'),
(20763, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5347";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5436";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"60";}}}', 0, 'changeProperty', 'Figure:20760', NULL, 1236181362788535, 'pgiuseppe'),
(20764, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5347";s:8:"newValue";s:4:"5264";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5436";s:8:"newValue";s:4:"5407";}}}', 0, 'changeProperty', 'Figure:20760', NULL, 1236181364272548, 'pgiuseppe'),
(20767, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5277";s:8:"newValue";s:4:"5282";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5125";s:8:"newValue";s:4:"5111";}}}', 0, 'changeProperty', 'Figure:18789', NULL, 1236181368652304, 'pgiuseppe'),
(20772, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:665:"<ul><li>&#160;<span lang="EN-CA">Field Worker plans ?Silver?\nTrouble Calls to be processed at least 2 days before expiration of reaction\ntime.</span></li><li><span lang="EN-CA">He checks if it is meaningful to\ncheck up all Transmitters in the faulty Transmitter?s Subdomain. If so, plan\nmaintenance of whole Subdomain on that day.</span></li><li><span lang="EN-CA">Check if there are still any\nsingle postponed or open tasks to be planned and organize them in a meaningful\nway.</span></li><li><span style="font-size: 12pt; line-height: 150%; font-family: Arial;">For the remaining days\nplan maintenance of Transmitters of a whole Subdomain.</span></li></ul>\n\n\n\n\n\n\n\n";s:8:"newValue";s:688:"<ul><li>&nbsp;<span lang="EN-CA">Field Worker plans ?Silver? \nTrouble Calls to be processed at least 2 days before expiration of reaction \ntime.</span></li><li><span lang="EN-CA">He checks if it is meaningful to \ncheck up all Transmitters in the faulty Transmitter?s Subdomain. If so, plan \nmaintenance of whole Subdomain on that day.</span></li><li><span lang="EN-CA">Check if there are still any \nsingle postponed or open tasks to be planned and organize them in a meaningful \nway.</span></li><li><span style="font-size: 12pt; line-height: 150%; font-family: Arial;">For the remaining days \nplan maintenance of Transmitters of a whole Subdomain.</span></li></ul> \n \n \n \n \n \n \n \n";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9956', NULL, 1236181421471132, 'pgiuseppe'),
(20775, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:12:"New Activity";s:8:"newValue";s:109:"Field Worker plans ?Silver? Trouble Calls to be processed at least 2 days before expiration of reaction time.";}}}', 0, 'changeProperty', 'Activity:18798', NULL, 1236181435451110, 'pgiuseppe'),
(20776, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:405:"&nbsp;<br><ul><li><span lang="EN-CA"><br></span><span lang="EN-CA"></span></li><li><span lang="EN-CA">Check if there are still any \nsingle postponed or open tasks to be planned and organize them in a meaningful \nway.</span></li><li><span style="font-size: 12pt; line-height: 150%; font-family: Arial;">For the remaining days \nplan maintenance of Transmitters of a whole Subdomain.</span></li></ul>";}}}', 0, 'changeProperty', 'Activity:18798', NULL, 1236181452721628, 'pgiuseppe'),
(20779, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:12:"New Activity";s:8:"newValue";s:155:"# He checks if it is meaningful to check up all Transmitters in the faulty Transmitter?s Subdomain. If so, plan maintenance of whole Subdomain on that day.";}}}', 0, 'changeProperty', 'Activity:18800', NULL, 1236181460146921, 'pgiuseppe'),
(20780, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:155:"# He checks if it is meaningful to check up all Transmitters in the faulty Transmitter?s Subdomain. If so, plan maintenance of whole Subdomain on that day.";s:8:"newValue";s:96:"He checks if it is meaningful to check up all Transmitters in the faulty Transmitter?s Subdomain";}}}', 0, 'changeProperty', 'Activity:18800', NULL, 1236181489719368, 'pgiuseppe'),
(20781, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:118:"<span lang="EN-CA">&nbsp;If so, plan \nmaintenance of whole </span><span lang="EN-CA">Subdomain on that day.</span>";}}}', 0, 'changeProperty', 'Activity:18800', NULL, 1236181502359661, 'pgiuseppe'),
(20786, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5264";s:8:"newValue";s:4:"5261";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5407";s:8:"newValue";s:4:"5408";}}}', 0, 'changeProperty', 'Figure:20760', NULL, 1236181505375362, 'pgiuseppe'),
(20789, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:2:"95";s:8:"newValue";s:2:"95";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"60";s:8:"newValue";s:3:"117";}}}', 0, 'changeProperty', 'Figure:18797', NULL, 1236181511556075, 'pgiuseppe'),
(20792, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5261";s:8:"newValue";s:4:"5259";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5408";s:8:"newValue";s:4:"5427";}}}', 0, 'changeProperty', 'Figure:20760', NULL, 1236181513089699, 'pgiuseppe'),
(20795, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:20793', NULL, 1236181520974458, 'pgiuseppe'),
(20798, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5483";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5427";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"60";}}}', 0, 'changeProperty', 'Figure:20794', NULL, 1236181521315126, 'pgiuseppe'),
(20801, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:2:"95";s:8:"newValue";s:3:"171";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:3:"117";s:8:"newValue";s:3:"117";}}}', 0, 'changeProperty', 'Figure:18797', NULL, 1236181524474367, 'pgiuseppe'),
(20802, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5260";s:8:"newValue";s:4:"5233";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5243";s:8:"newValue";s:4:"5214";}}}', 0, 'changeProperty', 'Figure:18797', NULL, 1236181525375060, 'pgiuseppe'),
(20803, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:3:"171";s:8:"newValue";s:3:"171";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:3:"117";s:8:"newValue";s:2:"86";}}}', 0, 'changeProperty', 'Figure:18797', NULL, 1236181527435848, 'pgiuseppe'),
(20806, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5483";s:8:"newValue";s:4:"5452";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5427";s:8:"newValue";s:4:"5419";}}}', 0, 'changeProperty', 'Figure:20794', NULL, 1236181528412487, 'pgiuseppe'),
(20811, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5452";s:8:"newValue";s:4:"5464";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5419";s:8:"newValue";s:4:"5424";}}}', 0, 'changeProperty', 'Figure:20794', NULL, 1236181538003451, 'pgiuseppe'),
(20814, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:373:"&#160;<br><ul><li><span ><br></span><span ></span></li><li><span lang="EN-CA">Check if there are still any \nsingle postponed or open tasks to be planned and organize them in a meaningful \nway.</span></li><li><span style="font-size: 12pt; line-height: 150%; font-family: Arial;">For the remaining days \nplan maintenance of Transmitters of a whole Subdomain.</span></li></ul>";s:8:"newValue";s:266:"&nbsp;<br><ul><li><span><br></span><span></span></li><li><span lang="EN-CA"><br></span></li><li><span style="font-size: 12pt; line-height: 150%; font-family: Arial;">For the remaining days  \nplan maintenance of Transmitters of a whole Subdomain.</span></li></ul>";}}}', 0, 'changeProperty', 'Activity:18798', NULL, 1236181548794953, 'pgiuseppe'),
(20817, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:12:"New Activity";s:8:"newValue";s:59:"Check if there are still any single postponed or open tasks";}}}', 0, 'changeProperty', 'Activity:20793', NULL, 1236181566468647, 'pgiuseppe'),
(20818, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:2:"95";s:8:"newValue";s:2:"95";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"60";s:8:"newValue";s:2:"74";}}}', 0, 'changeProperty', 'Figure:20794', NULL, 1236181570273119, 'pgiuseppe'),
(20819, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:149:"<span lang="EN-CA">Check if there are still any  \nsingle postponed or open tasks to be planned and organize them in a meaningful  \nway.</span> <br>";}}}', 0, 'changeProperty', 'Activity:20793', NULL, 1236181572180449, 'pgiuseppe'),
(20824, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:20822', NULL, 1236181585779857, 'pgiuseppe'),
(20825, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:251:"&#160;<br><ul><li><span ><br></span><span></span></li><li><span ><br></span></li><li><span style="font-size: 12pt; line-height: 150%; font-family: Arial;">For the remaining days  \nplan maintenance of Transmitters of a whole Subdomain.</span></li></ul>";s:8:"newValue";s:10:"&nbsp;<br>";}}}', 0, 'changeProperty', 'Activity:18798', NULL, 1236181585947348, 'pgiuseppe'),
(20826, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5610";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5421";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"60";}}}', 0, 'changeProperty', 'Figure:20823', NULL, 1236181586105279, 'pgiuseppe'),
(20831, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5464";s:8:"newValue";s:4:"5476";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5424";s:8:"newValue";s:4:"5200";}}}', 0, 'changeProperty', 'Figure:20794', NULL, 1236181596034451, 'pgiuseppe'),
(20834, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5610";s:8:"newValue";s:4:"5530";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5421";s:8:"newValue";s:4:"5423";}}}', 0, 'changeProperty', 'Figure:20823', NULL, 1236181598018646, 'pgiuseppe'),
(20835, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:12:"New Activity";s:8:"newValue";s:77:"For the remaining days plan maintenance of Transmitters of a whole Subdomain.";}}}', 0, 'changeProperty', 'Activity:20822', NULL, 1236181601026466, 'pgiuseppe'),
(20836, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:2:"95";s:8:"newValue";s:2:"95";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"60";s:8:"newValue";s:2:"99";}}}', 0, 'changeProperty', 'Figure:20823', NULL, 1236181609913197, 'pgiuseppe'),
(20841, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5548";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5574";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}}', 0, 'changeProperty', 'Figure:20838', NULL, 1236181615320068, 'pgiuseppe'),
(20842, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:20837', NULL, 1236181615611412, 'pgiuseppe'),
(20845, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5282";s:8:"newValue";s:4:"5292";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5111";s:8:"newValue";s:4:"5068";}}}', 0, 'changeProperty', 'Figure:18789', NULL, 1236181634516014, 'pgiuseppe'),
(20846, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5292";s:8:"newValue";s:4:"5144";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5068";s:8:"newValue";s:4:"5130";}}}', 0, 'changeProperty', 'Figure:18789', NULL, 1236181636771837, 'pgiuseppe'),
(20847, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5144";s:8:"newValue";s:4:"5062";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5130";s:8:"newValue";s:4:"5022";}}}', 0, 'changeProperty', 'Figure:18789', NULL, 1236181642416889, 'pgiuseppe'),
(20850, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5233";s:8:"newValue";s:4:"5237";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5214";s:8:"newValue";s:4:"5089";}}}', 0, 'changeProperty', 'Figure:18797', NULL, 1236181648254992, 'pgiuseppe'),
(20853, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5476";s:8:"newValue";s:4:"5517";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5200";s:8:"newValue";s:4:"5088";}}}', 0, 'changeProperty', 'Figure:20794', NULL, 1236181652851818, 'pgiuseppe'),
(20856, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5530";s:8:"newValue";s:4:"5594";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5423";s:8:"newValue";s:4:"5212";}}}', 0, 'changeProperty', 'Figure:20823', NULL, 1236181654781469, 'pgiuseppe'),
(20859, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5548";s:8:"newValue";s:4:"5444";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5574";s:8:"newValue";s:4:"5418";}}}', 0, 'changeProperty', 'Figure:20838', NULL, 1236181656414617, 'pgiuseppe'),
(20862, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5259";s:8:"newValue";s:4:"5254";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5427";s:8:"newValue";s:4:"5317";}}}', 0, 'changeProperty', 'Figure:20760', NULL, 1236181660510785, 'pgiuseppe'),
(20865, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:20863', NULL, 1236181668965097, 'pgiuseppe'),
(20868, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5214";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5423";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"60";}}}', 0, 'changeProperty', 'Figure:20864', NULL, 1236181669308344, 'pgiuseppe'),
(20871, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:96:"He checks if it is meaningful to check up all Transmitters in the faulty Transmitter?s Subdomain";s:8:"newValue";s:0:"";}}}', 0, 'changeProperty', 'Activity:18800', NULL, 1236181677818650, 'pgiuseppe'),
(20874, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:12:"New Activity";s:8:"newValue";s:96:"He checks if it is meaningful to check up all Transmitters in the faulty Transmitter?s Subdomain";}}}', 0, 'changeProperty', 'Activity:20863', NULL, 1236181680770699, 'pgiuseppe'),
(20877, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:102:"<span lang="EN-CA">&#160;If so, plan \nmaintenance of whole </span><span >Subdomain on that day.</span>";s:8:"newValue";s:104:"<span lang="EN-CA">&nbsp;If so, plan  \nmaintenance of whole </span><span>Subdomain on that day.</span>";}}}', 0, 'changeProperty', 'Activity:18800', NULL, 1236181687276100, 'pgiuseppe'),
(20880, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:105:"&nbsp;<span lang="EN-CA"> If so, plan  \nmaintenance of whole </span><span>Subdomain on that day.</span>";}}}', 0, 'changeProperty', 'Activity:20863', NULL, 1236181690938248, 'pgiuseppe'),
(20883, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5254";s:8:"newValue";s:4:"5255";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5317";s:8:"newValue";s:4:"5317";}}}', 0, 'changeProperty', 'Figure:20760', NULL, 1236181714222039, 'pgiuseppe'),
(20886, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5214";s:8:"newValue";s:4:"5254";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5423";s:8:"newValue";s:4:"5310";}}}', 0, 'changeProperty', 'Figure:20864', NULL, 1236181721042478, 'pgiuseppe'),
(20887, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:2:"95";s:8:"newValue";s:2:"95";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"60";s:8:"newValue";s:3:"106";}}}', 0, 'changeProperty', 'Figure:20864', NULL, 1236181725251120, 'pgiuseppe'),
(20888, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:2:"95";s:8:"newValue";s:3:"113";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:3:"106";s:8:"newValue";s:3:"106";}}}', 0, 'changeProperty', 'Figure:20864', NULL, 1236181727094970, 'pgiuseppe'),
(20892, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5254";s:8:"newValue";s:4:"5273";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5310";s:8:"newValue";s:4:"5024";}}}', 0, 'changeProperty', 'Figure:20864', NULL, 1236181740542065, 'pgiuseppe'),
(20895, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5517";s:8:"newValue";s:4:"5510";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5088";s:8:"newValue";s:4:"5039";}}}', 0, 'changeProperty', 'Figure:20794', NULL, 1236181741706035, 'pgiuseppe'),
(20898, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5594";s:8:"newValue";s:4:"5483";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5212";s:8:"newValue";s:4:"5198";}}}', 0, 'changeProperty', 'Figure:20823', NULL, 1236181744425104, 'pgiuseppe'),
(20901, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:17:"New ActivityFinal";s:8:"newValue";s:3:"end";}}}', 0, 'changeProperty', 'ActivityFinal:20837', NULL, 1236181752636960, 'pgiuseppe'),
(20923, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5325";s:8:"newValue";s:4:"5481";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5282";s:8:"newValue";s:4:"5178";}}}', 0, 'changeProperty', 'Figure:9666', NULL, 1236182302615290, 'pgiuseppe'),
(20926, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5222";s:8:"newValue";s:4:"5367";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5290";s:8:"newValue";s:4:"5160";}}}', 0, 'changeProperty', 'Figure:9678', NULL, 1236182303575829, 'pgiuseppe'),
(20929, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:21:"New ChiWorkerInternal";}}}', 0, 'changeProperty', 'ChiWorkerInternal:20927', NULL, 1236182345795743, 'pgiuseppe'),
(20932, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5186";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5237";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"48";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"52";}}}', 0, 'changeProperty', 'Figure:20928', NULL, 1236182346176557, 'pgiuseppe'),
(20933, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5186";s:8:"newValue";s:4:"5210";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5237";s:8:"newValue";s:4:"5215";}}}', 0, 'changeProperty', 'Figure:20928', NULL, 1236182347937761, 'pgiuseppe'),
(20934, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:21:"New ChiWorkerInternal";s:8:"newValue";s:10:"ERP system";}}}', 0, 'changeProperty', 'ChiWorkerInternal:20927', NULL, 1236182353590574, 'pgiuseppe'),
(20935, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5210";s:8:"newValue";s:4:"5197";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5215";s:8:"newValue";s:4:"5203";}}}', 0, 'changeProperty', 'Figure:20928', NULL, 1236182356110007, 'pgiuseppe'),
(20937, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Diagram";}}}', 0, 'changeProperty', 'Diagram:20936', NULL, 1236182377253156, 'pgiuseppe'),
(20942, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New Diagram";s:8:"newValue";s:23:"Interface specification";}}}', 0, 'changeProperty', 'Diagram:20936', NULL, 1236182394958100, 'pgiuseppe'),
(20945, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5197";s:8:"newValue";s:4:"5215";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5203";s:8:"newValue";s:4:"5208";}}}', 0, 'changeProperty', 'Figure:20928', NULL, 1236182421680081, 'pgiuseppe'),
(20961, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5233";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5340";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"48";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"52";}}}', 0, 'changeProperty', 'Figure:20958', NULL, 1236182507061092, 'pgiuseppe'),
(20962, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5233";s:8:"newValue";s:4:"5239";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5340";s:8:"newValue";s:4:"5080";}}}', 0, 'changeProperty', 'Figure:20958', NULL, 1236182510165585, 'pgiuseppe'),
(20967, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5226";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5247";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"116";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:20964', NULL, 1236182528889582, 'pgiuseppe'),
(20972, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5085";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5328";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"52";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:20969', NULL, 1236182539849879, 'pgiuseppe'),
(20973, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5085";s:8:"newValue";s:4:"5498";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5328";s:8:"newValue";s:4:"5249";}}}', 0, 'changeProperty', 'Figure:20969', NULL, 1236182540675886, 'pgiuseppe'),
(20976, 'a:1:{i:0;a:1:{s:11:"OtherActors";a:2:{s:8:"oldValue";s:6:"SVNCRM";s:8:"newValue";s:5:"20927";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9938', NULL, 1236182577622306, 'pgiuseppe'),
(20977, 'a:1:{i:0;a:1:{s:11:"OtherActors";a:2:{s:8:"oldValue";s:5:"20927";s:8:"newValue";s:5:"20927";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9938', NULL, 1236182587722387, 'pgiuseppe'),
(20978, 'a:1:{i:0;a:1:{s:11:"OtherActors";a:2:{s:8:"oldValue";s:5:"20927";s:8:"newValue";s:5:"20927";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9938', NULL, 1236182595208386, 'pgiuseppe'),
(20979, 'a:1:{i:0;a:1:{s:11:"OtherActors";a:2:{s:8:"oldValue";s:5:"20927";s:8:"newValue";s:5:"20927";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9938', NULL, 1236182596036932, 'pgiuseppe'),
(20980, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9938', NULL, 1236182596226998, 'pgiuseppe'),
(20983, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9938', NULL, 1236182605043371, 'pgiuseppe'),
(20984, 'a:1:{i:0;a:1:{s:11:"OtherActors";a:2:{s:8:"oldValue";s:5:"20927";s:8:"newValue";s:5:"20927";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9938', NULL, 1236182605591937, 'pgiuseppe'),
(20985, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5239";s:8:"newValue";s:4:"5340";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5080";s:8:"newValue";s:4:"5071";}}}', 0, 'changeProperty', 'Figure:20958', NULL, 1236182606836406, 'pgiuseppe'),
(20990, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:3:"116";s:8:"newValue";s:3:"162";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"79";s:8:"newValue";s:2:"79";}}}', 0, 'changeProperty', 'Figure:20964', NULL, 1236182614406835, 'pgiuseppe'),
(20995, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New Package";s:8:"newValue";s:8:"UK Pilot";}}}', 0, 'changeProperty', 'Package:18605', NULL, 1236184229683041, 'ibm'),
(20997, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Package";}}}', 0, 'changeProperty', 'Package:20996', NULL, 1236184262338789, 'ibm'),
(20998, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:46:"<span id="inlineComboBoxSpanId"> <br></span>";}}}', 0, 'changeProperty', 'Package:18605', NULL, 1236184267533604, 'ibm'),
(21001, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New Package";s:8:"newValue";s:5:"Goals";}}}', 0, 'changeProperty', 'Package:20996', NULL, 1236184280205298, 'ibm'),
(21003, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Package";}}}', 0, 'changeProperty', 'Package:21002', NULL, 1236184340721257, 'ibm'),
(21004, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:8:"&nbsp;jj";}}}', 0, 'changeProperty', 'Package:20996', NULL, 1236184342698228, 'ibm'),
(21008, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Diagram";}}}', 0, 'changeProperty', 'Diagram:21007', NULL, 1236184350847957, 'ibm'),
(21039, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";N;s:8:"newValue";s:8:"<br><br>";}}}', 0, 'changeProperty', 'Package:15647', NULL, 1236184850822691, 'ibm'),
(21043, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Package";}}}', 0, 'changeProperty', 'Package:21042', NULL, 1236255831720115, 'pgiuseppe'),
(21046, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New Package";s:8:"newValue";s:0:"";}}}', 0, 'changeProperty', 'Package:21042', NULL, 1236255885079972, 'pgiuseppe');
INSERT INTO `History` (`id`, `data`, `duplicate`, `eventtype`, `affectedoid`, `otheroid`, `timestamp`, `user`) VALUES
(21056, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Diagram";}}}', 0, 'changeProperty', 'Diagram:21055', NULL, 1236256144156821, 'pgiuseppe'),
(21059, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:14:"vision mission";}}}', 0, 'changeProperty', 'Package:21042', NULL, 1236256154478129, 'pgiuseppe'),
(21062, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiGoal";}}}', 0, 'changeProperty', 'ChiGoal:21060', NULL, 1236256158160494, 'pgiuseppe'),
(21063, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5135";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5121";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:21061', NULL, 1236256158548410, 'pgiuseppe'),
(21066, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New ChiGoal";s:8:"newValue";s:80:"Gain market share by winning contracts for newly erected transmitter generations";}}}', 0, 'changeProperty', 'ChiGoal:21060', NULL, 1236256165306500, 'pgiuseppe'),
(21067, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:3:"150";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"50";s:8:"newValue";s:2:"85";}}}', 0, 'changeProperty', 'Figure:21061', NULL, 1236256168688529, 'pgiuseppe'),
(21068, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5534";}}}', 0, 'changeProperty', 'ChiGoal:21060', NULL, 1236256174084609, 'pgiuseppe'),
(21069, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:4:"5534";s:8:"newValue";s:4:"5534";}}}', 0, 'changeProperty', 'ChiGoal:21060', NULL, 1236256187528167, 'pgiuseppe'),
(21070, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";s:4:"5534";s:8:"newValue";s:4:"5534";}}}', 0, 'changeProperty', 'ChiGoal:21060', NULL, 1236256187931032, 'pgiuseppe'),
(21075, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5414";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5119";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:21072', NULL, 1236256192660548, 'pgiuseppe'),
(21076, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiGoal";}}}', 0, 'changeProperty', 'ChiGoal:21071', NULL, 1236256192965241, 'pgiuseppe'),
(21077, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New ChiGoal";s:8:"newValue";s:80:"Gain market share by winning contracts for newly erected transmitter generations";}}}', 0, 'changeProperty', 'ChiGoal:21071', NULL, 1236256199187052, 'pgiuseppe'),
(21078, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:80:"Gain market share by winning contracts for newly erected transmitter generations";s:8:"newValue";s:99:"Constantly providing high-quality services for our partners in the mobile telecommunications sector";}}}', 0, 'changeProperty', 'ChiGoal:21071', NULL, 1236256209703030, 'pgiuseppe'),
(21079, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:3:"150";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"50";s:8:"newValue";s:2:"99";}}}', 0, 'changeProperty', 'Figure:21072', NULL, 1236256214920513, 'pgiuseppe'),
(21080, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5414";s:8:"newValue";s:4:"5369";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5119";s:8:"newValue";s:4:"5123";}}}', 0, 'changeProperty', 'Figure:21072', NULL, 1236256216119850, 'pgiuseppe'),
(21081, 'a:1:{i:0;a:1:{s:8:"GoalType";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5536";}}}', 0, 'changeProperty', 'ChiGoal:21071', NULL, 1236256219853830, 'pgiuseppe'),
(21082, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5369";s:8:"newValue";s:4:"5471";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5123";s:8:"newValue";s:4:"5120";}}}', 0, 'changeProperty', 'Figure:21072', NULL, 1236256224096817, 'pgiuseppe'),
(21085, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5135";s:8:"newValue";s:4:"5131";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5121";s:8:"newValue";s:4:"5166";}}}', 0, 'changeProperty', 'Figure:21061', NULL, 1236256225367920, 'pgiuseppe'),
(21086, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5131";s:8:"newValue";s:4:"5129";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5166";s:8:"newValue";s:4:"5148";}}}', 0, 'changeProperty', 'Figure:21061', NULL, 1236256226306727, 'pgiuseppe'),
(21095, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New Diagram";s:8:"newValue";s:14:"vision mission";}}}', 0, 'changeProperty', 'Diagram:21055', NULL, 1236258986149435, 'pgiuseppe'),
(21097, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5471";s:8:"newValue";s:4:"5462";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5120";s:8:"newValue";s:4:"5235";}}}', 0, 'changeProperty', 'Figure:21072', NULL, 1236259002788140, 'pgiuseppe'),
(21110, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5055";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5534";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:21107', NULL, 1236259195034581, 'pgiuseppe'),
(21111, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5055";s:8:"newValue";s:4:"5045";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5534";s:8:"newValue";s:4:"5083";}}}', 0, 'changeProperty', 'Figure:21107', NULL, 1236259197813392, 'pgiuseppe'),
(21114, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5229";s:8:"newValue";s:4:"5256";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5087";s:8:"newValue";s:4:"5065";}}}', 0, 'changeProperty', 'Figure:7706', NULL, 1236259204804010, 'pgiuseppe'),
(21115, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5256";s:8:"newValue";s:4:"5051";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5065";s:8:"newValue";s:4:"5190";}}}', 0, 'changeProperty', 'Figure:7706', NULL, 1236259213782539, 'pgiuseppe'),
(21118, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5045";s:8:"newValue";s:4:"5181";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5083";s:8:"newValue";s:4:"5053";}}}', 0, 'changeProperty', 'Figure:21107', NULL, 1236259215000187, 'pgiuseppe'),
(21121, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5447";s:8:"newValue";s:4:"5408";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5090";s:8:"newValue";s:4:"5152";}}}', 0, 'changeProperty', 'Figure:7762', NULL, 1236259224817319, 'pgiuseppe'),
(21122, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5408";s:8:"newValue";s:4:"5637";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5152";s:8:"newValue";s:4:"5154";}}}', 0, 'changeProperty', 'Figure:7762', NULL, 1236259232193434, 'pgiuseppe'),
(21125, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5181";s:8:"newValue";s:4:"5298";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5053";s:8:"newValue";s:4:"5054";}}}', 0, 'changeProperty', 'Figure:21107', NULL, 1236259244657967, 'pgiuseppe'),
(21128, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5637";s:8:"newValue";s:4:"5637";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5154";s:8:"newValue";s:4:"5155";}}}', 0, 'changeProperty', 'Figure:7762', NULL, 1236259252945141, 'pgiuseppe'),
(21129, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";s:3:"+5%";s:8:"newValue";s:1:"+";}}}', 0, 'changeProperty', 'ChiGoal:7763', NULL, 1236259262199968, 'pgiuseppe'),
(21130, 'a:1:{i:0;a:1:{s:10:"Value_Name";a:2:{s:8:"oldValue";s:13:"Effectiveness";s:8:"newValue";s:18:"Effectiveness in %";}}}', 0, 'changeProperty', 'ChiGoal:7763', NULL, 1236259265556671, 'pgiuseppe'),
(21131, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";s:1:"+";s:8:"newValue";s:1:"5";}}}', 0, 'changeProperty', 'ChiGoal:7763', NULL, 1236259270782785, 'pgiuseppe'),
(21132, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"20";}}}', 0, 'changeProperty', 'ChiGoal:7763', NULL, 1236259282867657, 'pgiuseppe'),
(21135, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";s:16:"Reduction by 15%";s:8:"newValue";s:0:"";}}}', 0, 'changeProperty', 'ChiGoal:7792', NULL, 1236259549797382, 'pgiuseppe'),
(21136, 'a:1:{i:0;a:1:{s:10:"Value_Name";a:2:{s:8:"oldValue";s:13:"Reaction time";s:8:"newValue";s:27:"Reaction time Reduction by ";}}}', 0, 'changeProperty', 'ChiGoal:7792', NULL, 1236259555517946, 'pgiuseppe'),
(21137, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"15%";}}}', 0, 'changeProperty', 'ChiGoal:7792', NULL, 1236259556563416, 'pgiuseppe'),
(21138, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}}', 0, 'changeProperty', 'ChiGoal:7792', NULL, 1236259565085816, 'pgiuseppe'),
(21139, 'a:1:{i:0;a:1:{s:10:"Value_Name";a:2:{s:8:"oldValue";s:27:"Reaction time Reduction by ";s:8:"newValue";s:32:"Reaction time in day % reduction";}}}', 0, 'changeProperty', 'ChiGoal:7792', NULL, 1236259587925090, 'pgiuseppe'),
(21140, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";s:3:"15%";s:8:"newValue";s:2:"15";}}}', 0, 'changeProperty', 'ChiGoal:7792', NULL, 1236259929171306, 'pgiuseppe'),
(21141, 'a:1:{i:0;a:1:{s:10:"Value_Name";a:2:{s:8:"oldValue";s:32:"Reaction time in day % reduction";s:8:"newValue";s:31:"Reaction time in day  reduction";}}}', 0, 'changeProperty', 'ChiGoal:7792', NULL, 1236259959090402, 'pgiuseppe'),
(21142, 'a:1:{i:0;a:1:{s:10:"Value_Goal";a:2:{s:8:"oldValue";s:2:"15";s:8:"newValue";s:2:"35";}}}', 0, 'changeProperty', 'ChiGoal:7792', NULL, 1236259973892539, 'pgiuseppe'),
(21173, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5354";s:8:"newValue";s:4:"5353";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5634";s:8:"newValue";s:4:"5643";}}}', 0, 'changeProperty', 'Figure:7989', NULL, 1236260795270729, 'pgiuseppe'),
(21174, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:5:"11255";s:8:"newValue";s:4:"5007";}}}', 0, 'changeProperty', 'ChiRequirement:7990', NULL, 1236260854000964, 'pgiuseppe'),
(21175, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5007";s:8:"newValue";s:4:"5007";}}}', 0, 'changeProperty', 'ChiRequirement:7990', NULL, 1236260891972814, 'pgiuseppe'),
(21176, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5007";s:8:"newValue";s:4:"5007";}}}', 0, 'changeProperty', 'ChiRequirement:7990', NULL, 1236260894530515, 'pgiuseppe'),
(21177, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:4:"5007";s:8:"newValue";s:4:"5007";}}}', 0, 'changeProperty', 'ChiRequirement:7990', NULL, 1236260894978307, 'pgiuseppe'),
(21195, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"6114";s:8:"newValue";s:4:"5174";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5460";s:8:"newValue";s:4:"5164";}}}', 0, 'changeProperty', 'Figure:8901', NULL, 1236260906062763, 'pgiuseppe'),
(21198, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5813";s:8:"newValue";s:4:"5508";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5422";s:8:"newValue";s:4:"5203";}}}', 0, 'changeProperty', 'Figure:8877', NULL, 1236260908696082, 'pgiuseppe'),
(21201, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5722";s:8:"newValue";s:4:"5518";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5280";s:8:"newValue";s:4:"5283";}}}', 0, 'changeProperty', 'Figure:8839', NULL, 1236260910107517, 'pgiuseppe'),
(21204, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5882";s:8:"newValue";s:4:"5513";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5505";s:8:"newValue";s:4:"5389";}}}', 0, 'changeProperty', 'Figure:8879', NULL, 1236260912399732, 'pgiuseppe'),
(21207, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5188";s:8:"newValue";s:4:"5297";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5481";s:8:"newValue";s:4:"5483";}}}', 0, 'changeProperty', 'Figure:8883', NULL, 1236260917619783, 'pgiuseppe'),
(21210, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4884";s:8:"newValue";s:4:"5298";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5397";s:8:"newValue";s:4:"5279";}}}', 0, 'changeProperty', 'Figure:8903', NULL, 1236260920529530, 'pgiuseppe'),
(21213, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4773";s:8:"newValue";s:4:"5307";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5225";s:8:"newValue";s:4:"5395";}}}', 0, 'changeProperty', 'Figure:8308', NULL, 1236260926573132, 'pgiuseppe'),
(21216, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5174";s:8:"newValue";s:4:"5283";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5164";s:8:"newValue";s:4:"5153";}}}', 0, 'changeProperty', 'Figure:8901', NULL, 1236260928562741, 'pgiuseppe'),
(21217, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"4912";s:8:"newValue";s:4:"5061";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5079";s:8:"newValue";s:4:"5172";}}}', 0, 'changeProperty', 'Figure:8833', NULL, 1236260932027615, 'pgiuseppe'),
(21218, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5192";s:8:"newValue";s:4:"5087";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5040";s:8:"newValue";s:4:"5282";}}}', 0, 'changeProperty', 'Figure:8851', NULL, 1236260933591453, 'pgiuseppe'),
(21244, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New Diagram";}}}', 0, 'changeProperty', 'Diagram:21243', NULL, 1236260970536022, 'pgiuseppe'),
(21249, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:11:"New Diagram";s:8:"newValue";s:29:"requirements features diagram";}}}', 0, 'changeProperty', 'Diagram:21243', NULL, 1236261089870537, 'pgiuseppe'),
(21256, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5203";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5361";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:21253', NULL, 1236261115247381, 'pgiuseppe'),
(21267, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5240";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5209";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:21264', NULL, 1236261190218495, 'pgiuseppe'),
(21273, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5444";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5212";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:21270', NULL, 1236261214417910, 'pgiuseppe'),
(21274, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5444";s:8:"newValue";s:4:"5444";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5212";s:8:"newValue";s:4:"5211";}}}', 0, 'changeProperty', 'Figure:21270', NULL, 1236261216037733, 'pgiuseppe'),
(21275, 'a:2:{i:0;a:1:{s:5:"Width";a:2:{s:8:"oldValue";s:3:"150";s:8:"newValue";s:3:"150";}}i:1;a:1:{s:6:"Height";a:2:{s:8:"oldValue";s:2:"50";s:8:"newValue";s:2:"69";}}}', 0, 'changeProperty', 'Figure:21270', NULL, 1236261217408296, 'pgiuseppe'),
(21278, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5203";s:8:"newValue";s:4:"5450";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5361";s:8:"newValue";s:4:"5370";}}}', 0, 'changeProperty', 'Figure:21253', NULL, 1236261243478955, 'pgiuseppe'),
(21279, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:5:"11382";s:8:"newValue";s:2:"70";}}}', 0, 'changeProperty', 'ChiFeature:8834', NULL, 1236261363633166, 'pgiuseppe'),
(21280, 'a:1:{i:0;a:1:{s:6:"Status";a:2:{s:8:"oldValue";s:2:"70";s:8:"newValue";s:2:"70";}}}', 0, 'changeProperty', 'ChiFeature:8834', NULL, 1236261364588556, 'pgiuseppe'),
(21289, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiView";}}}', 0, 'changeProperty', 'ChiView:21287', NULL, 1236263861253334, 'pgiuseppe'),
(21290, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5460";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5443";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:21288', NULL, 1236263861396890, 'pgiuseppe'),
(21297, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiNode";}}}', 0, 'changeProperty', 'ChiNode:21293', NULL, 1236263866678969, 'pgiuseppe'),
(21298, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5250";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5339";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:21294', NULL, 1236263866831922, 'pgiuseppe'),
(21303, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ChiController";}}}', 0, 'changeProperty', 'ChiController:21299', NULL, 1236263871172518, 'pgiuseppe'),
(21304, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5154";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5467";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:21300', NULL, 1236263871317128, 'pgiuseppe'),
(21307, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5460";s:8:"newValue";s:4:"5394";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5443";s:8:"newValue";s:4:"5451";}}}', 0, 'changeProperty', 'Figure:21288', NULL, 1236263874732475, 'pgiuseppe'),
(21310, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5154";s:8:"newValue";s:4:"5062";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5467";s:8:"newValue";s:4:"5342";}}}', 0, 'changeProperty', 'Figure:21300', NULL, 1236263878416136, 'pgiuseppe'),
(21313, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5250";s:8:"newValue";s:4:"5112";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5339";s:8:"newValue";s:4:"5543";}}}', 0, 'changeProperty', 'Figure:21294', NULL, 1236263879785843, 'pgiuseppe'),
(21316, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiNode";}}}', 0, 'changeProperty', 'ChiNode:21314', NULL, 1236263887539026, 'pgiuseppe'),
(21319, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5382";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5700";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:21315', NULL, 1236263887879386, 'pgiuseppe'),
(21320, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5382";s:8:"newValue";s:4:"5205";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5700";s:8:"newValue";s:4:"5729";}}}', 0, 'changeProperty', 'Figure:21315', NULL, 1236263889377891, 'pgiuseppe'),
(21324, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5394";s:8:"newValue";s:4:"5391";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5451";s:8:"newValue";s:4:"5423";}}}', 0, 'changeProperty', 'Figure:21288', NULL, 1236263922579298, 'pgiuseppe'),
(21331, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5112";s:8:"newValue";s:4:"5076";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5543";s:8:"newValue";s:4:"5523";}}}', 0, 'changeProperty', 'Figure:21294', NULL, 1236263944257839, 'pgiuseppe'),
(21334, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5205";s:8:"newValue";s:4:"5269";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5729";s:8:"newValue";s:4:"5343";}}}', 0, 'changeProperty', 'Figure:21315', NULL, 1236263948898966, 'pgiuseppe'),
(21337, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5076";s:8:"newValue";s:4:"5158";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5523";s:8:"newValue";s:4:"5550";}}}', 0, 'changeProperty', 'Figure:21294', NULL, 1236263952835455, 'pgiuseppe'),
(21352, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5391";s:8:"newValue";s:4:"5537";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5423";s:8:"newValue";s:4:"5498";}}}', 0, 'changeProperty', 'Figure:21288', NULL, 1236264022944914, 'pgiuseppe'),
(21353, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5537";s:8:"newValue";s:4:"5503";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5498";s:8:"newValue";s:4:"5425";}}}', 0, 'changeProperty', 'Figure:21288', NULL, 1236264025992794, 'pgiuseppe'),
(21358, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5291";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5651";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"96";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}}', 0, 'changeProperty', 'Figure:21355', NULL, 1236264042472581, 'pgiuseppe'),
(21359, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiNode";}}}', 0, 'changeProperty', 'ChiNode:21354', NULL, 1236264042784494, 'pgiuseppe'),
(21360, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5291";s:8:"newValue";s:4:"5420";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5651";s:8:"newValue";s:4:"5653";}}}', 0, 'changeProperty', 'Figure:21355', NULL, 1236264043413473, 'pgiuseppe'),
(21361, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5420";s:8:"newValue";s:4:"5411";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5653";s:8:"newValue";s:4:"5625";}}}', 0, 'changeProperty', 'Figure:21355', NULL, 1236264055322274, 'pgiuseppe'),
(21364, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5503";s:8:"newValue";s:4:"5774";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5425";s:8:"newValue";s:4:"5476";}}}', 0, 'changeProperty', 'Figure:21288', NULL, 1236264058452651, 'pgiuseppe'),
(21367, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5411";s:8:"newValue";s:4:"5484";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5625";s:8:"newValue";s:4:"5458";}}}', 0, 'changeProperty', 'Figure:21355', NULL, 1236264060182396, 'pgiuseppe'),
(21372, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:25:"Energieeffizienz erhÃ¶hen";s:8:"newValue";s:24:"Energieeffizienz erhöhen";}}}', 0, 'changeProperty', 'ChiGoal:4237', NULL, 1236283146731256, 'pgiuseppe'),
(21390, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:11:"New ChiGoal";}}}', 0, 'changeProperty', 'ChiGoal:21388', NULL, 1236333494918494, 'admin'),
(21391, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5095";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5045";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:21389', NULL, 1236333495136866, 'admin'),
(21419, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, 'changeProperty', 'ChiRequirement:21417', NULL, 1236334074360155, 'admin'),
(21420, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5277";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"4938";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:21418', NULL, 1236334074530210, 'admin'),
(21435, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:18:"New ChiRequirement";}}}', 0, 'changeProperty', 'ChiRequirement:21433', NULL, 1236334183208833, 'admin'),
(21438, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5178";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5126";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:3:"150";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'Figure:21434', NULL, 1236334183569348, 'admin'),
(21439, 'a:2:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";s:4:"5178";s:8:"newValue";s:4:"5139";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";s:4:"5126";s:8:"newValue";s:4:"5110";}}}', 0, 'changeProperty', 'Figure:21434', NULL, 1236334184724601, 'admin'),
(21454, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";s:2:"50";s:8:"newValue";s:9:"dfgdfgfdg";}}}', 0, 'changeProperty', 'ChiGoal:7707', NULL, 1236334450687731, 'admin'),
(21455, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";s:9:"dfgdfgfdg";s:8:"newValue";s:2:"50";}}}', 0, 'changeProperty', 'ChiGoal:7707', NULL, 1236334566020710, 'admin'),
(21458, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";s:2:"50";s:8:"newValue";s:9:"dsfsdfdsf";}}}', 0, 'changeProperty', 'ChiGoal:7707', NULL, 1236335572566327, 'admin'),
(21463, 'a:1:{i:0;a:1:{s:13:"Value_ammount";a:2:{s:8:"oldValue";s:2:"20";s:8:"newValue";s:9:"fdsgdfgfd";}}}', 0, 'changeProperty', 'ChiGoal:7763', NULL, 1236336550452941, 'admin'),
(21468, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"9673";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9867', NULL, 1236358323600050, 'admin'),
(21469, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9673";s:8:"newValue";s:4:"9673";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9867', NULL, 1236358325773577, 'admin'),
(21472, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9673";s:8:"newValue";s:4:"9673";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9867', NULL, 1236358326155134, 'admin'),
(21473, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9920', NULL, 1236358328746855, 'admin'),
(21474, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9920', NULL, 1236358329431130, 'admin'),
(21475, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9920', NULL, 1236358332092588, 'admin'),
(21476, 'a:1:{i:0;a:1:{s:11:"OtherActors";a:2:{s:8:"oldValue";s:17:"SVNCRM, Allocator";s:8:"newValue";s:4:"9679";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9920', NULL, 1236358335119826, 'admin'),
(21477, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9920', NULL, 1236358335288103, 'admin'),
(21478, 'a:1:{i:0;a:1:{s:11:"OtherActors";a:2:{s:8:"oldValue";s:4:"9679";s:8:"newValue";s:4:"9679";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9920', NULL, 1236358335670488, 'admin'),
(21479, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9920', NULL, 1236358335821516, 'admin'),
(21480, 'a:1:{i:0;a:1:{s:11:"OtherActors";a:2:{s:8:"oldValue";s:4:"9679";s:8:"newValue";s:4:"9679";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9920', NULL, 1236358341055645, 'admin'),
(21483, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9920', NULL, 1236358341483998, 'admin'),
(21484, 'a:1:{i:0;a:1:{s:12:"PrimaryActor";a:2:{s:8:"oldValue";s:4:"9474";s:8:"newValue";s:4:"9474";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9920', NULL, 1236358341654341, 'admin'),
(21485, 'a:1:{i:0;a:1:{s:11:"OtherActors";a:2:{s:8:"oldValue";s:4:"9679";s:8:"newValue";s:4:"9679";}}}', 0, 'changeProperty', 'ChiBusinessUseCaseCore:9920', NULL, 1236358341836506, 'admin'),
(21488, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";s:21:"my 2nd ChiRequirement";s:8:"newValue";s:21:"my 1st ChiRequirement";}}}', 0, 'changeProperty', 'ChiRequirement:12419', NULL, 1236358569979554, 'admin'),
(21491, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:15:"New ActivitySet";}}}', 0, 'changeProperty', 'ActivitySet:21489', NULL, 1236358580822755, 'admin'),
(21492, 'a:1:{i:0;a:1:{s:5:"Notes";a:2:{s:8:"oldValue";s:250:"Modify this for create your own <b>Requirements</b>. \n	<br><br>A Business guide line about the\nEnterprise or the project.\n<p>A ChiRequirement represents a condition\nthat needs to be <span >Satisfied</span> by certain\nachievement (a ChiFeature ).</p>\n";s:8:"newValue";s:255:"Modify this for create your own <b>Requirements</b>.  \n	<br><br>A Business guide line about the \nEnterprise or the project. \n<p>A ChiRequirement represents a condition \nthat needs to be <span>Satisfied</span> by certain \nachievement (a ChiFeature ).</p> \n";}}}', 0, 'changeProperty', 'ChiRequirement:12419', NULL, 1236358583646836, 'admin'),
(21497, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:30:"my ChiBusinessUseCase activity";}}}', 0, 'changeProperty', 'ActivitySet:21489', NULL, 1236358596731147, 'admin'),
(21500, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:19:"New ActivityInitial";}}}', 0, 'changeProperty', 'ActivityInitial:21498', NULL, 1236358610138325, 'admin'),
(21503, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5192";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5113";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}}', 0, 'changeProperty', 'Figure:21499', NULL, 1236358610491254, 'admin'),
(21506, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:12:"New Activity";}}}', 0, 'changeProperty', 'Activity:21504', NULL, 1236358615273150, 'admin'),
(21509, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5193";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5267";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"95";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"60";}}}', 0, 'changeProperty', 'Figure:21505', NULL, 1236358615554924, 'admin'),
(21512, 'a:1:{i:0;a:1:{s:4:"Name";a:2:{s:8:"oldValue";N;s:8:"newValue";s:17:"New ActivityFinal";}}}', 0, 'changeProperty', 'ActivityFinal:21510', NULL, 1236358618072561, 'admin'),
(21515, 'a:4:{i:0;a:1:{s:9:"PositionX";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5232";}}i:1;a:1:{s:9:"PositionY";a:2:{s:8:"oldValue";N;s:8:"newValue";s:4:"5428";}}i:2;a:1:{s:5:"Width";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}i:3;a:1:{s:6:"Height";a:2:{s:8:"oldValue";N;s:8:"newValue";s:2:"40";}}}', 0, 'changeProperty', 'Figure:21511', NULL, 1236358618338292, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `InputType`
--

CREATE TABLE IF NOT EXISTS `InputType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `InputType`
--


-- --------------------------------------------------------

--
-- Table structure for table `Locktable`
--

CREATE TABLE IF NOT EXISTS `Locktable` (
  `id` int(11) NOT NULL,
  `fk_user_id` int(11) default NULL,
  `oid` varchar(255) default NULL,
  `sid` varchar(255) default NULL,
  `since` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Locktable`
--

INSERT INTO `Locktable` (`id`, `fk_user_id`, `oid`, `sid`, `since`) VALUES
(2831, 3, 'ChiRequirement:517', '12bada1a67e41556d325b5cfdcaef94c', '2008-12-17 14:20:22'),
(2838, 3, 'ChiRequirement:1101', '14da72911b7a57faf76628db6d8e55c1', '2008-12-17 14:22:19'),
(6590, 3, 'ChiRequirementStatus:745', '4bb1b0f4b930b509ed9743780d2cc10a', '2009-01-23 13:22:12'),
(2131, 3, 'ChiRequirement:1076', 'fd71215da392ec911daa84fc285f7c83', '2008-11-16 17:55:50'),
(1971, 3, 'ChiIssue:752', 'ebcedc5e841b4fc169cd9f1479e448d2', '2008-11-12 10:17:51'),
(1991, 3, 'ChiRequirement:194', '9b94ab906e5410b0dc7e772a10e6186d', '2008-11-12 20:34:48'),
(2133, 3, 'ChiRequirement:845', 'c9b1dd763015ea167fd0b8ed75ccb23b', '2008-11-16 17:56:03'),
(4387, 3, 'ChiFeatureStatus:3633', '28b01f913c88eaad16ce32657844c388', '2009-01-16 14:05:31'),
(18526, 3, 'Package:17342', 'f63bbc6073ce8a724a025610df1e6f68', '2009-02-27 09:49:48'),
(14493, 3, 'ChiBusinessUseCaseCore:13374', 'd4c0d9191b58b2d1850d56e7c282d273', '2009-02-13 15:59:19'),
(18060, 3, 'ChiGoal:5547', '1aecf4ab4c3affacc6191079337d1a61', '2009-02-26 18:14:24'),
(21451, 3, 'ChiRequirement:21433', 'cab05b0d3c7ef8a3e51a0cab91e80e53', '2009-03-06 11:11:36');

-- --------------------------------------------------------

--
-- Table structure for table `Model`
--

CREATE TABLE IF NOT EXISTS `Model` (
  `id` int(11) NOT NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Model`
--

INSERT INTO `Model` (`id`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`) VALUES
(2117, NULL, NULL, 'eurocom', '&nbsp;model related to Eurocom<br>', '2008-11-16 17:45:54', 'admin', 'admin', '2008-12-27 15:02:46'),
(12097, NULL, NULL, 'Chronos Default model', '&#160; \n	The <b>Chronos default \nmodel</b> is a template with a project structure that you can use as reference to \nkick off your project. \n', '2009-02-10 17:55:05', 'pgiuseppe', 'pgiuseppe', '2009-02-10 19:28:16');

-- --------------------------------------------------------

--
-- Table structure for table `NMActivityActivityDecision`
--

CREATE TABLE IF NOT EXISTS `NMActivityActivityDecision` (
  `id` int(11) NOT NULL,
  `fk_activitydecision_id` int(11) default NULL,
  `fk_activity_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_activitydecision_id` (`fk_activitydecision_id`),
  KEY `fk_activity_id` (`fk_activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NMActivityActivityDecision`
--


-- --------------------------------------------------------

--
-- Table structure for table `NMActivityChiNode`
--

CREATE TABLE IF NOT EXISTS `NMActivityChiNode` (
  `id` int(11) NOT NULL,
  `fk_chinode_id` int(11) default NULL,
  `fk_activity_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_chinode_id` (`fk_chinode_id`),
  KEY `fk_activity_id` (`fk_activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NMActivityChiNode`
--


-- --------------------------------------------------------

--
-- Table structure for table `NMChiControllerChiController`
--

CREATE TABLE IF NOT EXISTS `NMChiControllerChiController` (
  `id` int(11) NOT NULL,
  `fk_chicontrollersource_id` int(11) default NULL,
  `fk_chicontrollertarget_id` int(11) default NULL,
  `sourcemultiplicity` varchar(255) default NULL,
  `sourcenavigability` varchar(255) default NULL,
  `targetmultiplicity` varchar(255) default NULL,
  `targetnavigability` varchar(255) default NULL,
  `relationtype` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_chicontrollersource_id` (`fk_chicontrollersource_id`),
  KEY `fk_chicontrollertarget_id` (`fk_chicontrollertarget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NMChiControllerChiController`
--


-- --------------------------------------------------------

--
-- Table structure for table `NMChiNodeChiNode`
--

CREATE TABLE IF NOT EXISTS `NMChiNodeChiNode` (
  `id` int(11) NOT NULL,
  `fk_chinodetarget_id` int(11) default NULL,
  `fk_chinodesource_id` int(11) default NULL,
  `sourcemultiplicity` varchar(255) default NULL,
  `sourcenavigability` varchar(255) default NULL,
  `targetmultiplicity` varchar(255) default NULL,
  `targetnavigability` varchar(255) default NULL,
  `relationtype` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_chinodetarget_id` (`fk_chinodetarget_id`),
  KEY `fk_chinodesource_id` (`fk_chinodesource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NMChiNodeChiNode`
--


-- --------------------------------------------------------

--
-- Table structure for table `NMFeatureRequirements`
--

CREATE TABLE IF NOT EXISTS `NMFeatureRequirements` (
  `id` int(11) NOT NULL,
  `fk_chifeature_id` int(11) default NULL,
  `fk_chirequirement_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NMFeatureRequirements`
--

INSERT INTO `NMFeatureRequirements` (`id`, `fk_chifeature_id`, `fk_chirequirement_id`) VALUES
(21268, 8834, 7858),
(9030, 8840, 7870),
(9026, 8834, 7870),
(9022, 8309, 7870),
(9016, 8850, 7864),
(8999, 8309, 7858),
(8988, 8886, 8502),
(8987, 8855, 8502),
(9035, 8850, 7870),
(9047, 8840, 7876),
(9051, 8861, 7876),
(9052, 8850, 7876),
(9058, 8309, 7882),
(9059, 8834, 7882),
(9060, 8840, 7882),
(9061, 8850, 7882),
(9062, 8855, 7882),
(9066, 8878, 7888),
(9069, 8861, 7888),
(9075, 8309, 7894),
(9076, 8834, 7894),
(9077, 8840, 7894),
(9078, 8850, 7894),
(9084, 8834, 7900),
(9085, 8840, 7900),
(9086, 8850, 7900),
(9087, 8886, 7900),
(9126, 8850, 8520),
(9130, 8850, 8528),
(9152, 8309, 7938),
(9163, 8885, 7944),
(9289, 8834, 7976),
(9293, 8840, 7984),
(9297, 8840, 7990),
(9298, 8850, 7990),
(9309, 8909, 7996),
(9313, 8850, 8016),
(12575, 12570, 12419);

-- --------------------------------------------------------

--
-- Table structure for table `NMFiguresDiagram`
--

CREATE TABLE IF NOT EXISTS `NMFiguresDiagram` (
  `id` int(11) NOT NULL,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NMFiguresDiagram`
--


-- --------------------------------------------------------

--
-- Table structure for table `NMUCActor`
--

CREATE TABLE IF NOT EXISTS `NMUCActor` (
  `id` int(11) NOT NULL,
  `fk_chibusinessusecasecore_id` int(11) default NULL,
  `fk_chiworkerexternal_id` int(11) default NULL,
  `fk_chiworkerinternal_id` int(11) default NULL,
  `fk_chiworker_id` int(11) default NULL,
  `fk_chibusinesspartneractive_id` int(11) default NULL,
  `fk_chibusinesspartnerpassive_id` int(11) default NULL,
  `fk_chibusinesspartner_id` int(11) default NULL,
  `fk_chibusinessusecase_id` int(11) default NULL,
  `fk_actor_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NMUCActor`
--

INSERT INTO `NMUCActor` (`id`, `fk_chibusinessusecasecore_id`, `fk_chiworkerexternal_id`, `fk_chiworkerinternal_id`, `fk_chiworker_id`, `fk_chibusinesspartneractive_id`, `fk_chibusinesspartnerpassive_id`, `fk_chibusinesspartner_id`, `fk_chibusinessusecase_id`, `fk_actor_id`) VALUES
(16073, NULL, 13286, NULL, NULL, NULL, NULL, NULL, 12587, NULL),
(20470, 9961, 9679, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20685, 9956, 9474, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20608, 9720, 9474, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20611, 9920, 9474, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20605, 9702, 9474, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20612, 9867, 9673, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20613, 9938, 9474, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20617, 9961, 9679, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20737, 9938, 9474, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20981, 9938, 9474, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20982, 9938, NULL, 20927, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `NMUserRole`
--

CREATE TABLE IF NOT EXISTS `NMUserRole` (
  `fk_role_id` int(11) NOT NULL,
  `fk_user_id` int(11) NOT NULL,
  `fk_userrdb_id` int(11) default NULL,
  `fk_rolerdb_id` int(11) default NULL,
  PRIMARY KEY  (`fk_role_id`,`fk_user_id`),
  KEY `fk_userrdb_id` (`fk_userrdb_id`),
  KEY `fk_rolerdb_id` (`fk_rolerdb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NMUserRole`
--


-- --------------------------------------------------------

--
-- Table structure for table `nm_user_role`
--

CREATE TABLE IF NOT EXISTS `nm_user_role` (
  `id` int(11) NOT NULL,
  `fk_user_id` int(11) default NULL,
  `fk_role_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nm_user_role`
--

INSERT INTO `nm_user_role` (`id`, `fk_user_id`, `fk_role_id`) VALUES
(4, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Operation`
--

CREATE TABLE IF NOT EXISTS `Operation` (
  `id` int(11) NOT NULL,
  `fk_chinode_id` int(11) default NULL,
  `returntype` varchar(255) default NULL,
  `parameters` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_chinode_id` (`fk_chinode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Operation`
--


-- --------------------------------------------------------

--
-- Table structure for table `Package`
--

CREATE TABLE IF NOT EXISTS `Package` (
  `id` int(11) NOT NULL,
  `fk_chibusinessprocess_id` int(11) default NULL,
  `fk_package_id` int(11) default NULL,
  `alias` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  `fk_model_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Package`
--

INSERT INTO `Package` (`id`, `fk_chibusinessprocess_id`, `fk_package_id`, `alias`, `version`, `name`, `notes`, `created`, `creator`, `last_editor`, `modified`, `fk_model_id`) VALUES
(21042, NULL, 7673, NULL, NULL, 'vision mission', NULL, '2009-03-05 13:23:50', 'pgiuseppe', 'pgiuseppe', '2009-03-05 14:16:07', NULL),
(7673, NULL, 7641, NULL, NULL, 'Goals', NULL, '2009-02-04 10:31:19', 'marco.eilers', 'marco.eilers', '2009-02-04 10:31:55', NULL),
(7653, NULL, 7641, NULL, NULL, 'Requirements', NULL, '2009-02-04 10:30:23', 'marco.eilers', 'marco.eilers', '2009-02-04 10:32:06', NULL),
(7652, NULL, 7641, NULL, NULL, 'Features', NULL, '2009-02-04 10:30:12', 'marco.eilers', 'marco.eilers', '2009-02-04 10:32:14', NULL),
(7641, NULL, NULL, NULL, NULL, 'Analysis', NULL, '2009-02-04 10:29:31', 'marco.eilers', 'marco.eilers', '2009-02-04 10:29:44', 2117),
(12098, NULL, NULL, NULL, NULL, 'ChiRequirements', ' \n	 \n	 \n<p><span >The </span><span><b>ChiRequirements</b></span><span lang="en-GB"> \nmodel is a structured catalogue of end-user requirements. </span> \n</p> \n \n \n<p>The model is divided into \n4 sub-catalogues, organized in packages:</p> \n<ul><li><p>ChiGoals</p> \n	</li><li><p>ChiRequirements</p></li><li><p>ChiFeatures</p> \n	</li><li>ChiIssues</li></ul> \n', '2009-02-10 17:55:05', 'pgiuseppe', 'pgiuseppe', '2009-02-10 18:36:16', 12097),
(8143, NULL, 7641, NULL, NULL, 'Issues', NULL, '2009-02-04 11:41:19', 'marco.eilers', 'marco.eilers', '2009-02-04 11:41:33', NULL),
(9430, NULL, NULL, NULL, NULL, 'Processes', NULL, '2009-02-04 16:23:49', 'marco.eilers', 'marco.eilers', '2009-02-04 16:24:04', 2117),
(9437, NULL, 9430, NULL, NULL, 'Actors', NULL, '2009-02-04 16:24:36', 'marco.eilers', 'marco.eilers', '2009-02-04 16:24:47', NULL),
(9694, NULL, 9430, NULL, NULL, 'Use Cases', NULL, '2009-02-05 10:40:19', 'marco.eilers', 'marco.eilers', '2009-02-05 10:40:29', NULL),
(12099, NULL, 12098, NULL, NULL, 'Goals', '\n	\n	\n<p>This package\ncontains ChiGoals, that are statuses  that you intend to achieves in\nyour project.</p>\n\n	\n	\n<p></p>', '2009-02-10 17:55:05', 'pgiuseppe', 'pgiuseppe', '2009-02-10 18:39:26', NULL),
(12106, NULL, 12098, NULL, NULL, 'Requirements', '&#160; \n	This package \ncontains the project requirements. You can create here an additional \nproject specific structure. \n', '2009-02-10 17:55:05', 'pgiuseppe', 'pgiuseppe', '2009-02-10 18:58:13', NULL),
(12126, NULL, 12098, NULL, NULL, 'Features', '&#160;\n	This package\ncontains the project <b>Features</b>. You can create here an additional\nproject specific structure.\n', '2009-02-10 17:55:05', 'pgiuseppe', 'pgiuseppe', '2009-02-10 18:45:27', NULL),
(12138, NULL, 12098, NULL, NULL, 'Issues', NULL, '2009-02-10 17:55:06', 'pgiuseppe', 'pgiuseppe', '2009-02-10 17:55:11', NULL),
(12142, NULL, NULL, NULL, NULL, 'ChiAnalysis', 'Goal of the ChiAnalysis package is to store \nthe description of the system''s behaviour. It is organized in the sub \npackages Processes, Use Cases , Actors and Activities \n<p>Output of the ChiAnalysis \nis a document that contains this description.</p> \n', '2009-02-10 17:55:06', 'pgiuseppe', 'pgiuseppe', '2009-02-10 18:58:08', 12097),
(12143, NULL, 12142, NULL, NULL, 'Actors', 'This package  \ncontains the project Actors. You can create here an additional  \nproject specific structure.  \n', '2009-02-10 17:55:06', 'pgiuseppe', 'pgiuseppe', '2009-02-10 18:58:44', NULL),
(12148, NULL, 12142, NULL, NULL, 'Use Cases', 'This package  \ncontains the project Use Cases. You can create here an additional  \nproject specific structure.', '2009-02-10 17:55:06', 'pgiuseppe', 'pgiuseppe', '2009-02-10 18:59:00', NULL),
(12455, NULL, NULL, NULL, NULL, 'ChiDomain', '&#160; \n	This package contains domain modelling information. \n<p>Its includes Packages for \ndescribing the Domain organized in:</p><ul><li> Domain Objects, <br></li><li>Services and <br></li><li>Views.</li></ul> \n', '2009-02-10 19:26:30', 'pgiuseppe', 'pgiuseppe', '2009-02-10 19:42:15', 12097),
(12390, NULL, 12142, NULL, NULL, 'Processes', 'This package  \ncontains the project Processes. You can create here an additional  \nproject specific structure.', '2009-02-10 18:48:02', 'pgiuseppe', 'pgiuseppe', '2009-02-10 18:59:23', NULL),
(12458, NULL, 12455, NULL, NULL, 'Domain Objects', '&#160; This package    \ncontains the project Domain Objects. You can create here an additional    \nproject specific structure.', '2009-02-10 19:29:20', 'pgiuseppe', 'pgiuseppe', '2009-02-10 19:50:13', NULL),
(12468, NULL, 12455, NULL, NULL, 'Services', '&#160; This package    \ncontains the project Services. You can create here an additional    \nproject specific structure.', '2009-02-10 19:42:25', 'pgiuseppe', 'pgiuseppe', '2009-02-10 19:50:30', NULL),
(12473, NULL, 12455, NULL, NULL, 'Views', NULL, '2009-02-10 19:48:17', 'pgiuseppe', 'pgiuseppe', '2009-02-10 19:48:25', NULL),
(18605, NULL, 7641, NULL, NULL, 'UK Pilot', '<span > <br></span>', '2009-02-27 12:49:47', 'ibm', 'ibm', '2009-03-04 17:31:07', NULL),
(20996, NULL, 18605, NULL, NULL, 'Goals', '&#160;jj', '2009-03-04 17:31:01', 'ibm', 'ibm', '2009-03-04 17:32:22', NULL),
(21002, NULL, 20996, NULL, NULL, 'New Package', NULL, '2009-03-04 17:32:19', 'ibm', 'ibm', '2009-03-04 17:32:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Relation`
--

CREATE TABLE IF NOT EXISTS `Relation` (
  `id` int(11) NOT NULL,
  `sourcemultiplicity` varchar(255) default NULL,
  `sourcenavigability` varchar(255) default NULL,
  `targetmultiplicity` varchar(255) default NULL,
  `targetnavigability` varchar(255) default NULL,
  `relationtype` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Relation`
--


-- --------------------------------------------------------

--
-- Table structure for table `RelationMultiplicity`
--

CREATE TABLE IF NOT EXISTS `RelationMultiplicity` (
  `id` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `RelationMultiplicity`
--


-- --------------------------------------------------------

--
-- Table structure for table `RelationType`
--

CREATE TABLE IF NOT EXISTS `RelationType` (
  `id` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  `notes` text,
  `created` varchar(255) default NULL,
  `creator` varchar(255) default NULL,
  `last_editor` varchar(255) default NULL,
  `modified` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `RelationType`
--


-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL,
  `name` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--


-- --------------------------------------------------------

--
-- Table structure for table `RoleRDB`
--

CREATE TABLE IF NOT EXISTS `RoleRDB` (
  `id` int(11) NOT NULL,
  `name` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `RoleRDB`
--

INSERT INTO `RoleRDB` (`id`, `name`) VALUES
(2, 'administrators'),
(21465, 'users');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `login` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `firstname` varchar(50) default NULL,
  `config` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `name`, `firstname`, `config`) VALUES
(3, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator', NULL, 'include/admin.ini'),
(21464, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'user', 'user', 'config.ini');

-- --------------------------------------------------------

--
-- Table structure for table `UserRDB`
--

CREATE TABLE IF NOT EXISTS `UserRDB` (
  `id` int(11) NOT NULL,
  `login` varchar(50) default NULL,
  `password` varchar(255) default NULL,
  `name` varchar(50) default NULL,
  `firstname` varchar(50) default NULL,
  `config` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UserRDB`
--

