

Generating the CWM backend from the Requirements model
======================================================

1. Copy the current sources from 
   
   https://olympos.svn.sourceforge.net/svnroot/olympos/trunk/olympos/chronos/scr/applications/requirements/application
   
   to ./requirements/build/application
   
2. Delete .svn directories in ./requirements/build/application
   (otherwise the protected region resolver will be confused)
   
3. Copy the current model from

   https://olympos.svn.sourceforge.net/svnroot/olympos/trunk/olympos/chronos/scr/model/requirements.EAP
   
   to ./requirements/requirements.EAP
   
4. Run ./requirements/run.bat in the console (working directory is ./requirements/)

5. The CWM backend is generated in ./requirements/build/application