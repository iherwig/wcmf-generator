// ----------------------------------------------------------
// wCMFGenerator
// based on the openArchitectureWare project
// see http://www.openarchitectureware.org/
// ----------------------------------------------------------

Usage:
java -Djava.library.path=./lib/ -jar wCMFGenerator.jar workflow/workflow.oaw -basePath=. -propertyFile=workflow/workflow.properties

Configuration:
- basePath: 	path to model, metamodel, workflow directories
- propertyFile: property file with project specific settings
