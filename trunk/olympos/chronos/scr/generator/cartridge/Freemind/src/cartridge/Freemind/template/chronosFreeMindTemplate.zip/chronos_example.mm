<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<attribute_registry>
<attribute_name NAME="Fea. Status" RESTRICTED="true">
<attribute_value VALUE=""/>
<attribute_value VALUE="Implemented "/>
<attribute_value VALUE="Proposed "/>
<attribute_value VALUE="Rejected "/>
<attribute_value VALUE="Validated "/>
</attribute_name>
<attribute_name NAME="Req. Status" RESTRICTED="true">
<attribute_value VALUE=""/>
<attribute_value VALUE="Mandatory"/>
<attribute_value VALUE="Proposed"/>
<attribute_value VALUE="Satisfied"/>
<attribute_value VALUE="Validated"/>
</attribute_name>
<attribute_name NAME="Type" RESTRICTED="true">
<attribute_value VALUE=""/>
<attribute_value VALUE="ChiBusinessUseCase"/>
<attribute_value VALUE="ChiFeature"/>
<attribute_value VALUE="ChiGoal"/>
<attribute_value VALUE="ChiIssue"/>
<attribute_value VALUE="ChiRequirement"/>
</attribute_name>
</attribute_registry>
<node CREATED="1228144317281" ID="ID_1823873164" MODIFIED="1289855583935" TEXT="Chronos Requirements model">
<font NAME="SansSerif" SIZE="12"/>
<hook NAME="accessories/plugins/HierarchicalIcons.properties"/>
<attribute_layout NAME_WIDTH="132" VALUE_WIDTH="141"/>
<node CREATED="1289855562192" HGAP="16" ID="Chi287Req" LINK="http://garr.dl.sourceforge.net/sourceforge/olympos/Chronos_Profile_Documentation.pdf" MODIFIED="1290093666784" POSITION="left" TEXT="Help" VSHIFT="-18">
<icon BUILTIN="help"/>
<attribute_layout NAME_WIDTH="132" VALUE_WIDTH="141"/>
</node>
<node CREATED="1228144960531" HGAP="97" ID="ID_451956133" MODIFIED="1290017457442" POSITION="right" VSHIFT="-4">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <img src="ChiGoal.png"/>
      mein Ziel
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      this is a note
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<attribute_layout NAME_WIDTH="109"/>
<attribute NAME="Type" VALUE="ChiGoal"/>
<attribute NAME="Priority" VALUE="50"/>
<attribute NAME="Value Name" VALUE="earning"/>
<attribute NAME="Value ammount" VALUE="20%"/>
<attribute NAME="Value Goal" VALUE="120"/>
<node CREATED="1228144432312" HGAP="56" ID="ID_787646724" MODIFIED="1228148095734" VSHIFT="3">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <img src="ChiRequirement.png"/>
      mein Szenario
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_787646724" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_512851619" STARTARROW="None" STARTINCLINATION="0;0;"/>
<font NAME="SansSerif" SIZE="12"/>
<attribute NAME="Type" VALUE="ChiRequirement"/>
<attribute NAME="Priority" VALUE="50"/>
<attribute NAME="Author" VALUE="domain expert"/>
<attribute NAME="Proofreader" VALUE="Manager"/>
<attribute NAME="Req. Status" VALUE="Proposed"/>
<attribute NAME="Req. Type" VALUE="Scenario"/>
<node CREATED="1228144432312" HGAP="33" ID="ID_1663276132" MODIFIED="1228149130484" VSHIFT="-47">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <img src="ChiRequirement.png"/>
      Anforderung 1
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_1663276132" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_106911721" STARTARROW="None" STARTINCLINATION="0;0;"/>
<font NAME="SansSerif" SIZE="12"/>
<attribute NAME="Type" VALUE="ChiRequirement"/>
<attribute NAME="Priority" VALUE="50"/>
<attribute NAME="Author" VALUE="Analyst"/>
<attribute NAME="Proofreader" VALUE="Manager"/>
<attribute NAME="Req. Status" VALUE="Proposed"/>
<attribute NAME="Req. Type" VALUE="Business Rule"/>
<node CREATED="1228144362937" HGAP="83" ID="ID_426376886" MODIFIED="1228149645562" VSHIFT="-34">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <img src="ChiIssue.png"/>
      mein Offene Punkt
    </p>
  </body>
</html></richcontent>
<attribute NAME="Type" VALUE="ChiIssue"/>
<attribute NAME="Author" VALUE="domain expert"/>
<attribute NAME="Responsible" VALUE="manager"/>
</node>
</node>
<node CREATED="1228144432312" HGAP="123" ID="chiblip1" MODIFIED="1290093657424" VSHIFT="8">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <img src="ChiRequirement.png"/>
      Anforderung 2
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="chiblip1" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_29544136" STARTARROW="None" STARTINCLINATION="0;0;"/>
<font NAME="SansSerif" SIZE="12"/>
<attribute NAME="Type" VALUE="ChiRequirement"/>
<attribute NAME="Priority" VALUE="50"/>
<attribute NAME="Author" VALUE="ich"/>
<attribute NAME="Proofreader" VALUE="Manager"/>
<attribute NAME="Req. Status" VALUE="Proposed"/>
<attribute NAME="Req. Type" VALUE="Persistence"/>
<node CREATED="1228144657578" HGAP="65" ID="ID_1520303491" MODIFIED="1228149635234" VSHIFT="-4">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <img src="ChiFeature.png"/>
      mein Massnahme
    </p>
  </body>
</html></richcontent>
<attribute NAME="Type" VALUE="ChiFeature"/>
<attribute NAME="Author" VALUE="Analyst"/>
<attribute NAME="Proofreader" VALUE="manager"/>
<attribute NAME="Fea. Status" VALUE="Proposed "/>
<node CREATED="1228148660484" HGAP="110" MODIFIED="1290017524221" VSHIFT="-62">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <img src="ChiBusinessUseCase.png"/>
      My Anwendungsfall
    </p>
  </body>
</html></richcontent>
<attribute_layout NAME_WIDTH="95" VALUE_WIDTH="145"/>
<attribute NAME="Type" VALUE="ChiBusinessUseCase"/>
<attribute NAME="Author" VALUE="Analyst"/>
<attribute NAME="Primary Actor" VALUE="Techniker"/>
<attribute NAME="Goal in Context" VALUE=""/>
<attribute NAME="Scope" VALUE="System A"/>
<attribute NAME="Level" VALUE="Domain Obj a"/>
<attribute NAME="Stakeholders" VALUE=""/>
<attribute NAME="Precondition" VALUE=""/>
<attribute NAME="Main Success Scenario" VALUE="this"/>
<attribute NAME="Extensions" VALUE=""/>
</node>
<node CREATED="1228148660484" HGAP="172" ID="ID_1914963321" MODIFIED="1290093675817" VSHIFT="7">
<richcontent TYPE="NODE"><html>
  <head>
    <style type="text/css">
      <!--
        p { margin-top: 0 }
      -->
    </style>
    
  </head>
  <body>
    <p>
      <img src="ChiBusinessUseCase.png"/>
      My Anwendungsfall 2
    </p>
  </body>
</html></richcontent>
<attribute_layout NAME_WIDTH="95" VALUE_WIDTH="145"/>
<attribute NAME="Type" VALUE="ChiBusinessUseCase"/>
<attribute NAME="Author" VALUE="Analyst"/>
<attribute NAME="Primary Actor" VALUE="Techniker"/>
<attribute NAME="Goal in Context" VALUE=""/>
<attribute NAME="Scope" VALUE="System A"/>
<attribute NAME="Level" VALUE="Domain Obj a"/>
<attribute NAME="Stakeholders" VALUE=""/>
<attribute NAME="Precondition" VALUE=""/>
<attribute NAME="Main Success Scenario" VALUE="this"/>
<attribute NAME="Extensions" VALUE=""/>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
