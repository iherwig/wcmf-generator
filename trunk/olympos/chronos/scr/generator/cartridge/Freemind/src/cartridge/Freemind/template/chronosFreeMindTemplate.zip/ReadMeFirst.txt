Chronos template
version 0.1
Author: giuseppe.platania@de.ibm.com

This templates permit to create a mindmap compatible with the Chronos metamodel.
see: https://sourceforge.net/projects/olympos/


requires freeMind version 0.9 or better
To view the MM file, download free mind mapping software FreeMind from http://freemind.sourceforge.net

